#ifndef FR3D_LCD_REMOTE_H
#define FR3D_LCD_REMOTE_H

#include "MK3.h"

#ifdef ULTRA_LCD

/* Espejo 4x20 + encoder remoto (LCDQ / ENC* / ENCC). Spec FR3D 2026-09. */

#ifndef FR3D_LCD_MIRROR_ROWS
#define FR3D_LCD_MIRROR_ROWS LCD_HEIGHT
#endif
#ifndef FR3D_LCD_MIRROR_COLS
#define FR3D_LCD_MIRROR_COLS LCD_WIDTH
#endif

void fr3d_lcd_mirror_clear(void);
void fr3d_lcd_mirror_set_cursor(uint8_t col, uint8_t row);
void fr3d_lcd_mirror_write(uint8_t c);
/* Copia linea row a out[0..cols-1], NUL en out[cols]. chars no imprimibles -> '?' */
void fr3d_lcd_mirror_get_line(uint8_t row, char *out, uint8_t cols);

void fr3d_lcd_remote_enc_step(int8_t dir); /* +1 / -1 paso de menu */
void fr3d_lcd_remote_enc_click(void);
/* Si hay click remoto pendiente, pone *clicked=true y lo consume. */
void fr3d_lcd_remote_poll_click(bool *clicked);
/* Emite LCD,0..n-1,<cols chars>, por serial (snapshot LCDQ). */
void fr3d_lcd_remote_dump_lcdq(void);

/* 1=leer encoder fisico (default), 0=ignorar pines (banco sin panel). EEPROM + LCDHWENC */
extern uint8_t fr3d_lcd_hw_encoder;

#endif /* ULTRA_LCD */
#endif /* FR3D_LCD_REMOTE_H */