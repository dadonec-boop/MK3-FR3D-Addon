#ifndef FR3D_LCD_PROXY_H
#define FR3D_LCD_PROXY_H

#include <Print.h>
#include "fr3d_lcd_remote.h"

/* Proxy Print sobre LiquidCrystal: cada write/setCursor/clear actualiza el espejo. */
template <typename LcdHw>
class Fr3dLcdProxy : public Print {
public:
  explicit Fr3dLcdProxy(LcdHw &hw) : _hw(hw) {}

  size_t write(uint8_t c)
  {
    fr3d_lcd_mirror_write(c);
    return _hw.write(c);
  }

  void setCursor(uint8_t col, uint8_t row)
  {
    fr3d_lcd_mirror_set_cursor(col, row);
    _hw.setCursor(col, row);
  }

  void clear()
  {
    fr3d_lcd_mirror_clear();
    _hw.clear();
  }

  void begin(uint8_t cols, uint8_t rows)
  {
    fr3d_lcd_mirror_clear();
    _hw.begin(cols, rows);
  }

  void createChar(uint8_t location, uint8_t charmap[])
  {
    _hw.createChar(location, charmap);
  }

  void home()
  {
    fr3d_lcd_mirror_set_cursor(0, 0);
    _hw.home();
  }

private:
  LcdHw &_hw;
};

#endif /* FR3D_LCD_PROXY_H */