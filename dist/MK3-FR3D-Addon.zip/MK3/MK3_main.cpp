/* -*- c++ -*- */

/*
 MACKEREL - Filament Extruder firmware based on Marlin for repraps.
 Copyright (C) 2014 Filip Mulier/Hugh Lyman

 This program is free software: you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation, either version 3 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,                                                                                
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program.  If not, see <http://www.gnu.org/licenses/>.

 ---------------------------------------------------------------------------
 Modified by FR3D Addon — Claudio Dadone — 14 Jul 2026

 This firmware incorporates diameter measurement and predictive diameter
 control (manual / automatic modes).

 Prepared for optional remote control via Raspberry Pi Zero 2 W gateway
 and web app (MK3s + FR3D Addon). That host/app stack is not published
 in this firmware repository.

 For more information: http://fr3d-addon.web.app/
 ---------------------------------------------------------------------------
 */

/*
 This firmware was designed in conjunction with Hugh Lyman to control a Lyman filament extruder
 with geared stepper motors. It is currently designed to support the RAMPS 1.4 with Smart LCD 2004
 and depends on a prototype filament width sensor. It replaces much of the control electronics in
 the current design with one controller. It can control the extruder motor, puller motor, Extruder
 heater (PID) with thermistor, winder motor, filament cooling fan and has input for a filament width
 sensor. The processes and menus have been adapted to control a filament extruder. 
 
 This firmware is based on Marlin 3D Printer Firmware but also has many original parts.
  (https://github.com/ErikZalm/Marlin)
 
 Marlins eat Mackerels, 3D printers eat filament. 

 */

#include "MK3.h"

#ifdef ENABLE_AUTO_BED_LEVELING
#include "vector_3.h"
  #ifdef AUTO_BED_LEVELING_GRID
    #include "qr_solve.h"
  #endif
#endif // ENABLE_AUTO_BED_LEVELING

#include "ultralcd.h"
#include "planner.h"
#include "stepper.h"
#include "temperature.h"
#include "motion_control.h"
#include "cardreader.h"
#include "watchdog.h"
#include "ConfigurationStore.h"
#include "fr3d_telemetry.h"
#include "fr3d_gateway_id.h"
#include "language.h"
#include "pins_arduino.h"
#include "math.h"
#include <Arduino.h>

#ifdef BLINKM
#include "BlinkM.h"
#include "Wire.h"
#endif

#if NUM_SERVOS > 0
#include "Servo.h"
#endif

#if defined(DIGIPOTSS_PIN) && DIGIPOTSS_PIN > -1
#include <SPI.h>
#endif

#define VERSION_STRING  "1.1.0"
#define FR3D_MK3_FW_DATE "2026-04-27"

// look here for descriptions of G-codes: http://linuxcnc.org/handbook/gcode/g-code.html
// http://objects.reprap.org/wiki/Mendel_User_Manual:_RepRapGCodes

//Implemented Codes
//-------------------
// G0  -> G1
// G1  - Coordinated Movement X Y Z E
// G2  - CW ARC
// G3  - CCW ARC
// G4  - Dwell S<seconds> or P<milliseconds>
// G10 - retract filament according to settings of M207
// G11 - retract recover filament according to settings of M208
// G28 - Home all Axis
// G29 - Detailed Z-Probe, probes the bed at 3 or more points.  Will fail if you haven't homed yet.
// G30 - Single Z Probe, probes bed at current XY location.
// G90 - Use Absolute Coordinates
// G91 - Use Relative Coordinates
// G92 - Set current position to coordinates given

// M Codes
// M0   - Unconditional stop - Wait for user to press a button on the LCD (Only if ULTRA_LCD is enabled)
// M1   - Same as M0
// M17  - Enable/Power all stepper motors
// M18  - Disable all stepper motors; same as M84
// M20  - List SD card
// M21  - Init SD card
// M22  - Release SD card
// M23  - Select SD file (M23 filename.g)
// M24  - Start/resume SD print
// M25  - Pause SD print
// M26  - Set SD position in bytes (M26 S12345)
// M27  - Report SD print status
// M28  - Start SD write (M28 filename.g)
// M29  - Stop SD write
// M30  - Delete file from SD (M30 filename.g)
// M31  - Output time since last M109 or SD card start to serial
// M32  - Select file and start SD print (Can be used _while_ printing from SD card files):
//        syntax "M32 /path/filename#", or "M32 S<startpos bytes> !filename#"
//        Call gcode file : "M32 P !filename#" and return to caller file after finishing (similar to #include).
//        The '#' is necessary when calling from within sd files, as it stops buffer prereading
// M42  - Change pin status via gcode Use M42 Px Sy to set pin x to value y, when omitting Px the onboard led will be used.
// M80  - Turn on Power Supply
// M81  - Turn off Power Supply
// M82  - Set E codes absolute (default)
// M83  - Set E codes relative while in Absolute Coordinates (G90) mode
// M84  - Disable steppers until next move,
//        or use S<seconds> to specify an inactivity timeout, after which the steppers will be disabled.  S0 to disable the timeout.
// M85  - Set inactivity shutdown timer with parameter S<seconds>. To disable set zero (default)
// M92  - Set axis_steps_per_unit - same syntax as G92
// M104 - Set extruder target temp
// M105 - Read current temp
// M106 - Fan on
// M107 - Fan off
// M109 - Sxxx Wait for extruder current temp to reach target temp. Waits only when heating
//        Rxxx Wait for extruder current temp to reach target temp. Waits when heating and cooling
// M114 - Output current position to serial port
// M115 - Capabilities string
// M117 - display message
// M119 - Output Endstop status to serial port
// M126 - Solenoid Air Valve Open (BariCUDA support by jmil)
// M127 - Solenoid Air Valve Closed (BariCUDA vent to atmospheric pressure by jmil)
// M128 - EtoP Open (BariCUDA EtoP = electricity to air pressure transducer by jmil)
// M129 - EtoP Closed (BariCUDA EtoP = electricity to air pressure transducer by jmil)
// M140 - Set bed target temp
// M150 - Set BlinkM Color Output R: Red<0-255> U(!): Green<0-255> B: Blue<0-255> over i2c, G for green does not work.
// M190 - Sxxx Wait for bed current temp to reach target temp. Waits only when heating
//        Rxxx Wait for bed current temp to reach target temp. Waits when heating and cooling
// M200 D<millimeters>- set filament diameter and set E axis units to cubic millimeters (use S0 to set back to millimeters).
// M201 - Set max acceleration in units/s^2 for print moves (M201 X1000 Y1000)
// M202 - Set max acceleration in units/s^2 for travel moves (M202 X1000 Y1000) Unused in Marlin!!
// M203 - Set maximum feedrate that your machine can sustain (M203 X200 Y200 Z300 E10000) in mm/sec
// M204 - Set default acceleration: S normal moves T filament only moves (M204 S3000 T7000) in mm/sec^2  also sets minimum segment time in ms (B20000) to prevent buffer under-runs and M20 minimum feedrate
// M205 -  advanced settings:  minimum travel speed S=while printing T=travel only,  B=minimum segment time X= maximum xy jerk, Z=maximum Z jerk, E=maximum E jerk
// M206 - set additional homing offset
// M207 - set retract length S[positive mm] F[feedrate mm/min] Z[additional zlift/hop], stays in mm regardless of M200 setting
// M208 - set recover=unretract length S[positive mm surplus to the M207 S*] F[feedrate mm/sec]
// M209 - S<1=true/0=false> enable automatic retract detect if the slicer did not support G10/11: every normal extrude-only move will be classified as retract depending on the direction.
// M218 - set hotend offset (in mm): T<extruder_number> X<offset_on_X> Y<offset_on_Y>
// M220 S<factor in percent>- set speed factor override percentage
// M221 S<factor in percent>- set extrude factor override percentage
// M226 P<pin number> S<pin state>- Wait until the specified pin reaches the state required
// M240 - Trigger a camera to take a photograph
// M250 - Set LCD contrast C<contrast value> (value 0..63)
// M280 - set servo position absolute. P: servo index, S: angle or microseconds
// M300 - Play beep sound S<frequency Hz> P<duration ms>
// M301 - Set PID parameters P I and D
// M302 - Allow cold extrudes, or set the minimum extrude S<temperature>.
// M303 - PID relay autotune S<temperature> sets the target temperature. (default target temperature = 150C)
// M304 - Set bed PID parameters P I and D
// M400 - Finish all moves
// M401 - Lower z-probe if present
// M402 - Raise z-probe if present
// M500 - stores parameters in EEPROM
// M501 - reads parameters from EEPROM (if you need reset them after you changed them temporarily).
// M502 - reverts to the default "factory settings".  You still need to store them in EEPROM afterwards if you want to.
// M503 - print the current settings (from memory not from EEPROM)
// M540 - Use S[0|1] to enable or disable the stop SD card print on endstop hit (requires ABORT_ON_ENDSTOP_HIT_FEATURE_ENABLED)
// M600 - Pause for filament change X[pos] Y[pos] Z[relative lift] E[initial retract] L[later retract distance for removal]
// M665 - set delta configurations
// M666 - set delta endstop adjustment
// M605 - Set dual x-carriage movement mode: S<mode> [ X<duplication x-offset> R<duplication temp offset> ]
// M700 - Extruder data dump 
// M907 - Set digital trimpot motor current using axis codes.
// M908 - Control digital trimpot directly.
// M350 - Set microstepping mode.
// M351 - Toggle MS1 MS2 pins directly.
// M928 - Start SD logging (M928 filename.g) - ended by M29
// M999 - Restart after being stopped by error

//Stepper Movement Variables

//===========================================================================
//=============================imported variables============================
//===========================================================================


//===========================================================================
//=============================public variables=============================
//===========================================================================
#ifdef SDSUPPORT
CardReader card;
#endif
float homing_feedrate[] = HOMING_FEEDRATE;
bool axis_relative_modes[] = AXIS_RELATIVE_MODES;
unsigned char extrude_status =0;
float filament_width_desired= DESIRED_FILAMENT_DIA; //holds the desired filament width (i.e like 2.6mm)
int feedmultiply; //100->1 200->2
int saved_feedmultiply;

int extrudemultiply=100; //100->1 200->2
float extruder_feedrate;  //extruder real time 'feed rate' - yet we are really interested in RPM
float extruder_rpm; //real time extruder rpm
float extruder_rpm_set= DEFAULT_EXTRUDER_RPM; //setpoint for extruder RPM
float puller_feedrate_default = DEFAULT_PULLER_FEEDRATE; //puller motor feed rate in mm/sec
float puller_feedrate= DEFAULT_PULLER_FEEDRATE; //puller motor feed rate in mm/sec
float puller_feedrate_last = DEFAULT_PULLER_FEEDRATE;
float sum_measured_filament_width=0;  //numerator in average
float n_measured_filament_width=0;  //denominator in average
float avg_measured_filament_width=0; //average
float max_measured_filament_width=0; // max measured filament width 
float min_measured_filament_width=0; // min measured filament width 
float extrude_length=0; //length extruded
float fil_length_cutoff= DEFAULT_LENGTH_CUTOFF; //length of filament at which extruder shuts down
int default_winder_speed = DEFAULT_WINDER_SPEED;
int injectionTimeSeconds = DEFAULT_INJECTION_TIME;
unsigned long injectionModeStartMillis = -1;
int winder_rpm_factor = DEFAULT_WINDER_RPM_FACTOR;
uint8_t sinfin_compression_mode = DEFAULT_SINFIN_COMPRESSION;
#ifdef FR3D_SERIAL_HOST_DISABLE_GM
bool fr3d_serial_filter_msgs = DEFAULT_FR3D_SERIAL_FILTER_MSGS_ON;
#ifndef FR3D_SERIAL_HOST_ONLY_COMPACT
  /* 1: por USB solo acepta comandos compactos FR3D.
     0: bloquea solo G/M (comportamiento anterior). */
  #define FR3D_SERIAL_HOST_ONLY_COMPACT 1
#endif
#endif
unsigned long starttime=0;
unsigned long stoptime=0;

unsigned long duration=0;
unsigned long timeremaining=DEFAULT_LENGTH_CUTOFF/DEFAULT_PULLER_FEEDRATE*1000;  //used to hold a calculated time remaining in ms to hit fil length cutoff

int maxBeepSequenceLength = 20;
int beepSequence[20];
int currentBeepSequenceIndex = -1;
int currentBeepSequenceLength;
unsigned long currentBeepMillis;

void setBeepSequence(int bs[], int length)
{
  if (length > maxBeepSequenceLength)
    length = maxBeepSequenceLength;
  for (int i = 0; i < length; i++)
    beepSequence[i] = bs[i];

  currentBeepSequenceLength = length;
  currentBeepSequenceIndex = 0;
  currentBeepMillis = millis();

  WRITE(BEEPER,HIGH);

}

void beepSequenceLoop() {

  if (currentBeepSequenceIndex >= 0 && currentBeepSequenceIndex < currentBeepSequenceLength) {

    unsigned long elapsedMillis = millis() - currentBeepMillis;

    if (elapsedMillis > beepSequence[currentBeepSequenceIndex]) {
      currentBeepSequenceIndex++;
      currentBeepMillis = millis();
      if (currentBeepSequenceIndex % 2 == 0) {
        WRITE(BEEPER,HIGH);
      } else {
        WRITE(BEEPER,LOW);
      }
      if (currentBeepSequenceIndex >= currentBeepSequenceLength) {
        currentBeepSequenceIndex = -1;
        WRITE(BEEPER,LOW);
      }
    }
  }


}


float model_out;  //Smith predictor model out
float model_gain; //Smith predictor model gain
float model_param; //Smith Predictor low pass param
float smith_filter_out;
float smith_filter_param;

int model_delay[100]; //Smith predictor delay line 
float last_p_position=0.0;  //keeps track of last position updated in the delay line

float filament_control=0.0;
unsigned long runoutStartTimeMS = 0;
unsigned long safetycooldownStartTimeMS = 0;

int extruder_multiply[EXTRUDERS] = {100
  #if EXTRUDERS > 1
    , 100
    #if EXTRUDERS > 2
      , 100
    #endif
  #endif
};
float volumetric_multiplier[EXTRUDERS] = {1.0
  #if EXTRUDERS > 1
    , 1.0
    #if EXTRUDERS > 2
      , 1.0
    #endif
  #endif
};
float current_position[NUM_AXIS] = { 0.0, 0.0, 0.0, 0.0, 0.0};  //FMM added P_AXIS
float add_homeing[3]={0,0,0};
#ifdef DELTA
float endstop_adj[3]={0,0,0};
#endif
float min_pos[3] = { X_MIN_POS, Y_MIN_POS, Z_MIN_POS };
float max_pos[3] = { X_MAX_POS, Y_MAX_POS, Z_MAX_POS };
bool axis_known_position[3] = {false, false, false};
float zprobe_zoffset;

// Extruder offset
#if EXTRUDERS > 1
#ifndef DUAL_X_CARRIAGE
  #define NUM_EXTRUDER_OFFSETS 2 // only in XY plane
#else
  #define NUM_EXTRUDER_OFFSETS 3 // supports offsets in XYZ plane
#endif
float extruder_offset[NUM_EXTRUDER_OFFSETS][EXTRUDERS] = {
#if defined(EXTRUDER_OFFSET_X) && defined(EXTRUDER_OFFSET_Y)
  EXTRUDER_OFFSET_X, EXTRUDER_OFFSET_Y
#endif
};
#endif
uint8_t active_extruder = 0;
int winderSpeed=0;
#ifdef SERVO_ENDSTOPS
  int servo_endstops[] = SERVO_ENDSTOPS;
  int servo_endstop_angles[] = SERVO_ENDSTOP_ANGLES;
#endif
#ifdef BARICUDA
int ValvePressure=0;
int EtoPPressure=0;
#endif

#ifdef FWRETRACT
  bool autoretract_enabled=false;
  bool retracted=false;
  float retract_length = RETRACT_LENGTH;
  float retract_feedrate = RETRACT_FEEDRATE;
  float retract_zlift = RETRACT_ZLIFT;
  float retract_recover_length = RETRACT_RECOVER_LENGTH;
  float retract_recover_feedrate = RETRACT_RECOVER_FEEDRATE;
#endif

#ifdef ULTIPANEL
  #ifdef PS_DEFAULT_OFF
    bool powersupply = false;
  #else
	  bool powersupply = true;
  #endif
#endif

#ifdef DELTA
  float delta[3] = {0.0, 0.0, 0.0};
  #define SIN_60 0.8660254037844386
  #define COS_60 0.5
  // these are the default values, can be overriden with M665
  float delta_radius= DELTA_RADIUS;
  float delta_tower1_x= -SIN_60*delta_radius; // front left tower
  float delta_tower1_y= -COS_60*delta_radius;	   
  float delta_tower2_x=  SIN_60*delta_radius; // front right tower
  float delta_tower2_y= -COS_60*delta_radius;	   
  float delta_tower3_x= 0.0;                  // back middle tower
  float delta_tower3_y= delta_radius;
  float delta_diagonal_rod= DELTA_DIAGONAL_ROD;
  float delta_diagonal_rod_2= sq(delta_diagonal_rod);
  float delta_segments_per_second= DELTA_SEGMENTS_PER_SECOND;
#endif					

//===========================================================================
//=============================Private Variables=============================
//===========================================================================
const char axis_codes[NUM_AXIS] = {'X', 'Y', 'Z', 'E', 'P'};
static float destination[NUM_AXIS] = {  0.0, 0.0, 0.0, 0.0, 0.0};
static float offset[3] = {0.0, 0.0, 0.0};
static bool home_all_axis = true;
static float feedrate = 1500.0, next_feedrate, saved_feedrate;
static long gcode_N, gcode_LastN, Stopped_gcode_LastN = 0;

static bool relative_mode = false;  //Determines Absolute or Relative Coordinates

static char cmdbuffer[BUFSIZE][MAX_CMD_SIZE];
static bool fromsd[BUFSIZE];
static int bufindr = 0;
static int bufindw = 0;
static int buflen = 0;
//static int i = 0;
static char serial_char;
static int serial_count = 0;
static boolean comment_mode = false;
static char *strchr_pointer; // just a pointer to find chars in the command string like X, Y, Z, E, etc

const int sensitive_pins[] = SENSITIVE_PINS; // Sensitive pin list for M42

//static float tt = 0;
//static float bt = 0;

//Inactivity shutdown variables
static unsigned long previous_millis_cmd = 0;
static unsigned long max_inactive_time = 0;
static unsigned long stepper_inactive_time = DEFAULT_STEPPER_DEACTIVE_TIME*1000l;



static uint8_t tmp_extruder;

static float extruder_increment;  //used to calculate the increment to add to create the next planning move for the extruder motor
static float puller_increment; //used to calculate the increment to add to create the next planning move for the puller motor
static unsigned long timebuff=0;
static unsigned long deltatime=0;
static unsigned long lasttime=0;

//PID variables
static float dia_iState_fwidth = { 0 };
static float dia_dState_fwidth = { 0 };
static float pTerm_fwidth;
static float iTerm_fwidth;
static float dTerm_fwidth;
static bool pid_reset_fwidth;
  //int output;
static float pid_error_fwidth;
static float pid_input;

bool Stopped=false;

#if NUM_SERVOS > 0
  Servo servos[NUM_SERVOS];
#endif

bool CooldownNoWait = true;
bool target_direction;

//Insert variables if CHDK is defined
#ifdef CHDK
unsigned long chdkHigh = 0;
boolean chdkActive = false;
#endif

//===========================================================================
//=============================Routines======================================
//===========================================================================

void get_arc_coordinates();
bool setTargetedHotend(int code);

void serial_echopair_P(const char *s_P, float v)
    { serialprintPGM(s_P); SERIAL_ECHO(v); }
void serial_echopair_P(const char *s_P, double v)
    { serialprintPGM(s_P); SERIAL_ECHO(v); }
void serial_echopair_P(const char *s_P, unsigned long v)
    { serialprintPGM(s_P); SERIAL_ECHO(v); }

extern "C"{
  extern unsigned int __bss_end;
  extern unsigned int __heap_start;
  extern void *__brkval;

  int freeMemory() {
    int free_memory;

    if((int)__brkval == 0)
      free_memory = ((int)&free_memory) - ((int)&__bss_end);
    else
      free_memory = ((int)&free_memory) - ((int)__brkval);

    return free_memory;
  }
}

//adds an command to the main command buffer
//thats really done in a non-safe way.
//needs overworking someday
void enquecommand(const char *cmd)
{
  if(buflen < BUFSIZE)
  {
    //this is dangerous if a mixing of serial and this happens
    strcpy(&(cmdbuffer[bufindw][0]),cmd);
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("enqueing \"");
    SERIAL_ECHO(cmdbuffer[bufindw]);
    SERIAL_ECHOLNPGM("\"");
    bufindw= (bufindw + 1)%BUFSIZE;
    buflen += 1;
  }
}

void enquecommand_P(const char *cmd)
{
  if(buflen < BUFSIZE)
  {
    //this is dangerous if a mixing of serial and this happens
    strcpy_P(&(cmdbuffer[bufindw][0]),cmd);
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("enqueing \"");
    SERIAL_ECHO(cmdbuffer[bufindw]);
    SERIAL_ECHOLNPGM("\"");
    bufindw= (bufindw + 1)%BUFSIZE;
    buflen += 1;
  }
}

void setup_killpin()
{
  #if defined(KILL_PIN) && KILL_PIN > -1
    pinMode(KILL_PIN,INPUT);
    WRITE(KILL_PIN,HIGH);
  #endif
}

void setup_photpin()
{
  #if defined(PHOTOGRAPH_PIN) && PHOTOGRAPH_PIN > -1
    SET_OUTPUT(PHOTOGRAPH_PIN);
    WRITE(PHOTOGRAPH_PIN, LOW);
  #endif
}

void setup_extruder_on_off_pin()
	{
	#if defined(EXTRUDER_MOTOR_ON_OFF_PIN) && EXTRUDER_MOTOR_ON_OFF_PIN > -1
	   SET_INPUT(EXTRUDER_MOTOR_ON_OFF_PIN);
	   WRITE(EXTRUDER_MOTOR_ON_OFF_PIN,HIGH);  //enable high pullup for input pin
	#endif
	}

void setup_powerhold()
{
  #if defined(SUICIDE_PIN) && SUICIDE_PIN > -1
    SET_OUTPUT(SUICIDE_PIN);
    WRITE(SUICIDE_PIN, HIGH);
  #endif
  #if defined(PS_ON_PIN) && PS_ON_PIN > -1
    SET_OUTPUT(PS_ON_PIN);
	#if defined(PS_DEFAULT_OFF)
	  WRITE(PS_ON_PIN, PS_ON_ASLEEP);
    #else
	  WRITE(PS_ON_PIN, PS_ON_AWAKE);
	#endif
  #endif
}

void suicide()
{
  #if defined(SUICIDE_PIN) && SUICIDE_PIN > -1
    SET_OUTPUT(SUICIDE_PIN);
    WRITE(SUICIDE_PIN, LOW);
  #endif
}

void servo_init()
{
  #if (NUM_SERVOS >= 1) && defined(SERVO0_PIN) && (SERVO0_PIN > -1)
    servos[0].attach(SERVO0_PIN);
  #endif
  #if (NUM_SERVOS >= 2) && defined(SERVO1_PIN) && (SERVO1_PIN > -1)
    servos[1].attach(SERVO1_PIN);
  #endif
  #if (NUM_SERVOS >= 3) && defined(SERVO2_PIN) && (SERVO2_PIN > -1)
    servos[2].attach(SERVO2_PIN);
  #endif
  #if (NUM_SERVOS >= 4) && defined(SERVO3_PIN) && (SERVO3_PIN > -1)
    servos[3].attach(SERVO3_PIN);
  #endif
  #if (NUM_SERVOS >= 5)
    #error "TODO: enter initalisation code for more servos"
  #endif

  // Set position of Servo Endstops that are defined
  #ifdef SERVO_ENDSTOPS
  for(int8_t i = 0; i < 3; i++)
  {
    if(servo_endstops[i] > -1) {
      servos[servo_endstops[i]].write(servo_endstop_angles[i * 2 + 1]);
    }
  }
  #endif

  #if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
  delay(PROBE_SERVO_DEACTIVATION_DELAY);
  servos[servo_endstops[Z_AXIS]].detach();
  #endif
}

void setup()
{
  
  setup_killpin();
  setup_powerhold();
  MYSERIAL.begin(BAUDRATE);
  // NOTE: this firmware branch uses custom serial abstraction (MSerial/MYSERIAL).
  // UART1 for ESP32 is reserved in pinout, but its init is deferred until dedicated
  // serial implementation is added for this codebase.
  SERIAL_PROTOCOLLNPGM("start");
  SERIAL_ECHO_START;

  // Check startup - does nothing if bootloader sets MCUSR to 0
  byte mcu = MCUSR;
  if(mcu & 1) SERIAL_ECHOLNPGM(MSG_POWERUP);
  if(mcu & 2) SERIAL_ECHOLNPGM(MSG_EXTERNAL_RESET);
  if(mcu & 4) SERIAL_ECHOLNPGM(MSG_BROWNOUT_RESET);
  if(mcu & 8) SERIAL_ECHOLNPGM(MSG_WATCHDOG_RESET);
  if(mcu & 32) SERIAL_ECHOLNPGM(MSG_SOFTWARE_RESET);
  MCUSR=0;

  SERIAL_ECHOPGM(MSG_MARLIN);
  SERIAL_ECHOLNPGM(VERSION_STRING);
  #ifdef STRING_VERSION_CONFIG_H
    #ifdef STRING_CONFIG_H_AUTHOR
      SERIAL_ECHO_START;
      SERIAL_ECHOPGM(MSG_CONFIGURATION_VER);
      SERIAL_ECHOPGM(STRING_VERSION_CONFIG_H);
      SERIAL_ECHOPGM(MSG_AUTHOR);
      SERIAL_ECHOLNPGM(STRING_CONFIG_H_AUTHOR);
      SERIAL_ECHOPGM("Compiled: ");
      SERIAL_ECHOLNPGM(__DATE__);
    #endif
  #endif
  SERIAL_ECHO_START;
  SERIAL_ECHOPGM(MSG_FREE_MEMORY);
  SERIAL_ECHO(freeMemory());
  SERIAL_ECHOPGM(MSG_PLANNER_BUFFER_BYTES);
  SERIAL_ECHOLN((int)sizeof(block_t)*BLOCK_BUFFER_SIZE);
  for(int8_t i = 0; i < BUFSIZE; i++)
  {
    fromsd[i] = false;
  }

  // loads data from EEPROM if available else uses defaults (and resets step acceleration rate)
#ifdef EEPROM_SETTINGS
  Config_RetrieveSettings(false); /* no restaurar objetivo hotend al encender; usar Cargar/M501 */
#else
  Config_ResetDefault();
#endif
  fr3d_gwid_init();

  tp_init();    // Initialize temperature loop
#if defined(EEPROM_SETTINGS) && !defined(DELTA)
  if (target_temperature[0] > 0)
    setWatch();
#endif
  plan_init();  // Initialize planner;
  watchdog_init();
  st_init();    // Initialize stepper, this enables interrupts!
  setup_photpin();
  servo_init();
  setup_extruder_on_off_pin(); //FMM initialize pin to shut down/start up extruder motor.
  lcd_init();
  _delay_ms(1000);	// wait 1sec to display the splash screen

  #if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1
    SET_OUTPUT(CONTROLLERFAN_PIN); //Set pin used for driver cooling fan
  #endif

  #ifdef DIGIPOT_I2C
    digipot_i2c_init();
  #endif
    
  #if BEEPER > 0
    SET_OUTPUT(BEEPER);
  #endif
}

static unsigned long encoderDownTime = -1;

bool encoderClicked = false;
bool encoderLongPressed = false;

void loop()
{

  encoderClicked = false;
  encoderLongPressed = false;

  unsigned long encoderMillis = millis();

  if (lcd_clicked()) {
    if (encoderDownTime == -1) {
      encoderDownTime = encoderMillis;
    }

    if (encoderMillis - encoderDownTime > 2000) {
      encoderLongPressed = true;
    }

  } else {
    if (encoderDownTime != -1) {
      if (millis() - encoderDownTime < 1000) {
        encoderClicked = true;
      } 
      encoderDownTime = -1;
    }
  }


  beepSequenceLoop();  

  if(buflen < (BUFSIZE-1))
    get_command();
  #ifdef SDSUPPORT
  card.checkautostart(false);
  #endif
  if(buflen)
  {
    #ifdef SDSUPPORT
      if(card.saving)
      {
        if(strstr_P(cmdbuffer[bufindr], PSTR("M29")) == NULL)
        {
          card.write_command(cmdbuffer[bufindr]);
          if(card.logging)
          {
            process_commands();
          }
          else
          {
            SERIAL_PROTOCOLLNPGM(MSG_OK);
          }
        }
        else
        {
          card.closefile();
          SERIAL_PROTOCOLLNPGM(MSG_FILE_SAVED);
        }
      }
      else
      {
        process_commands();
      }
    #else
      process_commands();
    #endif //SDSUPPORT
    buflen = (buflen-1);
    bufindr = (bufindr + 1)%BUFSIZE;
  }
  //check heater every n milliseconds
  manage_heater();
  manage_inactivity();
  checkHitEndstops();
  fr3d_diam_poll_samples();
  lcd_update(encoderClicked, encoderLongPressed);

  fr3d_csv_telemetry_poll();

  //FMM calculate max, min, and average filament width

  timebuff=millis();
  deltatime = timebuff-lasttime;  //calculate delta times
  lasttime = timebuff;  //keep track of last sample time
  

  if(extrude_length < fil_length_cutoff)
	  winderSpeed = default_winder_speed*255/winder_rpm_factor;  //keep winder on all the time unless at end of spool
  

  
  
  
  if((extrude_status & (ES_STATS_SET))  == (ES_STATS_SET) ) //check whether we should collect stats on filament width
	  {
	  
	  sum_measured_filament_width = sum_measured_filament_width+current_filwidth;
	  n_measured_filament_width = n_measured_filament_width + 1.0;
	  avg_measured_filament_width=sum_measured_filament_width/n_measured_filament_width;
	  max_measured_filament_width=max(max_measured_filament_width,current_filwidth);
	  if(round(min_measured_filament_width)==0)
		min_measured_filament_width=current_filwidth;
	  min_measured_filament_width=min(min_measured_filament_width,current_filwidth);
	  extrude_length=extrude_length+puller_increment;
	  

	  if(extrude_length >= fil_length_cutoff){  //check whether we extruded enough filament
		  setTargetHotend0(0);
		  winderSpeed = 0;
		  digitalWrite(CONTROLLERFAN_PIN, 0);  //stop Fan
		  extrude_status= extrude_status & ES_ENABLE_CLEAR;  //update extrude_status to shut down extruder
		  extrude_status= extrude_status & ES_STATS_CLEAR;  //shut down statistics
		  timeremaining=0;
		  LCD_MESSAGEPGM(MSG_EXTRUDE_COMPLETE);
      int beepSequence[5] = {1000, 500, 1000, 500, 1000};
      setBeepSequence(beepSequence, 5);

	  } else {
		  
		  if(puller_feedrate>0)
		  timeremaining = (fil_length_cutoff-extrude_length)/puller_feedrate*1000;
		  
	  }
		  
	  }
	// puller stop when filament stuck for more than 30 secs
  if  ((extrude_status & ES_AUTO_SET) > 0 && !(extrude_length >= fil_length_cutoff)) {
    
    if (current_filwidth < sensorRunoutMin || current_filwidth > sensorRunoutMax) {
      // MYSERIAL.println("sensor runout detected");
      if (runoutStartTimeMS == 0) {
        // MYSERIAL.println("starting timeout");
        runoutStartTimeMS = millis();
      }
    } else {
      runoutStartTimeMS = 0;
      // MYSERIAL.println("resetting timeout");
    }

    if (runoutStartTimeMS != 0) {
      unsigned long elapsedTimeMS = millis() - runoutStartTimeMS;
      // MYSERIAL.print("elapsed time: ");
      // MYSERIAL.println(elapsedTimeMS, DEC);
      if (elapsedTimeMS > 30000) {
        LCD_ALERTMESSAGEPGM(MSG_sensor_runout);
        int beepSequence[5] = {1000, 500, 1000, 500, 1000};
        setBeepSequence(beepSequence, 5);
        while(1)
        {
          disable_heater();
          disable_x();
          disable_y();
          disable_z();
          disable_e0();
          
          manage_heater();
          lcd_update(encoderClicked, encoderLongPressed);
          beepSequenceLoop();
        }
      }
    }
  } else {
    runoutStartTimeMS = 0;
    // MYSERIAL.println("not watching filwidth");
  }
    
// stop and cooldown when heated and extruder does not run for more than 20 minutes-safety cooldown
  if  ((extrude_status & ES_HOT_SET) > 0)  {
    
    if (extruder_rpm < 1) {
      // MYSERIAL.println("sensor runout detected");
      if (safetycooldownStartTimeMS == 0) {
        // MYSERIAL.println("starting timeout");
        safetycooldownStartTimeMS = millis();
      }
    } else {
      safetycooldownStartTimeMS = 0;
      // MYSERIAL.println("resetting timeout");
    }

    if (safetycooldownStartTimeMS != 0) {
      unsigned long elapsedTimeMS = millis() - safetycooldownStartTimeMS;
      // MYSERIAL.print("elapsed time: ");
      // MYSERIAL.println(elapsedTimeMS, DEC);
      if (elapsedTimeMS > 3000000) {
        LCD_ALERTMESSAGEPGM(MSG_SAFETY_COOLDOWN);
        int beepSequence[5] = {1000, 500, 1000, 500, 1000};
        setBeepSequence(beepSequence, 5);
        while(1)
        {
          disable_heater();
          disable_x();
          disable_y();
          disable_z();
          disable_e0();
          
          manage_heater();
          lcd_update(encoderClicked, encoderLongPressed);
          beepSequenceLoop();
        }
      }
    }
  } else {
    safetycooldownStartTimeMS = 0;
    // MYSERIAL.println("not watching filwidth");
  }

  float extruderTemp = degHotend(active_extruder);

  
  //FMM generate extruder motion based on LCD inputs
  #if defined(EXTRUDER_MOTOR_ON_OFF_PIN) && EXTRUDER_MOTOR_ON_OFF_PIN > -1
  if (READ(EXTRUDER_MOTOR_ON_OFF_PIN))  //check if pin is high (=off)
	  extrude_status=extrude_status & ES_SWITCH_CLEAR;
  else
	  extrude_status= extrude_status | ES_SWITCH_SET;
  #else
  extrude_status = extrude_status | ES_SWITCH_SET;  // sin interruptor físico: equivalente a "motor habilitado"
  #endif
  
  if(extruderTemp > EXTRUDE_MINTEMP)  //check if extruder at min heated temp
	  extrude_status=extrude_status | ES_HOT_SET;
  else
	  {
	  extrude_status=extrude_status & ES_HOT_CLEAR;
	  extrude_status=extrude_status & ES_TEMP_CLEAR;
	  }
 
  
 
  if (extruderTemp > FAN_ACTIVE_TEMP) {
    digitalWrite(CONTROLLERFAN2_PIN, 1);  //start Fan
  } else if (extruderTemp < FAN_INACTIVE_TEMP) {
    digitalWrite(CONTROLLERFAN2_PIN, 0);  //stop Fan
  }

		  
  if(((extruderTemp >= (degTargetHotend(active_extruder)-TEMP_WINDOW)) && (extruderTemp <= (degTargetHotend(active_extruder)+TEMP_WINDOW)))  && ((extrude_status & ES_TEMP_SET)==0))  //check if extruder at or near setpoint
  	  {
	  extrude_status=extrude_status | ES_TEMP_SET;
    int beepSequence[5] = {1000, 500, 1000, 500, 1000};
    setBeepSequence(beepSequence, 5);
	  LCD_MESSAGEPGM(MSG_HEATING_COMPLETE);
  	  }
  	
  if (extrude_status && ES_TEMP_SET > 0 && extrude_status && ES_ENABLE_CLEAR_NO_AUTO > 0 && encoderLongPressed && injectionModeStartMillis == -1) {
    injectionModeStartMillis = millis();
    puller_feedrate = 0;
	  extrude_status=extrude_status|ES_ENABLE_SET; 
    LCD_MESSAGEPGM(MSG_INJECTION_MODE);
  }

  if (injectionModeStartMillis != -1) {

    unsigned long elapsedTimeMS = millis() - injectionModeStartMillis;
    unsigned long injectionTimeMillis = (unsigned long) injectionTimeSeconds * 1000;
    if (elapsedTimeMS > injectionTimeMillis) {
      injectionModeStartMillis = -1;
      extrude_status=extrude_status & ES_ENABLE_CLEAR_NO_AUTO;
      LCD_MESSAGEPGM(MSG_HEATING_COMPLETE);
    }
  }
  
  if((extrude_status & ES_ENABLE_SET) >0){
	  
	  
	  
	  
	  
	 //old 
	 // feedrate=20*60;
	 // extruder_increment=feedmultiply/100.0;
	 // puller_increment=extruder_increment*pullermultiply/1000.0;
	  
	  //extruder_feedrate=feedrate*extruder_increment/60.0;
	  //puller_feedrate=extruder_feedrate*pullermultiply/1000.0;
	  
	 //new
	  extruder_increment=extruder_rpm_set/EXTRUDER_RPM_MAX*8;  //make extruder increment 1 unit for max RPM and scale down as RPM input decreases *8 for more duration (removes pulsing)
	  extruder_feedrate=extruder_rpm_set/0.6;
	  puller_increment=puller_feedrate*0.6/EXTRUDER_RPM_MAX*8;  //make puller increment vary to control it *8 for more duration (removes pulsing)
	  
	  
	  
	  
	  
	  //calculate move  - always scale step size to feedmultiply (was previously fix step side of 0.1)
	  destination[P_AXIS] = puller_increment + current_position[P_AXIS]; //puller
	  

	  	  
	  if((extrude_status & ES_HOT_SET) && (extrude_status & ES_SWITCH_SET))  //check that extruder is at temp and switch in on
		  {//calculate move  - always scale step size to feedmultiply (was previously fix step side of 0.1)
		  destination[E_AXIS] = extruder_increment + current_position[E_AXIS];  //extruder
		  //extruder_rpm=extruder_feedrate*0.6;  //convert to rpm
		  extruder_rpm=extruder_rpm_set;
		  feedrate=extruder_feedrate;
		  duration = duration + deltatime;  //keep track of extrusion run time
		  }
	  else
		  {
		  extruder_rpm=0.0;
		  feedrate=puller_feedrate;
		  }
	  
	  
	  
	  //calculate PID - delta is spatial, not time
	  if((extrude_status & (ES_AUTO_SET | ES_HOT_SET | ES_SWITCH_SET)) == (ES_AUTO_SET | ES_HOT_SET | ES_SWITCH_SET) ){  ///check for normal extrusion
	  		//  Extruder in Automatic control
	  		
		  
		  //add smith predictor here to handle dead time in filament transit
		  /*
		  //calculate model of diameter (low pass filtered version of gain* extruder_RPM/filament control)
		  model_out=(1.0-model_param)*model_out+model_param*(model_gain*extruder_rpm/filament_control);
		  
		  
		  //update delay based on spatial delay
		  
		  while(current_position[P_AXIS]- last_p_position > 1.0){  //check if over 1 mm passed
			  
		  // shift the delay by one
		     	for (idelay=99; idelay>0 ; idelay--)
		     		{
		     		model_delay[idelay]=model_delay[idelay-1];
		     		}
		     	// add the new model output to the delay
		     	model_delay[0]=(int)(model_out*1000);  //convert the model out of 0-3.0 mm to an int in range 0-3000.
		     	
		     	last_p_position=last_p_position+1.0;
		  }
		  
		  //calculate difference between measured width and delayed model and filter   	
		  smith_filter_out=(1.0-smith_filter_param)*smith_filter_out+smith_filter_param*(current_filwidth-model_delay[99]/1000.0);
		     	
		  //update the error term to include the model
		  
		  
		  pid_input= model_out+smith_filter_out;
		 */ 
		 pid_input = current_filwidth;
		
			
				  pid_error_fwidth = filament_width_desired - pid_input;
				  pTerm_fwidth = puller_feedrate_last - fwidthKp * pid_error_fwidth;
				  
				  /*
				  if(pTerm_fwidth>PULLER_PID_MAX_LIMIT){
					  filament_control=PULLER_PID_MAX_LIMIT;
					  pid_reset_fwidth = true;  
				  } else if(pTerm_fwidth<PULLER_PID_MIN_LIMIT){
					  filament_control=PULLER_PID_MIN_LIMIT;
					  pid_reset_fwidth = true;
				  }else{
				  
					  if(pid_reset_fwidth== true){
						  dia_iState_fwidth=0.0;
						  pid_reset_fwidth = false;
					  }
				  
				  */

         float min_feedrate = PULLER_RPM_MIN / (60.0/pcirc);
         float max_feedrate = PULLER_RPM_MAX / (60.0/pcirc);
				  
				  if((filament_control<max_feedrate && pid_error_fwidth<0) || (filament_control>min_feedrate && pid_error_fwidth>0))
					  {
					  dia_iState_fwidth += pid_error_fwidth* puller_increment; //use spatial dT=puller_increment
					  dia_iState_fwidth = constrain(dia_iState_fwidth, -PULLER_PID_INTEGRATOR_WIND_LIMIT, PULLER_PID_INTEGRATOR_WIND_LIMIT);
					  }
				  iTerm_fwidth = fwidthKi * dia_iState_fwidth;  
		
				  //K1 defined in Configuration.h in the PID settings
				  #define K2 (1.0-K1)
				  dTerm_fwidth= (fwidthKd/puller_increment * (pid_input - dia_dState_fwidth))*K2 + (K1 * dTerm_fwidth);  //use spatial dT=puller_increment
				  
				  filament_control = constrain(pTerm_fwidth - iTerm_fwidth + dTerm_fwidth, min_feedrate, max_feedrate);
				  
				  dia_dState_fwidth = pid_input;
			
				  
	  		  puller_feedrate=filament_control;
	  		  
	  		  
	  		  
	  	  } else {
	  		  puller_feedrate_last=puller_feedrate;  //keep track of last puller_feedrate when running manual control
	  		  dia_iState_fwidth=0;  //reset the integral
	  	  }
	  		  
	  
	  
	  
	  
	  
	  //send move
	  previous_millis_cmd = millis();  //refresh the kill watchdog timer
	  plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate, active_extruder);  //FMM added P_AXIS
	  current_position[E_AXIS]=destination[E_AXIS];
	  current_position[P_AXIS]=destination[P_AXIS];
  }
  else{
	  extruder_increment=0;
	  extruder_feedrate=0;
	  puller_increment=0;
	  puller_feedrate=0;
	  extruder_rpm=0;
  }
 
  
  
	
  
  
  
}

/** Numeracion Marlin N<num> solo si N va al inicio (tras espacios) seguido de digito.
 *  strchr('N') en toda la linea disparaba falso positivo con el token compacto PNAO (P-N-A-O). */
static bool line_starts_with_host_line_number(const char *buf)
{
  const char *p = buf;
  while (*p == ' ' || *p == '\t') p++;
  char c0 = *p;
  if (c0 >= 'a' && c0 <= 'z') c0 = (char)(c0 - 'a' + 'A');
  return (c0 == 'N' && p[1] >= '0' && p[1] <= '9');
}

void get_command()
{
  while( MYSERIAL.available() > 0  && buflen < BUFSIZE) {
    serial_char = MYSERIAL.read();
    if(serial_char == '\n' ||
       serial_char == '\r' ||
       (serial_char == ':' && comment_mode == false) ||
       serial_count >= (MAX_CMD_SIZE - 1) )
    {
      if(!serial_count) { //if empty line
        comment_mode = false; //for new command
        return;
      }
      cmdbuffer[bufindw][serial_count] = 0; //terminate string
      if(!comment_mode){
        comment_mode = false; //for new command
        fromsd[bufindw] = false;
        if(line_starts_with_host_line_number(cmdbuffer[bufindw]))
        {
          strchr_pointer = strchr(cmdbuffer[bufindw], 'N');
          if (strchr_pointer == NULL)
            strchr_pointer = strchr(cmdbuffer[bufindw], 'n');
          gcode_N = (strtol(&cmdbuffer[bufindw][strchr_pointer - cmdbuffer[bufindw] + 1], NULL, 10));
          if(gcode_N != gcode_LastN+1 && (strstr_P(cmdbuffer[bufindw], PSTR("M110")) == NULL) ) {
            SERIAL_ERROR_START;
            SERIAL_ERRORPGM(MSG_ERR_LINE_NO);
            SERIAL_ERRORLN(gcode_LastN);
            //Serial.println(gcode_N);
            FlushSerialRequestResend();
            serial_count = 0;
            return;
          }

          if(strchr(cmdbuffer[bufindw], '*') != NULL)
          {
            byte checksum = 0;
            byte count = 0;
            while(cmdbuffer[bufindw][count] != '*') checksum = checksum^cmdbuffer[bufindw][count++];
            strchr_pointer = strchr(cmdbuffer[bufindw], '*');

            if( (int)(strtod(&cmdbuffer[bufindw][strchr_pointer - cmdbuffer[bufindw] + 1], NULL)) != checksum) {
              SERIAL_ERROR_START;
              SERIAL_ERRORPGM(MSG_ERR_CHECKSUM_MISMATCH);
              SERIAL_ERRORLN(gcode_LastN);
              FlushSerialRequestResend();
              serial_count = 0;
              return;
            }
            //if no errors, continue parsing
          }
          else
          {
            SERIAL_ERROR_START;
            SERIAL_ERRORPGM(MSG_ERR_NO_CHECKSUM);
            SERIAL_ERRORLN(gcode_LastN);
            FlushSerialRequestResend();
            serial_count = 0;
            return;
          }

          gcode_LastN = gcode_N;
          //if no errors, continue parsing
        }
        else  // if we don't receive 'N' but still see '*'
        {
          if((strchr(cmdbuffer[bufindw], '*') != NULL))
          {
            SERIAL_ERROR_START;
            SERIAL_ERRORPGM(MSG_ERR_NO_LINENUMBER_WITH_CHECKSUM);
            SERIAL_ERRORLN(gcode_LastN);
            serial_count = 0;
            return;
          }
        }
        if((strchr(cmdbuffer[bufindw], 'G') != NULL)){
          strchr_pointer = strchr(cmdbuffer[bufindw], 'G');
          switch((int)((strtod(&cmdbuffer[bufindw][strchr_pointer - cmdbuffer[bufindw] + 1], NULL)))){
          case 0:
          case 1:
          case 2:
          case 3:
            if(Stopped == false) { // If printer is stopped by an error the G[0-3] codes are ignored.
          #ifdef SDSUPPORT
              if(card.saving)
                break;
          #endif //SDSUPPORT
              SERIAL_PROTOCOLLNPGM(MSG_OK);
            }
            else {
              SERIAL_ERRORLNPGM(MSG_ERR_STOPPED);
              LCD_MESSAGEPGM(MSG_STOPPED);
            }
            break;
          default:
            break;
          }

        }
        bufindw = (bufindw + 1)%BUFSIZE;
        buflen += 1;
      }
      serial_count = 0; //clear buffer
    }
    else
    {
      if(serial_char == ';') comment_mode = true;
      if(!comment_mode) cmdbuffer[bufindw][serial_count++] = serial_char;
    }
  }
  #ifdef SDSUPPORT
  if(!card.sdprinting || serial_count!=0){
    return;
  }

  //'#' stops reading from SD to the buffer prematurely, so procedural macro calls are possible
  // if it occurs, stop_buffering is triggered and the buffer is ran dry.
  // this character _can_ occur in serial com, due to checksums. however, no checksums are used in SD printing

  static bool stop_buffering=false;
  if(buflen==0) stop_buffering=false;

  while( !card.eof()  && buflen < BUFSIZE && !stop_buffering) {
    int16_t n=card.get();
    serial_char = (char)n;
    if(serial_char == '\n' ||
       serial_char == '\r' ||
       (serial_char == '#' && comment_mode == false) ||
       (serial_char == ':' && comment_mode == false) ||
       serial_count >= (MAX_CMD_SIZE - 1)||n==-1)
    {
      if(card.eof()){
        SERIAL_PROTOCOLLNPGM(MSG_FILE_PRINTED);
        stoptime=millis();
        char time[30];
        unsigned long t=(stoptime-starttime)/1000;
        int hours, minutes;
        minutes=(t/60)%60;
        hours=t/60/60;
        sprintf_P(time, PSTR("%i hours %i minutes"),hours, minutes);
        SERIAL_ECHO_START;
        SERIAL_ECHOLN(time);
        lcd_setstatus(time);
        card.printingHasFinished();
        card.checkautostart(true);

      }
      if(serial_char=='#')
        stop_buffering=true;

      if(!serial_count)
      {
        comment_mode = false; //for new command
        return; //if empty line
      }
      cmdbuffer[bufindw][serial_count] = 0; //terminate string
//      if(!comment_mode){
        fromsd[bufindw] = true;
        buflen += 1;
        bufindw = (bufindw + 1)%BUFSIZE;
//      }
      comment_mode = false; //for new command
      serial_count = 0; //clear buffer
    }
    else
    {
      if(serial_char == ';') comment_mode = true;
      if(!comment_mode) cmdbuffer[bufindw][serial_count++] = serial_char;
    }
  }

  #endif //SDSUPPORT

}


float code_value()
{
  return (strtod(&cmdbuffer[bufindr][strchr_pointer - cmdbuffer[bufindr] + 1], NULL));
}

long code_value_long()
{
  return (strtol(&cmdbuffer[bufindr][strchr_pointer - cmdbuffer[bufindr] + 1], NULL, 10));
}

bool code_seen(char code)
{
  strchr_pointer = strchr(cmdbuffer[bufindr], code);
  return (strchr_pointer != NULL);  //Return True if a character was found
}

#define DEFINE_PGM_READ_ANY(type, reader)       \
    static inline type pgm_read_any(const type *p)  \
    { return pgm_read_##reader##_near(p); }

DEFINE_PGM_READ_ANY(float,       float);
DEFINE_PGM_READ_ANY(signed char, byte);

#define XYZ_CONSTS_FROM_CONFIG(type, array, CONFIG) \
static const PROGMEM type array##_P[3] =        \
    { X_##CONFIG, Y_##CONFIG, Z_##CONFIG };     \
static inline type array(int axis)          \
    { return pgm_read_any(&array##_P[axis]); }

XYZ_CONSTS_FROM_CONFIG(float, base_min_pos,    MIN_POS);
XYZ_CONSTS_FROM_CONFIG(float, base_max_pos,    MAX_POS);
XYZ_CONSTS_FROM_CONFIG(float, base_home_pos,   HOME_POS);
XYZ_CONSTS_FROM_CONFIG(float, max_length,      MAX_LENGTH);
XYZ_CONSTS_FROM_CONFIG(float, home_retract_mm, HOME_RETRACT_MM);
XYZ_CONSTS_FROM_CONFIG(signed char, home_dir,  HOME_DIR);

#ifdef DUAL_X_CARRIAGE
  #if EXTRUDERS == 1 || defined(COREXY) \
      || !defined(X2_ENABLE_PIN) || !defined(X2_STEP_PIN) || !defined(X2_DIR_PIN) \
      || !defined(X2_HOME_POS) || !defined(X2_MIN_POS) || !defined(X2_MAX_POS) \
      || !defined(X_MAX_PIN) || X_MAX_PIN < 0
    #error "Missing or invalid definitions for DUAL_X_CARRIAGE mode."
  #endif
  #if X_HOME_DIR != -1 || X2_HOME_DIR != 1
    #error "Please use canonical x-carriage assignment" // the x-carriages are defined by their homing directions
  #endif

#define DXC_FULL_CONTROL_MODE 0
#define DXC_AUTO_PARK_MODE    1
#define DXC_DUPLICATION_MODE  2
static int dual_x_carriage_mode = DEFAULT_DUAL_X_CARRIAGE_MODE;

static float x_home_pos(int extruder) {
  if (extruder == 0)
    return base_home_pos(X_AXIS) + add_homeing[X_AXIS];
  else
    // In dual carriage mode the extruder offset provides an override of the
    // second X-carriage offset when homed - otherwise X2_HOME_POS is used.
    // This allow soft recalibration of the second extruder offset position without firmware reflash
    // (through the M218 command).
    return (extruder_offset[X_AXIS][1] > 0) ? extruder_offset[X_AXIS][1] : X2_HOME_POS;
}

static int x_home_dir(int extruder) {
  return (extruder == 0) ? X_HOME_DIR : X2_HOME_DIR;
}

static float inactive_extruder_x_pos = X2_MAX_POS; // used in mode 0 & 1
static bool active_extruder_parked = false; // used in mode 1 & 2
static float raised_parked_position[NUM_AXIS]; // used in mode 1
static unsigned long delayed_move_time = 0; // used in mode 1
static float duplicate_extruder_x_offset = DEFAULT_DUPLICATION_X_OFFSET; // used in mode 2
static float duplicate_extruder_temp_offset = 0; // used in mode 2
bool extruder_duplication_enabled = false; // used in mode 2
#endif //DUAL_X_CARRIAGE

static void axis_is_at_home(int axis) {
#ifdef DUAL_X_CARRIAGE
  if (axis == X_AXIS) {
    if (active_extruder != 0) {
      current_position[X_AXIS] = x_home_pos(active_extruder);
      min_pos[X_AXIS] =          X2_MIN_POS;
      max_pos[X_AXIS] =          max(extruder_offset[X_AXIS][1], X2_MAX_POS);
      return;
    }
    else if (dual_x_carriage_mode == DXC_DUPLICATION_MODE && active_extruder == 0) {
      current_position[X_AXIS] = base_home_pos(X_AXIS) + add_homeing[X_AXIS];
      min_pos[X_AXIS] =          base_min_pos(X_AXIS) + add_homeing[X_AXIS];
      max_pos[X_AXIS] =          min(base_max_pos(X_AXIS) + add_homeing[X_AXIS],
                                  max(extruder_offset[X_AXIS][1], X2_MAX_POS) - duplicate_extruder_x_offset);
      return;
    }
  }
#endif
  current_position[axis] = base_home_pos(axis) + add_homeing[axis];
  min_pos[axis] =          base_min_pos(axis) + add_homeing[axis];
  max_pos[axis] =          base_max_pos(axis) + add_homeing[axis];
}

#ifdef ENABLE_AUTO_BED_LEVELING
#ifdef AUTO_BED_LEVELING_GRID
static void set_bed_level_equation_lsq(double *plane_equation_coefficients)
{
    vector_3 planeNormal = vector_3(-plane_equation_coefficients[0], -plane_equation_coefficients[1], 1);
    planeNormal.debug("planeNormal");
    plan_bed_level_matrix = matrix_3x3::create_look_at(planeNormal);
    //bedLevel.debug("bedLevel");

    //plan_bed_level_matrix.debug("bed level before");
    //vector_3 uncorrected_position = plan_get_position_mm();
    //uncorrected_position.debug("position before");

    vector_3 corrected_position = plan_get_position();
//    corrected_position.debug("position after");
    current_position[X_AXIS] = corrected_position.x;
    current_position[Y_AXIS] = corrected_position.y;
    current_position[Z_AXIS] = corrected_position.z;

    // but the bed at 0 so we don't go below it.
    current_position[Z_AXIS] = zprobe_zoffset; // in the lsq we reach here after raising the extruder due to the loop structure

    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], current_position[P_AXIS]);
}

#else // not AUTO_BED_LEVELING_GRID

static void set_bed_level_equation_3pts(float z_at_pt_1, float z_at_pt_2, float z_at_pt_3) {

    plan_bed_level_matrix.set_to_identity();

    vector_3 pt1 = vector_3(ABL_PROBE_PT_1_X, ABL_PROBE_PT_1_Y, z_at_pt_1);
    vector_3 pt2 = vector_3(ABL_PROBE_PT_2_X, ABL_PROBE_PT_2_Y, z_at_pt_2);
    vector_3 pt3 = vector_3(ABL_PROBE_PT_3_X, ABL_PROBE_PT_3_Y, z_at_pt_3);

    vector_3 from_2_to_1 = (pt1 - pt2).get_normal();
    vector_3 from_2_to_3 = (pt3 - pt2).get_normal();
    vector_3 planeNormal = vector_3::cross(from_2_to_1, from_2_to_3).get_normal();
    planeNormal = vector_3(planeNormal.x, planeNormal.y, abs(planeNormal.z));

    plan_bed_level_matrix = matrix_3x3::create_look_at(planeNormal);

    vector_3 corrected_position = plan_get_position();
    current_position[X_AXIS] = corrected_position.x;
    current_position[Y_AXIS] = corrected_position.y;
    current_position[Z_AXIS] = corrected_position.z;

    // put the bed at 0 so we don't go below it.
    current_position[Z_AXIS] = zprobe_zoffset;

    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);

}

#endif // AUTO_BED_LEVELING_GRID

static void run_z_probe() {
    plan_bed_level_matrix.set_to_identity();
    feedrate = homing_feedrate[Z_AXIS];

    // move down until you find the bed
    float zPosition = -10;
    plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], zPosition, current_position[E_AXIS], current_position[P_AXIS],feedrate/60, active_extruder);
    st_synchronize();

        // we have to let the planner know where we are right now as it is not where we said to go.
    zPosition = st_get_position_mm(Z_AXIS);
    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], zPosition, current_position[E_AXIS]);

    // move up the retract distance
    zPosition += home_retract_mm(Z_AXIS);
    plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], zPosition, current_position[E_AXIS], current_position[P_AXIS],feedrate/60, active_extruder);
    st_synchronize();

    // move back down slowly to find bed
    feedrate = homing_feedrate[Z_AXIS]/4;
    zPosition -= home_retract_mm(Z_AXIS) * 2;
    plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], zPosition, current_position[E_AXIS], current_position[P_AXIS],feedrate/60, active_extruder);
    st_synchronize();

    current_position[Z_AXIS] = st_get_position_mm(Z_AXIS);
    // make sure the planner knows where we are as it may be a bit different than we last said to move to
    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS],current_position[P_AXIS]);
}

static void do_blocking_move_to(float x, float y, float z) {
    float oldFeedRate = feedrate;

    feedrate = XY_TRAVEL_SPEED;

    current_position[X_AXIS] = x;
    current_position[Y_AXIS] = y;
    current_position[Z_AXIS] = z;
    plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS],current_position[P_AXIS], feedrate/60, active_extruder);
    st_synchronize();

    feedrate = oldFeedRate;
}

static void do_blocking_move_relative(float offset_x, float offset_y, float offset_z) {
    do_blocking_move_to(current_position[X_AXIS] + offset_x, current_position[Y_AXIS] + offset_y, current_position[Z_AXIS] + offset_z);
}

static void setup_for_endstop_move() {
    saved_feedrate = feedrate;
    saved_feedmultiply = feedmultiply;
    feedmultiply = 100;
    previous_millis_cmd = millis();

    enable_endstops(true);
}

static void clean_up_after_endstop_move() {
#ifdef ENDSTOPS_ONLY_FOR_HOMING
    enable_endstops(false);
#endif

    feedrate = saved_feedrate;
    feedmultiply = saved_feedmultiply;
    previous_millis_cmd = millis();
}

static void engage_z_probe() {
    // Engage Z Servo endstop if enabled
    #ifdef SERVO_ENDSTOPS
    if (servo_endstops[Z_AXIS] > -1) {
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
        servos[servo_endstops[Z_AXIS]].attach(0);
#endif
        servos[servo_endstops[Z_AXIS]].write(servo_endstop_angles[Z_AXIS * 2]);
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
        delay(PROBE_SERVO_DEACTIVATION_DELAY);
        servos[servo_endstops[Z_AXIS]].detach();
#endif
    }
    #endif
}

static void retract_z_probe() {
    // Retract Z Servo endstop if enabled
    #ifdef SERVO_ENDSTOPS
    if (servo_endstops[Z_AXIS] > -1) {
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
        servos[servo_endstops[Z_AXIS]].attach(0);
#endif
        servos[servo_endstops[Z_AXIS]].write(servo_endstop_angles[Z_AXIS * 2 + 1]);
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
        delay(PROBE_SERVO_DEACTIVATION_DELAY);
        servos[servo_endstops[Z_AXIS]].detach();
#endif
    }
    #endif
}

/// Probe bed height at position (x,y), returns the measured z value
static float probe_pt(float x, float y, float z_before) {
  // move to right place
  do_blocking_move_to(current_position[X_AXIS], current_position[Y_AXIS], z_before);
  do_blocking_move_to(x - X_PROBE_OFFSET_FROM_EXTRUDER, y - Y_PROBE_OFFSET_FROM_EXTRUDER, current_position[Z_AXIS]);

  engage_z_probe();   // Engage Z Servo endstop if available
  run_z_probe();
  float measured_z = current_position[Z_AXIS];
  retract_z_probe();

  SERIAL_PROTOCOLPGM(MSG_BED);
  SERIAL_PROTOCOLPGM(" x: ");
  SERIAL_PROTOCOL(x);
  SERIAL_PROTOCOLPGM(" y: ");
  SERIAL_PROTOCOL(y);
  SERIAL_PROTOCOLPGM(" z: ");
  SERIAL_PROTOCOL(measured_z);
  SERIAL_PROTOCOLPGM("\n");
  return measured_z;
}

#endif // #ifdef ENABLE_AUTO_BED_LEVELING

static void homeaxis(int axis) {
#define HOMEAXIS_DO(LETTER) \
  ((LETTER##_MIN_PIN > -1 && LETTER##_HOME_DIR==-1) || (LETTER##_MAX_PIN > -1 && LETTER##_HOME_DIR==1))

  if (axis==X_AXIS ? HOMEAXIS_DO(X) :
      axis==Y_AXIS ? HOMEAXIS_DO(Y) :
      axis==Z_AXIS ? HOMEAXIS_DO(Z) :
      0) {
    int axis_home_dir = home_dir(axis);
#ifdef DUAL_X_CARRIAGE
    if (axis == X_AXIS)
      axis_home_dir = x_home_dir(active_extruder);
#endif

    current_position[axis] = 0;
    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS],current_position[P_AXIS] );  //FMM added P_AXIS


    // Engage Servo endstop if enabled
    #ifdef SERVO_ENDSTOPS
      #if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
        if (axis==Z_AXIS) {
          engage_z_probe();
        }
	    else
      #endif
      if (servo_endstops[axis] > -1) {
        servos[servo_endstops[axis]].write(servo_endstop_angles[axis * 2]);
      }
    #endif

    destination[axis] = 1.5 * max_length(axis) * axis_home_dir;
    feedrate = homing_feedrate[axis];
    plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate/60, active_extruder); //FMM added P_axis
    st_synchronize();

    current_position[axis] = 0;
    plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], current_position[P_AXIS]); //FMM added P_axis
    destination[axis] = -home_retract_mm(axis) * axis_home_dir;
    plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate/60, active_extruder); //FMM added P_AXIS
    st_synchronize();

    destination[axis] = 2*home_retract_mm(axis) * axis_home_dir;
#ifdef DELTA
    feedrate = homing_feedrate[axis]/10;
#else
    feedrate = homing_feedrate[axis]/2 ;
#endif
    plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate/60, active_extruder);  //FMM added P_AXIS
    st_synchronize();
#ifdef DELTA
    // retrace by the amount specified in endstop_adj
    if (endstop_adj[axis] * axis_home_dir < 0) {
      plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS],current_position[P_AXIS]);
      destination[axis] = endstop_adj[axis];
      plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate/60, active_extruder);
      st_synchronize();
    }
#endif
    axis_is_at_home(axis);
    destination[axis] = current_position[axis];
    feedrate = 0.0;
    endstops_hit_on_purpose();
    axis_known_position[axis] = true;

    // Retract Servo endstop if enabled
    #ifdef SERVO_ENDSTOPS
      if (servo_endstops[axis] > -1) {
        servos[servo_endstops[axis]].write(servo_endstop_angles[axis * 2 + 1]);
      }
    #endif
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
    if (axis==Z_AXIS) retract_z_probe();
#endif

  }
}
#define HOMEAXIS(LETTER) homeaxis(LETTER##_AXIS)
void refresh_cmd_timeout(void)
{
  previous_millis_cmd = millis();
}

#ifdef FWRETRACT
  void retract(bool retracting) {
    if(retracting && !retracted) {
      destination[X_AXIS]=current_position[X_AXIS];
      destination[Y_AXIS]=current_position[Y_AXIS];
      destination[Z_AXIS]=current_position[Z_AXIS];
      destination[E_AXIS]=current_position[E_AXIS];
      current_position[E_AXIS]+=retract_length/volumetric_multiplier[active_extruder];
      plan_set_e_position(current_position[E_AXIS]);
      float oldFeedrate = feedrate;
      feedrate=retract_feedrate;
      retracted=true;
      prepare_move();
      current_position[Z_AXIS]-=retract_zlift;
      plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
      prepare_move();
      feedrate = oldFeedrate;
    } else if(!retracting && retracted) {
      destination[X_AXIS]=current_position[X_AXIS];
      destination[Y_AXIS]=current_position[Y_AXIS];
      destination[Z_AXIS]=current_position[Z_AXIS];
      destination[E_AXIS]=current_position[E_AXIS];
      current_position[Z_AXIS]+=retract_zlift;
      plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
      //prepare_move();
      current_position[E_AXIS]-=(retract_length+retract_recover_length)/volumetric_multiplier[active_extruder]; 
      plan_set_e_position(current_position[E_AXIS]);
      float oldFeedrate = feedrate;
      feedrate=retract_recover_feedrate;
      retracted=false;
      prepare_move();
      feedrate = oldFeedrate;
    }
  } //retract
#endif //FWRETRACT

#ifdef FR3D_SERIAL_HOST_DISABLE_GM
static bool fr3d_compact_last_error;

/** Mayúscula ASCII para comandos compactos (host acepta mayúsculas y minúsculas). */
static char fr3d_uc(char c)
{
  if (c >= 'a' && c <= 'z') return (char)(c - 'a' + 'A');
  return c;
}

/** Compara linea con palabra en mayusculas; fin de comando o espacio. */
static bool fr3d_cmd_word(const char *p, const char *uword)
{
  for (; *uword; ++p, ++uword) {
    if (fr3d_uc(*p) != *uword)
      return false;
  }
  /* \r puede quedar antes del \0 según el host (CRLF). */
  return *p == '\0' || *p == ' ' || *p == '\t' || *p == '\r';
}

/** Compara prefijo de comando (sin exigir separador al final). */
static bool fr3d_cmd_prefix(const char *p, const char *uword)
{
  for (; *uword; ++p, ++uword) {
    if (fr3d_uc(*p) != *uword)
      return false;
  }
  return true;
}

static bool fr3d_parse_tail_float(const char *p, const uint8_t cmd_len, float *out_v)
{
  char *q = (char *)(p + cmd_len);
  while (*q == ' ' || *q == '\t') q++;
  if (*q == '\0') return false;
  char *endp = NULL;
  const float vf = (float)strtod(q, &endp);
  if (endp == q) return false;
  while (*endp == ' ' || *endp == '\t') endp++;
  if (*endp != '\0') return false;
  *out_v = vf;
  return true;
}

static bool fr3d_parse_tail_long(const char *p, const uint8_t cmd_len, long *out_v)
{
  char *q = (char *)(p + cmd_len);
  while (*q == ' ' || *q == '\t') q++;
  if (*q == '\0') return false;
  char *endp = NULL;
  const long lv = strtol(q, &endp, 10);
  if (endp == q) return false;
  while (*endp == ' ' || *endp == '\t') endp++;
  if (*endp != '\0') return false;
  *out_v = lv;
  return true;
}

/** Salta prefijo opcional N<num> (numeración Marlin) y espacios. */
static void fr3d_skip_line_number_prefix(char **pp)
{
  char *p = *pp;
  if (fr3d_uc(*p) != 'N')
    return;
  char *q = p + 1;
  if (*q < '0' || *q > '9')
    return;
  while (*q >= '0' && *q <= '9')
    q++;
  p = q;
  while (*p == ' ' || *p == '\t')
    p++;
  *pp = p;
}

/** Línea = PAUT / PNAO / PMAN (alias); PMAN contiene M y puede confundir strchr si el compacto falla. */
static bool fr3d_line_is_compact_pman_or_paut(void)
{
  char *q = cmdbuffer[bufindr];
  while (*q == ' ' || *q == '\t') q++;
  fr3d_skip_line_number_prefix(&q);
  return fr3d_cmd_word(q, "PAUT") || fr3d_cmd_word(q, "PNAO") || fr3d_cmd_word(q, "PMAN");
}

static void fr3d_compact_do_er(void)
{
#ifdef ULTRA_LCD
  lcd_extruder_resume();
#else
  puller_feedrate = puller_feedrate_default;
  extrude_status = extrude_status | ES_ENABLE_SET;
  winderSpeed = default_winder_speed * 255 / winder_rpm_factor;
#if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1
  digitalWrite(CONTROLLERFAN_PIN, 1);
#endif
#if defined(CONTROLLERFAN2_PIN) && CONTROLLERFAN2_PIN > -1
  digitalWrite(CONTROLLERFAN2_PIN, 1);
#endif
  starttime = millis();
  extrude_status = extrude_status | ES_STATS_SET;
#endif
}

static void fr3d_compact_do_es(void)
{
#ifdef ULTRA_LCD
  lcd_extruder_pause();
#else
  extrude_status = extrude_status & ES_ENABLE_CLEAR_NO_AUTO;
  puller_feedrate_default = puller_feedrate;
  injectionModeStartMillis = -1;
#if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1
  digitalWrite(CONTROLLERFAN_PIN, 0);
#endif
  extrude_status = extrude_status & ES_STATS_CLEAR;
#endif
}

static void fr3d_compact_do_pa(bool alias_paut)
{
  if (extrude_status & ES_HOT_SET) {
    extrude_status |= ES_AUTO_SET;
    SERIAL_ECHO_START;
    if (alias_paut)
      SERIAL_ECHOLNPGM("ok PAUT");
    else
      SERIAL_ECHOLNPGM("ok PA");
  } else {
    SERIAL_ECHO_START;
    if (alias_paut)
      SERIAL_ECHOLNPGM("ok PAUT nohot");
    else
      SERIAL_ECHOLNPGM("ok PA nohot");
  }
}

static void fr3d_compact_apply_manual_pull(void)
{
  extrude_status &= ES_AUTO_CLEAR;
}

/** alias: 0=PM, 1=ok PMAN (obsoleto), 2=ok PNAO (recomendado, sin letra M en el token). */
static void fr3d_compact_do_pm(int alias)
{
  fr3d_compact_apply_manual_pull();
  SERIAL_ECHO_START;
  if (alias == 2)
    SERIAL_ECHOLNPGM("ok PNAO");
  else if (alias == 1)
    SERIAL_ECHOLNPGM("ok PMAN");
  else
    SERIAL_ECHOLNPGM("ok PM");
}

static void fr3d_compact_do_cooldown(void)
{
  setTargetHotend0(0);
  setTargetHotend1(0);
  setTargetHotend2(0);
  setTargetBed(0);
#ifdef ULTRA_LCD
  LCD_MESSAGEPGM(MSG_EX_COOL);
#endif
}

float fr3d_hall_adc_read_now()
{
#if defined(FR3D_HALL_DIAMETER_PIN) && (FR3D_HALL_DIAMETER_PIN > -1)
  /* El Hall se muestrea en TIMER0_COMPB (temperature.cpp): leer aquí sin tocar ADMUX ni cli()
     largo, porque bloquear TIMER0 cortaba el soft-PWM del hotend y no llegaba a temperatura. */
  uint16_t v;
  CRITICAL_SECTION_START;
  v = fr3d_hall_adc_oversample;
  CRITICAL_SECTION_END;
  return (float)v;
#else
  return 0.0f;
#endif
}

static bool process_fr3d_compact_line()
{
  char *p = cmdbuffer[bufindr];
  while (*p == ' ' || *p == '\t') p++;
  fr3d_skip_line_number_prefix(&p);

  fr3d_compact_last_error = false;

  if (fr3d_gwid_process_serial(p))
    return true;

  if (fr3d_uc(p[0]) == 'H' && fr3d_uc(p[1]) == 'E' && fr3d_uc(p[2]) == 'L' && fr3d_uc(p[3]) == 'P'
      && (p[4] == '\0' || p[4] == ' ' || p[4] == '\t')) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err HELP extra");
      return true;
    }
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok HELP");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" HELP  lista de comandos (host compacto)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" WRY   firma del equipo");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" GWID  WiFi+token+ip+cloud Pi (GWID,<wifi>[,<tok8>[,<ipv4>[,ONL|OFFL]]]] / GWID?)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" GWCLR borrar MAC gateway (desconexion Pi)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" QUERY estado completo (R,T,F,PR,SW,SWmin,SWmid,SWmax,PRED*,ES)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("       mayus/minus indistinto");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" R<X.X>  RPM extrusor 0-40 rpm");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" T<XXX>  temperatura objetivo 0-190 grados");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" F<XXX>  winder/ventilador %  0-100 %");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" START  start extrusion");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" STOP   stop extrusion");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PAUT   pulling automatico");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PNAO   pulling manual (recomendado; PMAN=alias obsoleto)");
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM(" PR<rpm> pulling RPM manual 0-");
    SERIAL_ECHO(PULLER_RPM_MAX);
    SERIAL_ECHOLNPGM(" (PNAO + HOT; ignora nohot/auto)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" SWMID<mm> diametro objetivo sensor (0.0-7.55)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" SWMIN<mm> umbral minimo sensor (0.0-7.55)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" SWMAX<mm> umbral maximo sensor (0.0-7.55)");
    SERIAL_ECHOLNPGM(" D170<adc> calibracion slot Lo (patron segun PAT A/B)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" D175<adc> calibracion slot Mid");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" D180<adc> calibracion slot Hi");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" DOFF<mm> offset diametro Hall A3 (-0.20..0.20)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" HPATA/HPATB preset patrones A(1.5/1.7/2.0) B(1.7/1.75/1.8); invalida CALV");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" C170/C175/C180 capturar ADC actual A3 para patron");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" QUERY incluye PAT,CALV,A3,<adc>; DLCD,<mm> diametro LCD (D)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" DIAMQ solo DLCD (diametro LCD campo D)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDQ estado predictor (enable/mode/parametros)");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDEN<0|1> predictor OFF/ON");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDMODE<0|1> 0=manual 1=automatico");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDTGT/PREDDB/PREDTM/PREDTRNG/PREDRRNG/PREDDTRNG tunning");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDDRRNG/PREDKR/PREDKT/PREDMARG/PREDSETTLE/PREDW");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" PREDCYCLE<5|10> CSV/predictor cycle seconds");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" DIAMDEBUG<0|1>  CSV diam debug extra OFF/ON");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" COOL   cooldown (temps a 0)");
#ifdef FR3D_SERIAL_HOST_DISABLE_GM
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" MF<0|1>  filtrar linea ok final");
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" LN<mm>  longitud corte filamento 1000-999000");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" SCLEAR  reset estadisticas/contador de metros");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" IN<s>  tiempo inyeccion 1-180");
#ifndef DELTA
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" SF<0|1>  sinfin 0=alta 1=baja");
#endif
#ifdef EEPROM_SETTINGS
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" MS    grabar EEPROM");
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" ML    cargar EEPROM");
#endif
#if (EXTRUDERS > 1) && (TEMP_SENSOR_1 != 0)
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" H1<T>  temp hotend 1 (C)");
#endif
#if (EXTRUDERS > 2) && (TEMP_SENSOR_2 != 0)
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" H2<T>  temp hotend 2 (C)");
#endif
#if TEMP_SENSOR_BED != 0
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" HB<T>  temp cama (C)");
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" Comandos no-FR3D por USB: bloqueados");
#ifdef FR3D_CSV_TELEMETRY
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM(" ST    sync muestreo CSV (+10s desde ahora)");
#endif
    return true;
  }

  if (fr3d_cmd_word(p, "WRY")) {
    char *r = p + 3;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err WRY extra");
      return true;
    }
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("SIG,MK3S+FR3D,1.1.0,2026-04-27");
    return true;
  }

  if (fr3d_cmd_word(p, "QUERY")) {
    char *r = p + 5;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err QUERY extra");
      return true;
    }

    /* Orden: ES al final para que el host recolecte PR/SW antes del cierre en echo:ES,. */
    SERIAL_ECHO_START; SERIAL_ECHOPGM("R,");  SERIAL_ECHO(extruder_rpm_set);      SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("T,");  SERIAL_ECHO(target_temperature[0]); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("F,");  SERIAL_ECHO(default_winder_speed);  SERIAL_ECHOLNPGM(",");
    {
      float pc_q = pcirc;
      if (pc_q < 1.0f) pc_q = DEFAULT_PULLER_WHEEL_CIRC;
      const float pr_q = puller_feedrate * (60.0f / pc_q);
      SERIAL_ECHO_START; SERIAL_ECHOPGM("PR,"); SERIAL_ECHO(pr_q); SERIAL_ECHOLNPGM(",");
    }
    SERIAL_ECHO_START; SERIAL_ECHOPGM("SW,"); SERIAL_ECHO(current_filwidth); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("SWmin,"); SERIAL_ECHO(sensorRunoutMin); SERIAL_ECHOLNPGM(",");
    /* SWmid = Ø objetivo (menú Filament / EEPROM), no el punto medio entre SWmin/SWmax (ventana runout). */
    SERIAL_ECHO_START; SERIAL_ECHOPGM("SWmid,"); SERIAL_ECHO(filament_width_desired); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("SWmax,"); SERIAL_ECHO(sensorRunoutMax); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DH,"); SERIAL_ECHO(1); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("A3,"); SERIAL_ECHO(fr3d_hall_adc_read_now()); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PAT,"); SERIAL_ECHO((fr3d_hall_pattern == FR3D_HALL_PATTERN_B) ? 'B' : 'A'); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("CALV,"); SERIAL_ECHO((int)fr3d_hall_cal_valid); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("D170,"); SERIAL_ECHO(fr3d_hall_cal_adc_170); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("D175,"); SERIAL_ECHO(fr3d_hall_cal_adc_175); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("D180,"); SERIAL_ECHO(fr3d_hall_cal_adc_180); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DOFF,"); SERIAL_PROTOCOL_F(fr3d_hall_diam_offset_mm, 3); SERIAL_ECHOLNPGM(",");
#ifdef FR3D_CSV_TELEMETRY
    fr3d_diam_poll_samples();
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DLCD,"); SERIAL_PROTOCOL_F(fr3d_diam_fifo_avg_x1000 / 1000.0f, 3); SERIAL_ECHOLNPGM(",");
#endif
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDEN,"); SERIAL_ECHO((int)fr3d_pred_enabled); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDMODE,"); SERIAL_ECHO((int)fr3d_pred_mode); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDW,"); SERIAL_ECHO((int)fr3d_pred_window_size); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTGT,"); SERIAL_PROTOCOL_F(fr3d_pred_target_diam_mm, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDDB,"); SERIAL_PROTOCOL_F(fr3d_pred_deadband_half_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTM,"); SERIAL_PROTOCOL_F(fr3d_pred_temp_match_max_c, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTRNG,"); SERIAL_ECHO(fr3d_pred_t_min); SERIAL_ECHOPGM(","); SERIAL_ECHO(fr3d_pred_t_max); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDRRNG,"); SERIAL_PROTOCOL_F(fr3d_pred_r_min, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_r_max, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDDTRNG,"); SERIAL_PROTOCOL_F(fr3d_pred_delta_t_min, 3); SERIAL_ECHOPGM(","); SERIAL_ECHO((int)fr3d_pred_delta_t_max); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDDRRNG,"); SERIAL_PROTOCOL_F(fr3d_pred_delta_r_min, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_delta_r_max, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDKR,"); SERIAL_PROTOCOL_F(fr3d_pred_k_span_r, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_k_err_r, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDKT,"); SERIAL_PROTOCOL_F(fr3d_pred_k_span_t, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_k_err_t, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDMARG,"); SERIAL_PROTOCOL_F(fr3d_pred_r_switch_margin, 3); SERIAL_ECHOPGM(","); SERIAL_ECHO((int)fr3d_pred_t_switch_margin); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDSETTLE,"); SERIAL_ECHO((int)fr3d_pred_t_settle_fusions); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDCYCLE,"); SERIAL_ECHO((int)fr3d_csv_cycle_s); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMJDB,"); SERIAL_PROTOCOL_F(fr3d_diam_jump_debounce_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMJPM,"); SERIAL_PROTOCOL_F(fr3d_diam_pending_match_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMDEBUG,"); SERIAL_ECHO((int)fr3d_diam_debug_csv_enabled); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ES,"); SERIAL_ECHO((extrude_status & ES_ENABLE_SET) ? 1 : 0); SERIAL_ECHOLNPGM(",");
    return true;
  }

  if (fr3d_cmd_word(p, "START")) {
    char *r = p + 5;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err START extra");
      return true;
    }
    fr3d_compact_do_er();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok START");
    return true;
  }
  if (fr3d_cmd_word(p, "STOP")) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err STOP extra");
      return true;
    }
    fr3d_compact_do_es();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok STOP");
    return true;
  }
  if (fr3d_cmd_word(p, "COOL")) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err COOL extra");
      return true;
    }
    fr3d_compact_do_cooldown();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok COOL");
    return true;
  }
  if (fr3d_cmd_word(p, "PAUT")) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PAUT extra");
      return true;
    }
    fr3d_compact_do_pa(true);
    return true;
  }
  if (fr3d_cmd_word(p, "PNAO")) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PNAO extra");
      return true;
    }
    fr3d_compact_do_pm(2);
    return true;
  }
  if (fr3d_cmd_word(p, "PMAN")) {
    char *r = p + 4;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PMAN extra");
      return true;
    }
    fr3d_compact_do_pm(1);
    return true;
  }

  /* PR<rpm> — pulling RPM manual 0–PULLER_RPM_MAX (requiere PNAO/PMAN + HOT; rechaza PAUT). */
  // Important: avoid matching predictor commands (PRED*) as PR.
  if (fr3d_uc(p[0]) == 'P' && fr3d_uc(p[1]) == 'R' && fr3d_uc(p[2]) != 'E') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PR empty");
      return true;
    }
    char *endp = NULL;
    const float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PR parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PR extra");
      return true;
    }
    float rpm = vf;
    if (rpm < 0.0f) rpm = 0.0f;
    if (rpm > PULLER_RPM_MAX) rpm = PULLER_RPM_MAX;
    // Bobinador: permitir PR con hotend en 0 °C (sin calentamiento).
    // En extrusión normal (T objetivo > 0), se mantiene la protección "nohot".
    if (!(extrude_status & ES_HOT_SET) && degTargetHotend(active_extruder) > 0) {
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("ok PR nohot");
      return true;
    }
    if (extrude_status & ES_AUTO_SET) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PR auto");
      return true;
    }
    float pc = pcirc;
    if (pc < 1.0f) pc = DEFAULT_PULLER_WHEEL_CIRC;
    const float mm_s = rpm * (pc / 60.0f);
    puller_feedrate = mm_s;
    puller_feedrate_default = mm_s;
    puller_feedrate_last = mm_s;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok PR ");
    SERIAL_ECHOLN(rpm);
    return true;
  }

  if (fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'W' && fr3d_uc(p[2]) == 'M' && fr3d_uc(p[3]) == 'I' && fr3d_uc(p[4]) == 'D') {
    char *q = p + 5;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMID empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMID parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMID extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 7.55f) vf = 7.55f;
    filament_width_desired = vf;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok SWMID ");
    SERIAL_ECHOLN(filament_width_desired);
    return true;
  }

  if (fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'W' && fr3d_uc(p[2]) == 'M' && fr3d_uc(p[3]) == 'I' && fr3d_uc(p[4]) == 'N') {
    char *q = p + 5;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMIN empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMIN parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMIN extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 7.55f) vf = 7.55f;
    sensorRunoutMin = vf;
    if (sensorRunoutMin > sensorRunoutMax) {
      float tmp = sensorRunoutMin;
      sensorRunoutMin = sensorRunoutMax;
      sensorRunoutMax = tmp;
    }
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok SWMIN ");
    SERIAL_ECHOLN(sensorRunoutMin);
    return true;
  }

  if (fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'W' && fr3d_uc(p[2]) == 'M' && fr3d_uc(p[3]) == 'A' && fr3d_uc(p[4]) == 'X') {
    char *q = p + 5;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMAX empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMAX parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SWMAX extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 7.55f) vf = 7.55f;
    sensorRunoutMax = vf;
    if (sensorRunoutMin > sensorRunoutMax) {
      float tmp = sensorRunoutMin;
      sensorRunoutMin = sensorRunoutMax;
      sensorRunoutMax = tmp;
    }
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok SWMAX ");
    SERIAL_ECHOLN(sensorRunoutMax);
    return true;
  }

  if (fr3d_uc(p[0]) == 'D' && fr3d_uc(p[1]) == 'H') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DH empty");
      return true;
    }
    char *endp = NULL;
    const long vf = strtol(q, &endp, 10);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DH parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DH extra");
      return true;
    }
    if (vf != 0 && vf != 1) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DH range");
      return true;
    }
    (void)vf;
    fr3d_hall_diameter_enabled = 1;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok DH ");
    SERIAL_ECHOLN(1);
    return true;
  }

  if (fr3d_cmd_word(p, "DIAMQ")) {
    char *r = p + 5;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DIAMQ extra");
      return true;
    }
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok DIAMQ");
#ifdef FR3D_CSV_TELEMETRY
    fr3d_diam_poll_samples();
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DLCD,"); SERIAL_PROTOCOL_F(fr3d_diam_fifo_avg_x1000 / 1000.0f, 3); SERIAL_ECHOLNPGM(",");
#endif
    return true;
  }

  if (fr3d_cmd_word(p, "PREDQ")) {
    char *r = p + 5;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err PREDQ extra");
      return true;
    }
    SERIAL_ECHO_START; SERIAL_ECHOLNPGM("ok PREDQ");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDEN,"); SERIAL_ECHO((int)fr3d_pred_enabled); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDMODE,"); SERIAL_ECHO((int)fr3d_pred_mode); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDW,"); SERIAL_ECHO((int)fr3d_pred_window_size); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTGT,"); SERIAL_PROTOCOL_F(fr3d_pred_target_diam_mm, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDDB,"); SERIAL_PROTOCOL_F(fr3d_pred_deadband_half_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTM,"); SERIAL_PROTOCOL_F(fr3d_pred_temp_match_max_c, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDTRNG,"); SERIAL_ECHO(fr3d_pred_t_min); SERIAL_ECHOPGM(","); SERIAL_ECHO(fr3d_pred_t_max); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDRRNG,"); SERIAL_PROTOCOL_F(fr3d_pred_r_min, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_r_max, 3); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDDTRNG,"); SERIAL_PROTOCOL_F(fr3d_pred_delta_t_min, 3); SERIAL_ECHOPGM(","); SERIAL_ECHO((int)fr3d_pred_delta_t_max); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMJDB,"); SERIAL_PROTOCOL_F(fr3d_diam_jump_debounce_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMJPM,"); SERIAL_PROTOCOL_F(fr3d_diam_pending_match_mm, 4); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("DIAMDEBUG,"); SERIAL_ECHO((int)fr3d_diam_debug_csv_enabled); SERIAL_ECHOLNPGM(",");
    SERIAL_ECHO_START; SERIAL_ECHOPGM("PREDCYCLE,"); SERIAL_ECHO((int)fr3d_csv_cycle_s); SERIAL_ECHOLNPGM(",");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDOWN")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 7, &lv) || (lv != 0 && lv != 1)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDOWN");
      return true;
    }
    (void)lv;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDOWN "); SERIAL_ECHOLN(1);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDEN")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 6, &lv) || (lv != 0 && lv != 1)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDEN");
      return true;
    }
    fr3d_pred_enabled = (uint8_t)lv;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDEN "); SERIAL_ECHOLN((int)fr3d_pred_enabled);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDMODE")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 8, &lv) || (lv != 0 && lv != 1)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDMODE");
      return true;
    }
    fr3d_pred_mode = (uint8_t)lv;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDMODE "); SERIAL_ECHOLN((int)fr3d_pred_mode);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDCYCLE")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 9, &lv) || (lv != 5 && lv != 10)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDCYCLE");
      return true;
    }
    fr3d_csv_cycle_s = (uint8_t)lv;
#ifdef FR3D_CSV_TELEMETRY
    fr3d_csv_sync_sample_timer();
#endif
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDCYCLE "); SERIAL_ECHOLN((int)fr3d_csv_cycle_s);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDTGT")) {
    float vf = 0.0f;
    if (!fr3d_parse_tail_float(p, 7, &vf)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDTGT");
      return true;
    }
    if (vf < 0.5f) vf = 0.5f;
    if (vf > 7.55f) vf = 7.55f;
    fr3d_pred_target_diam_mm = vf;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDTGT "); SERIAL_PROTOCOL_F(fr3d_pred_target_diam_mm, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDDB")) {
    float vf = 0.0f;
    if (!fr3d_parse_tail_float(p, 6, &vf)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDDB");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 0.20f) vf = 0.20f;
    fr3d_pred_deadband_half_mm = vf;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDDB "); SERIAL_PROTOCOL_F(fr3d_pred_deadband_half_mm, 4); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "DIAMJDB")) {
    float vf = 0.0f;
    if (!fr3d_parse_tail_float(p, 7, &vf)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err DIAMJDB");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 0.5f) vf = 0.5f;
    vf = ((float)((long)(vf * 1000.0f + 0.5f))) / 1000.0f;
    fr3d_diam_jump_debounce_mm = vf;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok DIAMJDB "); SERIAL_PROTOCOL_F(fr3d_diam_jump_debounce_mm, 4); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "DIAMJPM")) {
    float vf = 0.0f;
    if (!fr3d_parse_tail_float(p, 7, &vf)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err DIAMJPM");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 0.2f) vf = 0.2f;
    vf = ((float)((long)(vf * 1000.0f + 0.5f))) / 1000.0f;
    fr3d_diam_pending_match_mm = vf;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok DIAMJPM "); SERIAL_PROTOCOL_F(fr3d_diam_pending_match_mm, 4); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "DIAMDEBUG")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 9, &lv) || (lv != 0 && lv != 1)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err DIAMDEBUG");
      return true;
    }
    fr3d_diam_debug_csv_enabled = (uint8_t)lv;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok DIAMDEBUG "); SERIAL_ECHOLN((int)fr3d_diam_debug_csv_enabled);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDTM")) {
    float vf = 0.0f;
    if (!fr3d_parse_tail_float(p, 6, &vf)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDTM");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 20.0f) vf = 20.0f;
    fr3d_pred_temp_match_max_c = vf;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDTM "); SERIAL_PROTOCOL_F(fr3d_pred_temp_match_max_c, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDTRNG")) {
    char *q = p + 8;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    const long tmin = strtol(q, &endp, 10);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDTRNG");
      return true;
    }
    q = endp + 1;
    const long tmax = strtol(q, &endp, 10);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDTRNG");
      return true;
    }
    long a = tmin, b = tmax;
    if (a > b) { long tmp = a; a = b; b = tmp; }
    if (a < 0) a = 0;
    if (b > 300) b = 300;
    fr3d_pred_t_min = (int16_t)a;
    fr3d_pred_t_max = (int16_t)b;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDTRNG "); SERIAL_ECHO(fr3d_pred_t_min); SERIAL_ECHOPGM(","); SERIAL_ECHOLN(fr3d_pred_t_max);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDRRNG")) {
    char *q = p + 8;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float rmin = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDRRNG");
      return true;
    }
    q = endp + 1;
    float rmax = (float)strtod(q, &endp);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDRRNG");
      return true;
    }
    if (rmin > rmax) { float tmp = rmin; rmin = rmax; rmax = tmp; }
    if (rmin < 0.0f) rmin = 0.0f;
    if (rmax > EXTRUDER_RPM_MAX) rmax = EXTRUDER_RPM_MAX;
    fr3d_pred_r_min = rmin;
    fr3d_pred_r_max = rmax;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDRRNG "); SERIAL_PROTOCOL_F(fr3d_pred_r_min, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_r_max, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDDTRNG")) {
    char *q = p + 9;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float dtmin = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDDTRNG");
      return true;
    }
    q = endp + 1;
    const long dtmax = strtol(q, &endp, 10);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDDTRNG");
      return true;
    }
    long b = dtmax;
    if (dtmin < 0.0f) dtmin = 0.0f;
    if (b < 0) b = 0;
    if (b > 20) b = 20;
    fr3d_pred_delta_t_min = dtmin;
    fr3d_pred_delta_t_max = (uint8_t)b;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDDTRNG "); SERIAL_PROTOCOL_F(fr3d_pred_delta_t_min, 3); SERIAL_ECHOPGM(","); SERIAL_ECHOLN((int)fr3d_pred_delta_t_max);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDW")) {
    fr3d_pred_window_size = (uint8_t)FR3D_PRED_WINDOW_SIZE_DEFAULT;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDW "); SERIAL_ECHOLN((int)fr3d_pred_window_size);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDDRRNG")) {
    char *q = p + 9;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float drmin = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDDRRNG");
      return true;
    }
    q = endp + 1;
    float drmax = (float)strtod(q, &endp);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDDRRNG");
      return true;
    }
    if (drmin > drmax) { const float tmp = drmin; drmin = drmax; drmax = tmp; }
    if (drmin < 0.0f) drmin = 0.0f;
    if (drmax > 5.0f) drmax = 5.0f;
    fr3d_pred_delta_r_min = drmin;
    fr3d_pred_delta_r_max = drmax;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDDRRNG "); SERIAL_PROTOCOL_F(fr3d_pred_delta_r_min, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_delta_r_max, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDKR")) {
    char *q = p + 6;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float kspan = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDKR");
      return true;
    }
    q = endp + 1;
    float kerr = (float)strtod(q, &endp);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDKR");
      return true;
    }
    if (kspan < 0.0f) kspan = 0.0f;
    if (kerr < 0.0f) kerr = 0.0f;
    fr3d_pred_k_span_r = kspan;
    fr3d_pred_k_err_r = kerr;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDKR "); SERIAL_PROTOCOL_F(fr3d_pred_k_span_r, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_k_err_r, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDKT")) {
    char *q = p + 6;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float kspan = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDKT");
      return true;
    }
    q = endp + 1;
    float kerr = (float)strtod(q, &endp);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDKT");
      return true;
    }
    if (kspan < 0.0f) kspan = 0.0f;
    if (kerr < 0.0f) kerr = 0.0f;
    fr3d_pred_k_span_t = kspan;
    fr3d_pred_k_err_t = kerr;
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDKT "); SERIAL_PROTOCOL_F(fr3d_pred_k_span_t, 3); SERIAL_ECHOPGM(","); SERIAL_PROTOCOL_F(fr3d_pred_k_err_t, 3); SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDMARG")) {
    char *q = p + 8;
    while (*q == ' ' || *q == '\t') q++;
    char *endp = NULL;
    float rm = (float)strtod(q, &endp);
    if (endp == q || *endp != ',') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDMARG");
      return true;
    }
    q = endp + 1;
    const long tm = strtol(q, &endp, 10);
    while (*endp == ' ' || *endp == '\t') endp++;
    if (endp == q || *endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDMARG");
      return true;
    }
    if (rm < 0.0f) rm = 0.0f;
    fr3d_pred_r_switch_margin = rm;
    fr3d_pred_t_switch_margin = (uint8_t)constrain(tm, 0L, 20L);
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDMARG "); SERIAL_PROTOCOL_F(fr3d_pred_r_switch_margin, 3); SERIAL_ECHOPGM(","); SERIAL_ECHOLN((int)fr3d_pred_t_switch_margin);
    return true;
  }

  if (fr3d_cmd_prefix(p, "PREDSETTLE")) {
    long lv = 0;
    if (!fr3d_parse_tail_long(p, 10, &lv)) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START; SERIAL_ECHOLNPGM("err PREDSETTLE");
      return true;
    }
    fr3d_pred_t_settle_fusions = (uint8_t)constrain(lv, 0L, 20L);
    SERIAL_ECHO_START; SERIAL_ECHOPGM("ok PREDSETTLE "); SERIAL_ECHOLN((int)fr3d_pred_t_settle_fusions);
    return true;
  }

  if (fr3d_uc(p[0]) == 'D' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '7' && fr3d_uc(p[3]) == '0') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D170 empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D170 parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D170 extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 1023.0f) vf = 1023.0f;
    fr3d_hall_cal_adc_170 = vf;
    fr3d_hall_note_point_saved(0);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok D170 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_170);
    return true;
  }

  if (fr3d_uc(p[0]) == 'D' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '7' && fr3d_uc(p[3]) == '5') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D175 empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D175 parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D175 extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 1023.0f) vf = 1023.0f;
    fr3d_hall_cal_adc_175 = vf;
    fr3d_hall_note_point_saved(1);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok D175 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_175);
    return true;
  }

  if (fr3d_uc(p[0]) == 'D' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '8' && fr3d_uc(p[3]) == '0') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D180 empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D180 parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err D180 extra");
      return true;
    }
    if (vf < 0.0f) vf = 0.0f;
    if (vf > 1023.0f) vf = 1023.0f;
    fr3d_hall_cal_adc_180 = vf;
    fr3d_hall_note_point_saved(2);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok D180 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_180);
    return true;
  }

  if (fr3d_uc(p[0]) == 'D' && fr3d_uc(p[1]) == 'O' && fr3d_uc(p[2]) == 'F' && fr3d_uc(p[3]) == 'F') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DOFF empty");
      return true;
    }
    char *endp = NULL;
    float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DOFF parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err DOFF extra");
      return true;
    }
    if (vf < -0.20f) vf = -0.20f;
    if (vf > 0.20f) vf = 0.20f;
    fr3d_hall_diam_offset_mm = vf;
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok DOFF ");
    SERIAL_PROTOCOL_F(fr3d_hall_diam_offset_mm, 3);
    SERIAL_ECHOLNPGM("");
    return true;
  }

  if (fr3d_uc(p[0]) == 'C' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '7' && fr3d_uc(p[3]) == '0') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err C170 extra");
      return true;
    }
    fr3d_hall_cal_adc_170 = fr3d_hall_adc_read_now();
    fr3d_hall_note_point_saved(0);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok C170 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_170);
    return true;
  }

  if (fr3d_uc(p[0]) == 'C' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '7' && fr3d_uc(p[3]) == '5') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err C175 extra");
      return true;
    }
    fr3d_hall_cal_adc_175 = fr3d_hall_adc_read_now();
    fr3d_hall_note_point_saved(1);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok C175 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_175);
    return true;
  }

  if (fr3d_uc(p[0]) == 'C' && fr3d_uc(p[1]) == '1' && fr3d_uc(p[2]) == '8' && fr3d_uc(p[3]) == '0') {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    if (*q != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err C180 extra");
      return true;
    }
    fr3d_hall_cal_adc_180 = fr3d_hall_adc_read_now();
    fr3d_hall_note_point_saved(2);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok C180 ");
    SERIAL_ECHOLN(fr3d_hall_cal_adc_180);
    return true;
  }

  if (fr3d_cmd_prefix(p, "HPAT")) {
    char *q = p + 4;
    while (*q == ' ' || *q == '\t') q++;
    char ch = fr3d_uc(*q);
    if ((ch != 'A' && ch != 'B') || (q[1] != '\0' && q[1] != ' ' && q[1] != '\t')) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err HPAT use HPATA or HPATB");
      return true;
    }
    fr3d_hall_set_pattern((ch == 'B') ? FR3D_HALL_PATTERN_B : FR3D_HALL_PATTERN_A);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok HPAT ");
    SERIAL_ECHO(ch);
    SERIAL_ECHOPGM(" CALV=");
    SERIAL_ECHOLN((int)fr3d_hall_cal_valid);
    return true;
  }

  if (fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'T' && (p[2] == '\0' || p[2] == ' ' || p[2] == '\t')) {
    char *r = p + 2;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err ST extra");
      return true;
    }
#ifndef FR3D_CSV_TELEMETRY
    fr3d_compact_last_error = true;
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("err ST nocfg");
    return true;
#else
    fr3d_csv_sync_sample_timer();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok ST");
    return true;
#endif
  }

#ifdef FR3D_SERIAL_HOST_DISABLE_GM
  if (fr3d_uc(p[0]) == 'M' && fr3d_uc(p[1]) == 'F') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err MF empty");
      return true;
    }
    char *endp = NULL;
    const long v = strtol(q, &endp, 10);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err MF parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err MF extra");
      return true;
    }
    if (v != 0 && v != 1) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err MF range");
      return true;
    }
    /* Always ON (LCD toggle removed); ignore MF 0 */
    fr3d_serial_filter_msgs = true;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok MF ");
    SERIAL_ECHOLN((int)fr3d_serial_filter_msgs);
    return true;
  }
#endif
#ifdef EEPROM_SETTINGS
  if (fr3d_uc(p[0]) == 'M' && fr3d_uc(p[1]) == 'S' && (p[2] == '\0' || p[2] == ' ' || p[2] == '\t')) {
    char *r = p + 2;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err MS extra");
      return true;
    }
    Config_StoreSettings();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok MS");
    return true;
  }
  if (fr3d_uc(p[0]) == 'M' && fr3d_uc(p[1]) == 'L' && (p[2] == '\0' || p[2] == ' ' || p[2] == '\t')) {
    char *r = p + 2;
    while (*r == ' ' || *r == '\t') r++;
    if (*r != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err ML extra");
      return true;
    }
    Config_RetrieveSettings();
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok ML");
    return true;
  }
#endif

  if (fr3d_uc(p[0]) == 'L' && fr3d_uc(p[1]) == 'N') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err LN empty");
      return true;
    }
    char *endp = NULL;
    const float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err LN parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err LN extra");
      return true;
    }
    float len = vf;
    if (len < 1000.0f) len = 1000.0f;
    if (len > 999000.0f) len = 999000.0f;
    fil_length_cutoff = len;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok LN ");
    SERIAL_ECHOLN(fil_length_cutoff);
    return true;
  }
  if (
      fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'C' && fr3d_uc(p[2]) == 'L' &&
      fr3d_uc(p[3]) == 'E' && fr3d_uc(p[4]) == 'A' && fr3d_uc(p[5]) == 'R') {
    char *q = p + 6;
    while (*q == ' ' || *q == '\t') q++;
    if (*q != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SCLEAR extra");
      return true;
    }
    avg_measured_filament_width = 0.0f;
    max_measured_filament_width = 0.0f;
    min_measured_filament_width = 0.0f;
    sum_measured_filament_width = 0.0f;
    n_measured_filament_width = 0.0f;
    extrude_length = 0.0f;
    duration = 0UL;
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("ok SCLEAR");
    return true;
  }
  if (fr3d_uc(p[0]) == 'I' && fr3d_uc(p[1]) == 'N') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err IN empty");
      return true;
    }
    char *endp = NULL;
    const long v = strtol(q, &endp, 10);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err IN parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err IN extra");
      return true;
    }
    long sec = v;
    if (sec < 1) sec = 1;
    if (sec > 3 * 60) sec = 3 * 60;
    injectionTimeSeconds = (int)sec;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok IN ");
    SERIAL_ECHOLN(injectionTimeSeconds);
    return true;
  }
#ifndef DELTA
  if (fr3d_uc(p[0]) == 'S' && fr3d_uc(p[1]) == 'F') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SF empty");
      return true;
    }
    char *endp = NULL;
    const long v = strtol(q, &endp, 10);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SF parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SF extra");
      return true;
    }
    if (v != 0 && v != 1) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err SF range");
      return true;
    }
    sinfin_compression_mode = (uint8_t)(v == 0 ? SINFIN_COMP_ALTA : SINFIN_COMP_BAJA);
#ifdef EEPROM_SETTINGS
    Config_StoreSettings();
#endif
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok SF ");
    SERIAL_ECHOLN((int)v);
    return true;
  }
#endif
#if (EXTRUDERS > 1) && (TEMP_SENSOR_1 != 0)
  if (fr3d_uc(p[0]) == 'H' && fr3d_uc(p[1]) == '1') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H1 empty");
      return true;
    }
    char *endp = NULL;
    const float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H1 parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H1 extra");
      return true;
    }
    int ti = (int)(vf + (vf >= 0 ? 0.5f : -0.5f));
    if (ti < 0) ti = 0;
    if (ti > HEATER_1_MAXTEMP - 15) ti = HEATER_1_MAXTEMP - 15;
    target_temperature[1] = ti;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok H1 ");
    SERIAL_ECHOLN(ti);
    return true;
  }
#endif
#if (EXTRUDERS > 2) && (TEMP_SENSOR_2 != 0)
  if (fr3d_uc(p[0]) == 'H' && fr3d_uc(p[1]) == '2') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H2 empty");
      return true;
    }
    char *endp = NULL;
    const float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H2 parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err H2 extra");
      return true;
    }
    int ti = (int)(vf + (vf >= 0 ? 0.5f : -0.5f));
    if (ti < 0) ti = 0;
    if (ti > HEATER_2_MAXTEMP - 15) ti = HEATER_2_MAXTEMP - 15;
    target_temperature[2] = ti;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok H2 ");
    SERIAL_ECHOLN(ti);
    return true;
  }
#endif
#if TEMP_SENSOR_BED != 0
  if (fr3d_uc(p[0]) == 'H' && fr3d_uc(p[1]) == 'B') {
    char *q = p + 2;
    while (*q == ' ' || *q == '\t') q++;
    if (*q == '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err HB empty");
      return true;
    }
    char *endp = NULL;
    const float vf = (float)strtod(q, &endp);
    if (endp == q) {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err HB parse");
      return true;
    }
    while (*endp == ' ' || *endp == '\t') endp++;
    if (*endp != '\0') {
      fr3d_compact_last_error = true;
      SERIAL_ECHO_START;
      SERIAL_ECHOLNPGM("err HB extra");
      return true;
    }
    int tb = (int)(vf + (vf >= 0 ? 0.5f : -0.5f));
    if (tb < 0) tb = 0;
    if (tb > BED_MAXTEMP - 15) tb = BED_MAXTEMP - 15;
    target_temperature_bed = tb;
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("ok HB ");
    SERIAL_ECHOLN(tb);
    return true;
  }
#endif

  const char c = fr3d_uc(p[0]);
  if (c != 'R' && c != 'T' && c != 'F')
    return false;
  if (p[1] == '\0') {
    fr3d_compact_last_error = true;
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("err RTF empty");
    return true;
  }
  char *endp = NULL;
  const float vf = strtod(p + 1, &endp);
  if (endp == p + 1) {
    fr3d_compact_last_error = true;
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("err RTF parse");
    return true;
  }
  while (*endp == ' ' || *endp == '\t') endp++;
  if (*endp != '\0') {
    fr3d_compact_last_error = true;
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("err RTF extra");
    return true;
  }

  switch (c) {
    case 'R': {
      float v = vf;
      if (v < FR3D_SERIAL_RPM_MIN) v = FR3D_SERIAL_RPM_MIN;
      if (v > EXTRUDER_RPM_MAX) v = EXTRUDER_RPM_MAX;
      extruder_rpm_set = v;
      SERIAL_ECHO_START;
      SERIAL_ECHOPGM("ok R ");
      SERIAL_ECHOLN(v);
      break;
    }
    case 'T': {
      int t = (int)(vf + (vf >= 0 ? 0.5f : -0.5f));
      if (t < FR3D_SERIAL_TEMP_MIN) t = FR3D_SERIAL_TEMP_MIN;
      if (t > FR3D_SERIAL_TEMP_MAX) t = FR3D_SERIAL_TEMP_MAX;
      target_temperature[0] = t;
      SERIAL_ECHO_START;
      SERIAL_ECHOPGM("ok T ");
      SERIAL_ECHOLN(t);
      break;
    }
    case 'F': {
      int f = (int)(vf + (vf >= 0 ? 0.5f : -0.5f));
      if (f < FR3D_SERIAL_FAN_MIN) f = FR3D_SERIAL_FAN_MIN;
      if (f > FR3D_SERIAL_FAN_MAX) f = FR3D_SERIAL_FAN_MAX;
      default_winder_speed = f;
      SERIAL_ECHO_START;
      SERIAL_ECHOPGM("ok F ");
      SERIAL_ECHOLN(f);
      break;
    }
    default:
      return false;
  }
  return true;
}
#endif /* FR3D_SERIAL_HOST_DISABLE_GM */

void process_commands()
{
  unsigned long codenum; //throw away variable
  char *starpos = NULL;
#ifdef ENABLE_AUTO_BED_LEVELING
  float x_tmp, y_tmp, z_tmp, real_z;
#endif

#ifdef FR3D_SERIAL_HOST_DISABLE_GM
  /* Quitar CR para que fr3d_cmd_word reconozca fin de palabra en hosts CRLF.
     Truncar en '*' (checksum Marlin tras N… *NN) para que PNAO/PAUT/PMAN no queden con '*'. */
  {
    char *b = cmdbuffer[bufindr];
    for (char *c = b; *c; ++c) {
      if (*c == '\r')
        *c = '\0';
    }
    char *star = strchr(b, '*');
    if (star != NULL)
      *star = '\0';
  }
  if (process_fr3d_compact_line()) {
    previous_millis_cmd = millis();
#ifdef SDSUPPORT
    if (!fromsd[bufindr])
#endif
    {
      if (!fr3d_serial_filter_msgs || fr3d_compact_last_error)
        SERIAL_PROTOCOLLNPGM(MSG_OK);
    }
    return;
  }
  if (!fromsd[bufindr]) {
#if FR3D_SERIAL_HOST_ONLY_COMPACT
    SERIAL_ECHO_START;
    SERIAL_ECHOLNPGM("err FR3D only");
    ClearToSend();
    return;
#else
    /* No usar strchr('M') en toda la línea: PMAN (alias) contiene M. Preferir token PNAO (sin M).
       Solo bloquear G/M reales (primera letra tras espacios/N es G o M). */
    {
      char *qgm = cmdbuffer[bufindr];
      while (*qgm == ' ' || *qgm == '\t') qgm++;
      fr3d_skip_line_number_prefix(&qgm);
      const char g0 = fr3d_uc(*qgm);
      if (g0 == 'G' || g0 == 'M') {
        SERIAL_ECHO_START;
        SERIAL_ECHOLNPGM("err GM disabled");
        ClearToSend();
        return;
      }
    }
#endif
  }
#endif

  if(code_seen('G'))
  {
    switch((int)code_value())
    {
    case 0: // G0 -> G1
    case 1: // G1
      if(Stopped == false) {
        get_coordinates(); // For X Y Z E F
          #ifdef FWRETRACT
            if(autoretract_enabled)
            if( !(code_seen('X') || code_seen('Y') || code_seen('Z')) && code_seen('E')) {
              float echange=destination[E_AXIS]-current_position[E_AXIS];
              if((echange<-MIN_RETRACT && !retracted) || (echange>MIN_RETRACT && retracted)) { //move appears to be an attempt to retract or recover
                  current_position[E_AXIS] = destination[E_AXIS]; //hide the slicer-generated retract/recover from calculations
                  plan_set_e_position(current_position[E_AXIS]); //AND from the planner
                  retract(!retracted);
                  return;
              }
            }
          #endif //FWRETRACT
        prepare_move();
        //ClearToSend();
        return;
      }
      //break;
    case 2: // G2  - CW ARC
      if(Stopped == false) {
        get_arc_coordinates();
        prepare_arc_move(true);
        return;
      }
    case 3: // G3  - CCW ARC
      if(Stopped == false) {
        get_arc_coordinates();
        prepare_arc_move(false);
        return;
      }
    case 4: // G4 dwell
      LCD_MESSAGEPGM(MSG_DWELL);
      codenum = 0;
      if(code_seen('P')) codenum = code_value(); // milliseconds to wait
      if(code_seen('S')) codenum = code_value() * 1000; // seconds to wait

      st_synchronize();
      codenum += millis();  // keep track of when we started waiting
      previous_millis_cmd = millis();
      while(millis()  < codenum ){
        manage_heater();
        manage_inactivity();
        lcd_update(encoderClicked, encoderLongPressed);
      }
      break;
      #ifdef FWRETRACT
      case 10: // G10 retract
        retract(true);
      break;
      case 11: // G11 retract_recover
        retract(false);
      break;
      #endif //FWRETRACT
    case 28: //G28 Home all Axis one at a time
#ifdef ENABLE_AUTO_BED_LEVELING
      plan_bed_level_matrix.set_to_identity();  //Reset the plane ("erase" all leveling data)
#endif //ENABLE_AUTO_BED_LEVELING


 //     saved_feedrate = feedrate;
 //     saved_feedmultiply = feedmultiply;
 //     feedmultiply = 100;
      previous_millis_cmd = millis();

      enable_endstops(true);

      for(int8_t i=0; i < NUM_AXIS; i++) {
        destination[i] = current_position[i];
      }
      feedrate = 0.0;

#ifdef DELTA
          // A delta can only safely home all axis at the same time
          // all axis have to home at the same time

          // Move all carriages up together until the first endstop is hit.
          current_position[X_AXIS] = 0;
          current_position[Y_AXIS] = 0;
          current_position[Z_AXIS] = 0;
          plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);

          destination[X_AXIS] = 3 * Z_MAX_LENGTH;
          destination[Y_AXIS] = 3 * Z_MAX_LENGTH;
          destination[Z_AXIS] = 3 * Z_MAX_LENGTH;
          feedrate = 1.732 * homing_feedrate[X_AXIS];
          plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate/60, active_extruder);
          st_synchronize();
          endstops_hit_on_purpose();

          current_position[X_AXIS] = destination[X_AXIS];
          current_position[Y_AXIS] = destination[Y_AXIS];
          current_position[Z_AXIS] = destination[Z_AXIS];

          // take care of back off and rehome now we are all at the top
          HOMEAXIS(X);
          HOMEAXIS(Y);
          HOMEAXIS(Z);

          calculate_delta(current_position);
          plan_set_position(delta[X_AXIS], delta[Y_AXIS], delta[Z_AXIS], current_position[E_AXIS]);

#else // NOT DELTA

      home_all_axis = !((code_seen(axis_codes[X_AXIS])) || (code_seen(axis_codes[Y_AXIS])) || (code_seen(axis_codes[Z_AXIS])));

      #if Z_HOME_DIR > 0                      // If homing away from BED do Z first
      if((home_all_axis) || (code_seen(axis_codes[Z_AXIS]))) {
        HOMEAXIS(Z);
      }
      #endif

      #ifdef QUICK_HOME
      if((home_all_axis)||( code_seen(axis_codes[X_AXIS]) && code_seen(axis_codes[Y_AXIS])) )  //first diagonal move
      {
        current_position[X_AXIS] = 0;current_position[Y_AXIS] = 0;

       #ifndef DUAL_X_CARRIAGE
        int x_axis_home_dir = home_dir(X_AXIS);
       #else
        int x_axis_home_dir = x_home_dir(active_extruder);
        extruder_duplication_enabled = false;
       #endif

        plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
        destination[X_AXIS] = 1.5 * max_length(X_AXIS) * x_axis_home_dir;destination[Y_AXIS] = 1.5 * max_length(Y_AXIS) * home_dir(Y_AXIS);
        feedrate = homing_feedrate[X_AXIS];
        if(homing_feedrate[Y_AXIS]<feedrate)
          feedrate =homing_feedrate[Y_AXIS];
        plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS],destination[P_AXIS], feedrate/60, active_extruder);
        st_synchronize();

        axis_is_at_home(X_AXIS);
        axis_is_at_home(Y_AXIS);
        plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
        destination[X_AXIS] = current_position[X_AXIS];
        destination[Y_AXIS] = current_position[Y_AXIS];
        plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate/60, active_extruder);
        feedrate = 0.0;
        st_synchronize();
        endstops_hit_on_purpose();

        current_position[X_AXIS] = destination[X_AXIS];
        current_position[Y_AXIS] = destination[Y_AXIS];
        current_position[Z_AXIS] = destination[Z_AXIS];
      }
      #endif

      if((home_all_axis) || (code_seen(axis_codes[X_AXIS])))
      {
      #ifdef DUAL_X_CARRIAGE
        int tmp_extruder = active_extruder;
        extruder_duplication_enabled = false;
        active_extruder = !active_extruder;
        HOMEAXIS(X);
        inactive_extruder_x_pos = current_position[X_AXIS];
        active_extruder = tmp_extruder;
        HOMEAXIS(X);
        // reset state used by the different modes
        memcpy(raised_parked_position, current_position, sizeof(raised_parked_position));
        delayed_move_time = 0;
        active_extruder_parked = true;
      #else
        HOMEAXIS(X);
      #endif
      }

      if((home_all_axis) || (code_seen(axis_codes[Y_AXIS]))) {
        HOMEAXIS(Y);
      }

      if(code_seen(axis_codes[X_AXIS]))
      {
        if(code_value_long() != 0) {
          current_position[X_AXIS]=code_value()+add_homeing[0];
        }
      }

      if(code_seen(axis_codes[Y_AXIS])) {
        if(code_value_long() != 0) {
          current_position[Y_AXIS]=code_value()+add_homeing[1];
        }
      }

      #if Z_HOME_DIR < 0                      // If homing towards BED do Z last
        #ifndef Z_SAFE_HOMING
          if((home_all_axis) || (code_seen(axis_codes[Z_AXIS]))) {
            #if defined (Z_RAISE_BEFORE_HOMING) && (Z_RAISE_BEFORE_HOMING > 0)
              destination[Z_AXIS] = Z_RAISE_BEFORE_HOMING * home_dir(Z_AXIS) * (-1);    // Set destination away from bed
              feedrate = max_feedrate[Z_AXIS];
              plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate, active_extruder);
              st_synchronize();
            #endif
            HOMEAXIS(Z);
          }
        #else                      // Z Safe mode activated.
          if(home_all_axis) {
            destination[X_AXIS] = round(Z_SAFE_HOMING_X_POINT - X_PROBE_OFFSET_FROM_EXTRUDER);
            destination[Y_AXIS] = round(Z_SAFE_HOMING_Y_POINT - Y_PROBE_OFFSET_FROM_EXTRUDER);
            destination[Z_AXIS] = Z_RAISE_BEFORE_HOMING * home_dir(Z_AXIS) * (-1);    // Set destination away from bed
            feedrate = XY_TRAVEL_SPEED;
            current_position[Z_AXIS] = 0;

            plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
            plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate, active_extruder);
            st_synchronize();
            current_position[X_AXIS] = destination[X_AXIS];
            current_position[Y_AXIS] = destination[Y_AXIS];

            HOMEAXIS(Z);
          }
                                                // Let's see if X and Y are homed and probe is inside bed area.
          if(code_seen(axis_codes[Z_AXIS])) {
            if ( (axis_known_position[X_AXIS]) && (axis_known_position[Y_AXIS]) \
              && (current_position[X_AXIS]+X_PROBE_OFFSET_FROM_EXTRUDER >= X_MIN_POS) \
              && (current_position[X_AXIS]+X_PROBE_OFFSET_FROM_EXTRUDER <= X_MAX_POS) \
              && (current_position[Y_AXIS]+Y_PROBE_OFFSET_FROM_EXTRUDER >= Y_MIN_POS) \
              && (current_position[Y_AXIS]+Y_PROBE_OFFSET_FROM_EXTRUDER <= Y_MAX_POS)) {

              current_position[Z_AXIS] = 0;
              plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
              destination[Z_AXIS] = Z_RAISE_BEFORE_HOMING * home_dir(Z_AXIS) * (-1);    // Set destination away from bed
              feedrate = max_feedrate[Z_AXIS];
              plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS],feedrate, active_extruder);
              st_synchronize();

              HOMEAXIS(Z);
            } else if (!((axis_known_position[X_AXIS]) && (axis_known_position[Y_AXIS]))) {
                LCD_MESSAGEPGM(MSG_POSITION_UNKNOWN);
                SERIAL_ECHO_START;
                SERIAL_ECHOLNPGM(MSG_POSITION_UNKNOWN);
            } else {
                LCD_MESSAGEPGM(MSG_ZPROBE_OUT);
                SERIAL_ECHO_START;
                SERIAL_ECHOLNPGM(MSG_ZPROBE_OUT);
            }
          }
        #endif
      #endif



      if(code_seen(axis_codes[Z_AXIS])) {
        if(code_value_long() != 0) {
          current_position[Z_AXIS]=code_value()+add_homeing[2];
        }
      }
      #ifdef ENABLE_AUTO_BED_LEVELING
        if((home_all_axis) || (code_seen(axis_codes[Z_AXIS]))) {
          current_position[Z_AXIS] += zprobe_zoffset;  //Add Z_Probe offset (the distance is negative)
        }
      #endif
      plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], current_position[P_AXIS]);  //FMM added P_AXIS
#endif // else DELTA

      #ifdef ENDSTOPS_ONLY_FOR_HOMING
        enable_endstops(false);
      #endif

  //    feedrate = saved_feedrate;
  //    feedmultiply = saved_feedmultiply;
      previous_millis_cmd = millis();
      endstops_hit_on_purpose();
      break;

#ifdef ENABLE_AUTO_BED_LEVELING
    case 29: // G29 Detailed Z-Probe, probes the bed at 3 or more points.
        {
            #if Z_MIN_PIN == -1
            #error "You must have a Z_MIN endstop in order to enable Auto Bed Leveling feature!!! Z_MIN_PIN must point to a valid hardware pin."
            #endif

            // Prevent user from running a G29 without first homing in X and Y
            if (! (axis_known_position[X_AXIS] && axis_known_position[Y_AXIS]) )
            {
                LCD_MESSAGEPGM(MSG_POSITION_UNKNOWN);
                SERIAL_ECHO_START;
                SERIAL_ECHOLNPGM(MSG_POSITION_UNKNOWN);
                break; // abort G29, since we don't know where we are
            }

            st_synchronize();
            // make sure the bed_level_rotation_matrix is identity or the planner will get it incorectly
            //vector_3 corrected_position = plan_get_position_mm();
            //corrected_position.debug("position before G29");
            plan_bed_level_matrix.set_to_identity();
            vector_3 uncorrected_position = plan_get_position();
            //uncorrected_position.debug("position durring G29");
            current_position[X_AXIS] = uncorrected_position.x;
            current_position[Y_AXIS] = uncorrected_position.y;
            current_position[Z_AXIS] = uncorrected_position.z;
            plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
            setup_for_endstop_move();

            feedrate = homing_feedrate[Z_AXIS];
#ifdef AUTO_BED_LEVELING_GRID
            // probe at the points of a lattice grid

            int xGridSpacing = (RIGHT_PROBE_BED_POSITION - LEFT_PROBE_BED_POSITION) / (AUTO_BED_LEVELING_GRID_POINTS-1);
            int yGridSpacing = (BACK_PROBE_BED_POSITION - FRONT_PROBE_BED_POSITION) / (AUTO_BED_LEVELING_GRID_POINTS-1);


            // solve the plane equation ax + by + d = z
            // A is the matrix with rows [x y 1] for all the probed points
            // B is the vector of the Z positions
            // the normal vector to the plane is formed by the coefficients of the plane equation in the standard form, which is Vx*x+Vy*y+Vz*z+d = 0
            // so Vx = -a Vy = -b Vz = 1 (we want the vector facing towards positive Z

            // "A" matrix of the linear system of equations
            double eqnAMatrix[AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS*3];
            // "B" vector of Z points
            double eqnBVector[AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS];


            int probePointCounter = 0;
            bool zig = true;

            for (int yProbe=FRONT_PROBE_BED_POSITION; yProbe <= BACK_PROBE_BED_POSITION; yProbe += yGridSpacing)
            {
              int xProbe, xInc;
              if (zig)
              {
                xProbe = LEFT_PROBE_BED_POSITION;
                //xEnd = RIGHT_PROBE_BED_POSITION;
                xInc = xGridSpacing;
                zig = false;
              } else // zag
              {
                xProbe = RIGHT_PROBE_BED_POSITION;
                //xEnd = LEFT_PROBE_BED_POSITION;
                xInc = -xGridSpacing;
                zig = true;
              }

              for (int xCount=0; xCount < AUTO_BED_LEVELING_GRID_POINTS; xCount++)
              {
                float z_before;
                if (probePointCounter == 0)
                {
                  // raise before probing
                  z_before = Z_RAISE_BEFORE_PROBING;
                } else
                {
                  // raise extruder
                  z_before = current_position[Z_AXIS] + Z_RAISE_BETWEEN_PROBINGS;
                }

                float measured_z = probe_pt(xProbe, yProbe, z_before);

                eqnBVector[probePointCounter] = measured_z;

                eqnAMatrix[probePointCounter + 0*AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS] = xProbe;
                eqnAMatrix[probePointCounter + 1*AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS] = yProbe;
                eqnAMatrix[probePointCounter + 2*AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS] = 1;
                probePointCounter++;
                xProbe += xInc;
              }
            }
            clean_up_after_endstop_move();

            // solve lsq problem
            double *plane_equation_coefficients = qr_solve(AUTO_BED_LEVELING_GRID_POINTS*AUTO_BED_LEVELING_GRID_POINTS, 3, eqnAMatrix, eqnBVector);

            SERIAL_PROTOCOLPGM("Eqn coefficients: a: ");
            SERIAL_PROTOCOL(plane_equation_coefficients[0]);
            SERIAL_PROTOCOLPGM(" b: ");
            SERIAL_PROTOCOL(plane_equation_coefficients[1]);
            SERIAL_PROTOCOLPGM(" d: ");
            SERIAL_PROTOCOLLN(plane_equation_coefficients[2]);


            set_bed_level_equation_lsq(plane_equation_coefficients);

            free(plane_equation_coefficients);

#else // AUTO_BED_LEVELING_GRID not defined

            // Probe at 3 arbitrary points
            // probe 1
            float z_at_pt_1 = probe_pt(ABL_PROBE_PT_1_X, ABL_PROBE_PT_1_Y, Z_RAISE_BEFORE_PROBING);

            // probe 2
            float z_at_pt_2 = probe_pt(ABL_PROBE_PT_2_X, ABL_PROBE_PT_2_Y, current_position[Z_AXIS] + Z_RAISE_BETWEEN_PROBINGS);

            // probe 3
            float z_at_pt_3 = probe_pt(ABL_PROBE_PT_3_X, ABL_PROBE_PT_3_Y, current_position[Z_AXIS] + Z_RAISE_BETWEEN_PROBINGS);

            clean_up_after_endstop_move();

            set_bed_level_equation_3pts(z_at_pt_1, z_at_pt_2, z_at_pt_3);


#endif // AUTO_BED_LEVELING_GRID
            st_synchronize();

            // The following code correct the Z height difference from z-probe position and hotend tip position.
            // The Z height on homing is measured by Z-Probe, but the probe is quite far from the hotend.
            // When the bed is uneven, this height must be corrected.
            real_z = float(st_get_position(Z_AXIS))/axis_steps_per_unit[Z_AXIS];  //get the real Z (since the auto bed leveling is already correcting the plane)
            x_tmp = current_position[X_AXIS] + X_PROBE_OFFSET_FROM_EXTRUDER;
            y_tmp = current_position[Y_AXIS] + Y_PROBE_OFFSET_FROM_EXTRUDER;
            z_tmp = current_position[Z_AXIS];

            apply_rotation_xyz(plan_bed_level_matrix, x_tmp, y_tmp, z_tmp);         //Apply the correction sending the probe offset
            current_position[Z_AXIS] = z_tmp - real_z + current_position[Z_AXIS];   //The difference is added to current position and sent to planner.
            plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
        }
        break;

    case 30: // G30 Single Z Probe
        {
            engage_z_probe(); // Engage Z Servo endstop if available

            st_synchronize();
            // TODO: make sure the bed_level_rotation_matrix is identity or the planner will get set incorectly
            setup_for_endstop_move();

            feedrate = homing_feedrate[Z_AXIS];

            run_z_probe();
            SERIAL_PROTOCOLPGM(MSG_BED);
            SERIAL_PROTOCOLPGM(" X: ");
            SERIAL_PROTOCOL(current_position[X_AXIS]);
            SERIAL_PROTOCOLPGM(" Y: ");
            SERIAL_PROTOCOL(current_position[Y_AXIS]);
            SERIAL_PROTOCOLPGM(" Z: ");
            SERIAL_PROTOCOL(current_position[Z_AXIS]);
            SERIAL_PROTOCOLPGM("\n");

            clean_up_after_endstop_move();

            retract_z_probe(); // Retract Z Servo endstop if available
        }
        break;
#endif // ENABLE_AUTO_BED_LEVELING
    case 90: // G90
      relative_mode = false;
      break;
    case 91: // G91
      relative_mode = true;
      break;
    case 92: // G92
      if(!code_seen(axis_codes[E_AXIS]) && !code_seen(axis_codes[P_AXIS]))  //FMM added P_AXIS
        st_synchronize();
      for(int8_t i=0; i < NUM_AXIS; i++) {
        if(code_seen(axis_codes[i])) {
           if(i == E_AXIS) {
             current_position[i] = code_value();
             plan_set_e_position(current_position[E_AXIS]);
           }
           else if(i == P_AXIS){  //FMM Added P_AXIS logic
        	 current_position[i] = code_value();
        	 plan_set_p_position(current_position[P_AXIS]);  //FMM need to modify this function to handle P axis
           }
           else {
             current_position[i] = code_value()+add_homeing[i];
             plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], current_position[P_AXIS]);  //FMM added P_AXIS
           }
        }
      }
      break;
    }
  }

  else if(
    ({
      char *mcmd = cmdbuffer[bufindr];
      while (*mcmd == ' ' || *mcmd == '\t') mcmd++;
      if (fr3d_uc(*mcmd) == 'N') {
        while (*mcmd && *mcmd != ' ' && *mcmd != '\t') mcmd++;
        while (*mcmd == ' ' || *mcmd == '\t') mcmd++;
      }
      fr3d_uc(*mcmd) == 'M';
    })
    && !fr3d_line_is_compact_pman_or_paut()
  )
  {
    switch( (int)code_value() )
    {
#ifdef ULTIPANEL
    case 0: // M0 - Unconditional stop - Wait for user button press on LCD
    case 1: // M1 - Conditional stop - Wait for user button press on LCD
    {
      LCD_MESSAGEPGM(MSG_USERWAIT);
      codenum = 0;
      if(code_seen('P')) codenum = code_value(); // milliseconds to wait
      if(code_seen('S')) codenum = code_value() * 1000; // seconds to wait

      st_synchronize();
      previous_millis_cmd = millis();
      if (codenum > 0){
        codenum += millis();  // keep track of when we started waiting
        while(millis()  < codenum && !lcd_clicked()){
          manage_heater();
          manage_inactivity();
          lcd_update(encoderClicked, encoderLongPressed);
        }
      }else{
        while(!lcd_clicked()){
          manage_heater();
          manage_inactivity();
          lcd_update(encoderClicked, encoderLongPressed);
        }
      }
      LCD_MESSAGEPGM(MSG_RESUMING);
    }
    break;
#endif
    case 17:
        LCD_MESSAGEPGM(MSG_NO_MOVE);
        enable_x();
        enable_y();
        enable_z();
        enable_e0();
        enable_p();
        enable_e2();
      break;

#ifdef SDSUPPORT
    case 20: // M20 - list SD card
      SERIAL_PROTOCOLLNPGM(MSG_BEGIN_FILE_LIST);
      card.ls();
      SERIAL_PROTOCOLLNPGM(MSG_END_FILE_LIST);
      break;
    case 21: // M21 - init SD card

      card.initsd();

      break;
    case 22: //M22 - release SD card
      card.release();

      break;
    case 23: //M23 - Select file
      starpos = (strchr(strchr_pointer + 4,'*'));
      if(starpos!=NULL)
        *(starpos-1)='\0';
      card.openFile(strchr_pointer + 4,true);
      break;
    case 24: //M24 - Start SD print
      card.startFileprint();
      starttime=millis();
      break;
    case 25: //M25 - Pause SD print
      card.pauseSDPrint();
      break;
    case 26: //M26 - Set SD index
      if(card.cardOK && code_seen('S')) {
        card.setIndex(code_value_long());
      }
      break;
    case 27: //M27 - Get SD status
      card.getStatus();
      break;
    case 28: //M28 - Start SD write
      starpos = (strchr(strchr_pointer + 4,'*'));
      if(starpos != NULL){
        char* npos = strchr(cmdbuffer[bufindr], 'N');
        strchr_pointer = strchr(npos,' ') + 1;
        *(starpos-1) = '\0';
      }
      card.openFile(strchr_pointer+4,false);
      break;
    case 29: //M29 - Stop SD write
      //processed in write to file routine above
      //card,saving = false;
      break;
    case 30: //M30 <filename> Delete File
      if (card.cardOK){
        card.closefile();
        starpos = (strchr(strchr_pointer + 4,'*'));
        if(starpos != NULL){
          char* npos = strchr(cmdbuffer[bufindr], 'N');
          strchr_pointer = strchr(npos,' ') + 1;
          *(starpos-1) = '\0';
        }
        card.removeFile(strchr_pointer + 4);
      }
      break;
    case 32: //M32 - Select file and start SD print
    {
      if(card.sdprinting) {
        st_synchronize();

      }
      starpos = (strchr(strchr_pointer + 4,'*'));

      char* namestartpos = (strchr(strchr_pointer + 4,'!'));   //find ! to indicate filename string start.
      if(namestartpos==NULL)
      {
        namestartpos=strchr_pointer + 4; //default name position, 4 letters after the M
      }
      else
        namestartpos++; //to skip the '!'

      if(starpos!=NULL)
        *(starpos-1)='\0';

      bool call_procedure=(code_seen('P'));

      if(strchr_pointer>namestartpos)
        call_procedure=false;  //false alert, 'P' found within filename

      if( card.cardOK )
      {
        card.openFile(namestartpos,true,!call_procedure);
        if(code_seen('S'))
          if(strchr_pointer<namestartpos) //only if "S" is occuring _before_ the filename
            card.setIndex(code_value_long());
        card.startFileprint();
        if(!call_procedure)
          starttime=millis(); //procedure calls count as normal print time.
      }
    } break;
    case 928: //M928 - Start SD write
      starpos = (strchr(strchr_pointer + 5,'*'));
      if(starpos != NULL){
        char* npos = strchr(cmdbuffer[bufindr], 'N');
        strchr_pointer = strchr(npos,' ') + 1;
        *(starpos-1) = '\0';
      }
      card.openLogFile(strchr_pointer+5);
      break;

#endif //SDSUPPORT

    case 31: //M31 take time since the start of the SD print or an M109 command
      {
      stoptime=millis();
      char time[30];
      unsigned long t=(stoptime-starttime)/1000;
      int sec,min;
      min=t/60;
      sec=t%60;
      sprintf_P(time, PSTR("%i min, %i sec"), min, sec);
      SERIAL_ECHO_START;
      SERIAL_ECHOLN(time);
      lcd_setstatus(time);
      autotempShutdown();
      }
      break;
    case 42: //M42 -Change pin status via gcode
      if (code_seen('S'))
      {
        int pin_status = code_value();
        int pin_number = LED_PIN;
        if (code_seen('P') && pin_status >= 0 && pin_status <= 255)
          pin_number = code_value();
        for(int8_t i = 0; i < (int8_t)sizeof(sensitive_pins); i++)
        {
          if (sensitive_pins[i] == pin_number)
          {
            pin_number = -1;
            break;
          }
        }
      #if defined(WINDER_PIN) && WINDER_PIN > -1
        if (pin_number == WINDER_PIN)
          winderSpeed = pin_status;
      #endif
        if (pin_number > -1)
        {
          pinMode(pin_number, OUTPUT);
          digitalWrite(pin_number, pin_status);
          analogWrite(pin_number, pin_status);
        }
      }
     break;
    case 104: // M104
      if(setTargetedHotend(104)){
        break;
      }
      if (code_seen('S')) setTargetHotend(code_value(), tmp_extruder);
#ifdef DUAL_X_CARRIAGE
      if (dual_x_carriage_mode == DXC_DUPLICATION_MODE && tmp_extruder == 0)
        setTargetHotend1(code_value() == 0.0 ? 0.0 : code_value() + duplicate_extruder_temp_offset);
#endif
      setWatch();
      break;
    case 140: // M140 set bed temp
      if (code_seen('S')) setTargetBed(code_value());
      break;
    case 105 : // M105
      if(setTargetedHotend(105)){
        break;
        }
      #if defined(TEMP_0_PIN) && TEMP_0_PIN > -1
        SERIAL_PROTOCOLPGM("ok T:");
        SERIAL_PROTOCOL_F(degHotend(tmp_extruder),1);
        SERIAL_PROTOCOLPGM(" /");
        SERIAL_PROTOCOL_F(degTargetHotend(tmp_extruder),1);
        #if defined(TEMP_BED_PIN) && TEMP_BED_PIN > -1
          SERIAL_PROTOCOLPGM(" B:");
          SERIAL_PROTOCOL_F(degBed(),1);
          SERIAL_PROTOCOLPGM(" /");
          SERIAL_PROTOCOL_F(degTargetBed(),1);
        #endif //TEMP_BED_PIN
        for (int8_t cur_extruder = 0; cur_extruder < EXTRUDERS; ++cur_extruder) {
          SERIAL_PROTOCOLPGM(" T");
          SERIAL_PROTOCOL(cur_extruder);
          SERIAL_PROTOCOLPGM(":");
          SERIAL_PROTOCOL_F(degHotend(cur_extruder),1);
          SERIAL_PROTOCOLPGM(" /");
          SERIAL_PROTOCOL_F(degTargetHotend(cur_extruder),1);
        }
      #else
        SERIAL_ERROR_START;
        SERIAL_ERRORLNPGM(MSG_ERR_NO_THERMISTORS);
      #endif

        SERIAL_PROTOCOLPGM(" @:");
      #ifdef EXTRUDER_WATTS
        SERIAL_PROTOCOL((EXTRUDER_WATTS * getHeaterPower(tmp_extruder))/127);
        SERIAL_PROTOCOLPGM("W");
      #else
        SERIAL_PROTOCOL(getHeaterPower(tmp_extruder));
      #endif

        SERIAL_PROTOCOLPGM(" B@:");
      #ifdef BED_WATTS
        SERIAL_PROTOCOL((BED_WATTS * getHeaterPower(-1))/127);
        SERIAL_PROTOCOLPGM("W");
      #else
        SERIAL_PROTOCOL(getHeaterPower(-1));
      #endif

        #ifdef SHOW_TEMP_ADC_VALUES
          #if defined(TEMP_BED_PIN) && TEMP_BED_PIN > -1
            SERIAL_PROTOCOLPGM("    ADC B:");
            SERIAL_PROTOCOL_F(degBed(),1);
            SERIAL_PROTOCOLPGM("C->");
            SERIAL_PROTOCOL_F(rawBedTemp()/OVERSAMPLENR,0);
          #endif
          for (int8_t cur_extruder = 0; cur_extruder < EXTRUDERS; ++cur_extruder) {
            SERIAL_PROTOCOLPGM("  T");
            SERIAL_PROTOCOL(cur_extruder);
            SERIAL_PROTOCOLPGM(":");
            SERIAL_PROTOCOL_F(degHotend(cur_extruder),1);
            SERIAL_PROTOCOLPGM("C->");
            SERIAL_PROTOCOL_F(rawHotendTemp(cur_extruder)/OVERSAMPLENR,0);
          }
        #endif

        SERIAL_PROTOCOLLN("");
      return;
      break;
    case 109:
    {// M109 - Wait for extruder heater to reach target.
      if(setTargetedHotend(109)){
        break;
      }
      LCD_MESSAGEPGM(MSG_HEATING);
      #ifdef AUTOTEMP
        autotemp_enabled=false;
      #endif
      if (code_seen('S')) {
        setTargetHotend(code_value(), tmp_extruder);
#ifdef DUAL_X_CARRIAGE
        if (dual_x_carriage_mode == DXC_DUPLICATION_MODE && tmp_extruder == 0)
          setTargetHotend1(code_value() == 0.0 ? 0.0 : code_value() + duplicate_extruder_temp_offset);
#endif
        CooldownNoWait = true;
      } else if (code_seen('R')) {
        setTargetHotend(code_value(), tmp_extruder);
#ifdef DUAL_X_CARRIAGE
        if (dual_x_carriage_mode == DXC_DUPLICATION_MODE && tmp_extruder == 0)
          setTargetHotend1(code_value() == 0.0 ? 0.0 : code_value() + duplicate_extruder_temp_offset);
#endif
        CooldownNoWait = false;
      }
      #ifdef AUTOTEMP
        if (code_seen('S')) autotemp_min=code_value();
        if (code_seen('B')) autotemp_max=code_value();
        if (code_seen('F'))
        {
          autotemp_factor=code_value();
          autotemp_enabled=true;
        }
      #endif

      setWatch();
      codenum = millis();

      /* See if we are heating up or cooling down */
      target_direction = isHeatingHotend(tmp_extruder); // true if heating, false if cooling

      #ifdef TEMP_RESIDENCY_TIME
        long residencyStart;
        residencyStart = -1;
        /* continue to loop until we have reached the target temp
          _and_ until TEMP_RESIDENCY_TIME hasn't passed since we reached it */
        while((residencyStart == -1) ||
              (residencyStart >= 0 && (((unsigned int) (millis() - residencyStart)) < (TEMP_RESIDENCY_TIME * 1000UL))) ) {
      #else
        while ( target_direction ? (isHeatingHotend(tmp_extruder)) : (isCoolingHotend(tmp_extruder)&&(CooldownNoWait==false)) ) {
      #endif //TEMP_RESIDENCY_TIME
          if( (millis() - codenum) > 1000UL )
          { //Print Temp Reading and remaining time every 1 second while heating up/cooling down
            SERIAL_PROTOCOLPGM("T:");
            SERIAL_PROTOCOL_F(degHotend(tmp_extruder),1);
            SERIAL_PROTOCOLPGM(" E:");
            SERIAL_PROTOCOL((int)tmp_extruder);
            #ifdef TEMP_RESIDENCY_TIME
              SERIAL_PROTOCOLPGM(" W:");
              if(residencyStart > -1)
              {
                 codenum = ((TEMP_RESIDENCY_TIME * 1000UL) - (millis() - residencyStart)) / 1000UL;
                 SERIAL_PROTOCOLLN( codenum );
              }
              else
              {
                 SERIAL_PROTOCOLLN( "?" );
              }
            #else
              SERIAL_PROTOCOLLN("");
            #endif
            codenum = millis();
          }
          manage_heater();
          manage_inactivity();
          lcd_update(encoderClicked, encoderLongPressed);
        #ifdef TEMP_RESIDENCY_TIME
            /* start/restart the TEMP_RESIDENCY_TIME timer whenever we reach target temp for the first time
              or when current temp falls outside the hysteresis after target temp was reached */
          if ((residencyStart == -1 &&  target_direction && (degHotend(tmp_extruder) >= (degTargetHotend(tmp_extruder)-TEMP_WINDOW))) ||
              (residencyStart == -1 && !target_direction && (degHotend(tmp_extruder) <= (degTargetHotend(tmp_extruder)+TEMP_WINDOW))) ||
              (residencyStart > -1 && labs(degHotend(tmp_extruder) - degTargetHotend(tmp_extruder)) > TEMP_HYSTERESIS) )
          {
            residencyStart = millis();
          }
        #endif //TEMP_RESIDENCY_TIME
        }
        // LCD_MESSAGEPGM(MSG_HEATING_COMPLETE);
        starttime=millis();
        previous_millis_cmd = millis();
      }
      break;
    case 190: // M190 - Wait for bed heater to reach target.
    #if defined(TEMP_BED_PIN) && TEMP_BED_PIN > -1
        LCD_MESSAGEPGM(MSG_BED_HEATING);
        if (code_seen('S')) {
          setTargetBed(code_value());
          CooldownNoWait = true;
        } else if (code_seen('R')) {
          setTargetBed(code_value());
          CooldownNoWait = false;
        }
        codenum = millis();

        target_direction = isHeatingBed(); // true if heating, false if cooling

        while ( target_direction ? (isHeatingBed()) : (isCoolingBed()&&(CooldownNoWait==false)) )
        {
          if(( millis() - codenum) > 1000 ) //Print Temp Reading every 1 second while heating up.
          {
            float tt=degHotend(active_extruder);
            SERIAL_PROTOCOLPGM("T:");
            SERIAL_PROTOCOL(tt);
            SERIAL_PROTOCOLPGM(" E:");
            SERIAL_PROTOCOL((int)active_extruder);
            SERIAL_PROTOCOLPGM(" B:");
            SERIAL_PROTOCOL_F(degBed(),1);
            SERIAL_PROTOCOLLN("");
            codenum = millis();
          }
          manage_heater();
          manage_inactivity();
          lcd_update(encoderClicked, encoderLongPressed);
        }
        LCD_MESSAGEPGM(MSG_BED_DONE);
        previous_millis_cmd = millis();
    #endif
        break;

    #if defined(WINDER_PIN) && WINDER_PIN > -1
      case 106: //M106 Fan On
        if (code_seen('S')){
           winderSpeed=constrain(code_value(),0,255);
        }
        else {
          winderSpeed=255;
        }
        break;
      case 107: //M107 Fan Off
        winderSpeed = 0;
        break;
    #endif //WINDER_PIN
    #ifdef BARICUDA
      // PWM for HEATER_1_PIN
      #if defined(HEATER_1_PIN) && HEATER_1_PIN > -1
        case 126: //M126 valve open
          if (code_seen('S')){
             ValvePressure=constrain(code_value(),0,255);
          }
          else {
            ValvePressure=255;
          }
          break;
        case 127: //M127 valve closed
          ValvePressure = 0;
          break;
      #endif //HEATER_1_PIN

      // PWM for HEATER_2_PIN
      #if defined(HEATER_2_PIN) && HEATER_2_PIN > -1
        case 128: //M128 valve open
          if (code_seen('S')){
             EtoPPressure=constrain(code_value(),0,255);
          }
          else {
            EtoPPressure=255;
          }
          break;
        case 129: //M129 valve closed
          EtoPPressure = 0;
          break;
      #endif //HEATER_2_PIN
    #endif

    #if defined(PS_ON_PIN) && PS_ON_PIN > -1
      case 80: // M80 - Turn on Power Supply
        SET_OUTPUT(PS_ON_PIN); //GND
        WRITE(PS_ON_PIN, PS_ON_AWAKE);

        // If you have a switch on suicide pin, this is useful
        // if you want to start another print with suicide feature after
        // a print without suicide...
        #if defined SUICIDE_PIN && SUICIDE_PIN > -1
            SET_OUTPUT(SUICIDE_PIN);
            WRITE(SUICIDE_PIN, HIGH);
        #endif

        #ifdef ULTIPANEL
          powersupply = true;
          LCD_MESSAGEPGM(WELCOME_MSG);
          lcd_update(encoderClicked, encoderLongPressed);
        #endif
        break;
      #endif

      case 81: // M81 - Turn off Power Supply
        disable_heater();
        st_synchronize();
        disable_e0();
        disable_p();
        disable_e2();
        finishAndDisableSteppers();
        winderSpeed = 0;
        delay(1000); // Wait a little before to switch off
      #if defined(SUICIDE_PIN) && SUICIDE_PIN > -1
        st_synchronize();
        suicide();
      #elif defined(PS_ON_PIN) && PS_ON_PIN > -1
        SET_OUTPUT(PS_ON_PIN);
        WRITE(PS_ON_PIN, PS_ON_ASLEEP);
      #endif
      #ifdef ULTIPANEL
        powersupply = false;
        LCD_MESSAGEPGM(MACHINE_NAME" "MSG_OFF".");
        lcd_update(encoderClicked, encoderLongPressed);
      #endif
	  break;

    case 82:
      axis_relative_modes[3] = false;
      break;
    case 83:
      axis_relative_modes[3] = true;
      break;
    case 18: //compatibility
    case 84: // M84
      if(code_seen('S')){
        stepper_inactive_time = code_value() * 1000;
      }
      else
      {
        bool all_axis = !((code_seen(axis_codes[X_AXIS])) || (code_seen(axis_codes[Y_AXIS])) || (code_seen(axis_codes[Z_AXIS]))|| (code_seen(axis_codes[E_AXIS]))||(code_seen(axis_codes[P_AXIS])));  //FMM added P_AXIS
        if(all_axis)
        {
          st_synchronize();
          disable_e0();
          disable_p();
          disable_e2();
          finishAndDisableSteppers();
        }
        else
        {
          st_synchronize();
          if(code_seen('X')) disable_x();
          if(code_seen('Y')) disable_y();
          if(code_seen('Z')) disable_z();
          #if ((E0_ENABLE_PIN != X_ENABLE_PIN) && (E1_ENABLE_PIN != Y_ENABLE_PIN)) // Only enable on boards that have seperate ENABLE_PINS
            if(code_seen('E')) {
              disable_e0();
              disable_p();
              disable_e2();
            }
          #endif
        }
      }
      break;
    case 85: // M85
      code_seen('S');
      max_inactive_time = code_value() * 1000;
      break;
    case 92: // M92
      for(int8_t i=0; i < NUM_AXIS; i++)
      {
        if(code_seen(axis_codes[i]))
        {
          if(i == 3) { // E
            float value = code_value();
            if(value < 20.0) {
              float factor = axis_steps_per_unit[i] / value; // increase e constants if M92 E14 is given for netfab.
              max_e_jerk *= factor;
              max_feedrate[i] *= factor;
              axis_steps_per_sqr_second[i] *= factor;
            }
            axis_steps_per_unit[i] = value;
          }
          else {
            axis_steps_per_unit[i] = code_value();
          }
        }
      }
      break;
    case 115: // M115
      SERIAL_PROTOCOLPGM(MSG_M115_REPORT);
      break;
    case 117: // M117 display message
      starpos = (strchr(strchr_pointer + 5,'*'));
      if(starpos!=NULL)
        *(starpos-1)='\0';
      lcd_setstatus(strchr_pointer + 5);
      break;
    case 114: // M114
      SERIAL_PROTOCOLPGM("X:");
      SERIAL_PROTOCOL(current_position[X_AXIS]);
      SERIAL_PROTOCOLPGM(" Y:");
      SERIAL_PROTOCOL(current_position[Y_AXIS]);
      SERIAL_PROTOCOLPGM(" Z:");
      SERIAL_PROTOCOL(current_position[Z_AXIS]);
      SERIAL_PROTOCOLPGM(" E:");
      SERIAL_PROTOCOL(current_position[E_AXIS]);
      SERIAL_PROTOCOLPGM(" P:");				//FMM added P_AXIS
      SERIAL_PROTOCOL(current_position[P_AXIS]);
            
      SERIAL_PROTOCOLPGM(MSG_COUNT_X);
      SERIAL_PROTOCOL(float(st_get_position(X_AXIS))/axis_steps_per_unit[X_AXIS]);
      SERIAL_PROTOCOLPGM(" Y:");
      SERIAL_PROTOCOL(float(st_get_position(Y_AXIS))/axis_steps_per_unit[Y_AXIS]);
      SERIAL_PROTOCOLPGM(" Z:");
      SERIAL_PROTOCOL(float(st_get_position(Z_AXIS))/axis_steps_per_unit[Z_AXIS]);

      SERIAL_PROTOCOLLN("");
      break;
    case 120: // M120
      enable_endstops(false) ;
      break;
    case 121: // M121
      enable_endstops(true) ;
      break;
    case 119: // M119
    SERIAL_PROTOCOLLN(MSG_M119_REPORT);
      #if defined(X_MIN_PIN) && X_MIN_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_X_MIN);
        SERIAL_PROTOCOLLN(((READ(X_MIN_PIN)^X_MIN_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      #if defined(X_MAX_PIN) && X_MAX_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_X_MAX);
        SERIAL_PROTOCOLLN(((READ(X_MAX_PIN)^X_MAX_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      #if defined(Y_MIN_PIN) && Y_MIN_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_Y_MIN);
        SERIAL_PROTOCOLLN(((READ(Y_MIN_PIN)^Y_MIN_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      #if defined(Y_MAX_PIN) && Y_MAX_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_Y_MAX);
        SERIAL_PROTOCOLLN(((READ(Y_MAX_PIN)^Y_MAX_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      #if defined(Z_MIN_PIN) && Z_MIN_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_Z_MIN);
        SERIAL_PROTOCOLLN(((READ(Z_MIN_PIN)^Z_MIN_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      #if defined(Z_MAX_PIN) && Z_MAX_PIN > -1
        SERIAL_PROTOCOLPGM(MSG_Z_MAX);
        SERIAL_PROTOCOLLN(((READ(Z_MAX_PIN)^Z_MAX_ENDSTOP_INVERTING)?MSG_ENDSTOP_HIT:MSG_ENDSTOP_OPEN));
      #endif
      break;
      //TODO: update for all axis, use for loop
    #ifdef BLINKM
    case 150: // M150
      {
        byte red;
        byte grn;
        byte blu;

        if(code_seen('R')) red = code_value();
        if(code_seen('U')) grn = code_value();
        if(code_seen('B')) blu = code_value();

        SendColors(red,grn,blu);
      }
      break;
    #endif //BLINKM
    case 200: // M200 D<millimeters> set filament diameter and set E axis units to cubic millimeters (use S0 to set back to millimeters).
      {
        float area = .0;
        float radius = .0;
        if(code_seen('D')) {
          radius = (float)code_value() * .5;
          if(radius == 0) {
            area = 1;
          } else {
            area = M_PI * pow(radius, 2);
          }
        } else {
          //reserved for setting filament diameter via UFID or filament measuring device
          break;
        }
        tmp_extruder = active_extruder;
        if(code_seen('T')) {
          tmp_extruder = code_value();
          if(tmp_extruder >= EXTRUDERS) {
            SERIAL_ECHO_START;
            SERIAL_ECHO(MSG_M200_INVALID_EXTRUDER);
          }
          SERIAL_ECHOLN(tmp_extruder);
          break;
        }
        volumetric_multiplier[tmp_extruder] = 1 / area;
      }
      break;
    case 201: // M201
      for(int8_t i=0; i < NUM_AXIS; i++)
      {
        if(code_seen(axis_codes[i]))
        {
          max_acceleration_units_per_sq_second[i] = code_value();
        }
      }
      // steps per sq second need to be updated to agree with the units per sq second (as they are what is used in the planner)
      reset_acceleration_rates();
      break;
    #if 0 // Not used for Sprinter/grbl gen6
    case 202: // M202
      for(int8_t i=0; i < NUM_AXIS; i++) {
        if(code_seen(axis_codes[i])) axis_travel_steps_per_sqr_second[i] = code_value() * axis_steps_per_unit[i];
      }
      break;
    #endif
    case 203: // M203 max feedrate mm/sec
      for(int8_t i=0; i < NUM_AXIS; i++) {
        if(code_seen(axis_codes[i])) max_feedrate[i] = code_value();
      }
      break;
    case 204: // M204 acclereration S normal moves T filmanent only moves
      {
        if(code_seen('S')) acceleration = code_value() ;
        if(code_seen('T')) retract_acceleration = code_value() ;
      }
      break;
    case 205: //M205 advanced settings:  minimum travel speed S=while printing T=travel only,  B=minimum segment time X= maximum xy jerk, Z=maximum Z jerk
    {
      if(code_seen('S')) minimumfeedrate = code_value();
      if(code_seen('T')) mintravelfeedrate = code_value();
      if(code_seen('B')) minsegmenttime = code_value() ;
      if(code_seen('X')) max_xy_jerk = code_value() ;
      if(code_seen('Z')) max_z_jerk = code_value() ;
      if(code_seen('E')) max_e_jerk = code_value() ;
    }
    break;
    case 206: // M206 additional homeing offset
      for(int8_t i=0; i < 3; i++)
      {
        if(code_seen(axis_codes[i])) add_homeing[i] = code_value();
      }
      break;
    #ifdef DELTA
	case 665: // M665 set delta configurations L<diagonal_rod> R<delta_radius> S<segments_per_sec>
		if(code_seen('L')) {
			delta_diagonal_rod= code_value();
		}
		if(code_seen('R')) {
			delta_radius= code_value();
		}
		if(code_seen('S')) {
			delta_segments_per_second= code_value();
		}
		
		recalc_delta_settings(delta_radius, delta_diagonal_rod);
		break;
    case 666: // M666 set delta endstop adjustemnt
      for(int8_t i=0; i < 3; i++)
      {
        if(code_seen(axis_codes[i])) endstop_adj[i] = code_value();
      }
      break;
    #endif
    #ifdef FWRETRACT
    case 207: //M207 - set retract length S[positive mm] F[feedrate mm/sec] Z[additional zlift/hop]
    {
      if(code_seen('S'))
      {
        retract_length = code_value() ;
      }
      if(code_seen('F'))
      {
        retract_feedrate = code_value() ;
      }
      if(code_seen('Z'))
      {
        retract_zlift = code_value() ;
      }
    }break;
    case 208: // M208 - set retract recover length S[positive mm surplus to the M207 S*] F[feedrate mm/sec]
    {
      if(code_seen('S'))
      {
        retract_recover_length = code_value() ;
      }
      if(code_seen('F'))
      {
        retract_recover_feedrate = code_value() ;
      }
    }break;
    case 209: // M209 - S<1=true/0=false> enable automatic retract detect if the slicer did not support G10/11: every normal extrude-only move will be classified as retract depending on the direction.
    {
      if(code_seen('S'))
      {
        int t= code_value() ;
        switch(t)
        {
          case 0: autoretract_enabled=false;retracted=false;break;
          case 1: autoretract_enabled=true;retracted=false;break;
          default:
            SERIAL_ECHO_START;
            SERIAL_ECHOPGM(MSG_UNKNOWN_COMMAND);
            SERIAL_ECHO(cmdbuffer[bufindr]);
            SERIAL_ECHOLNPGM("\"");
        }
      }

    }break;
    #endif // FWRETRACT
    #if EXTRUDERS > 1
    case 218: // M218 - set hotend offset (in mm), T<extruder_number> X<offset_on_X> Y<offset_on_Y>
    {
      if(setTargetedHotend(218)){
        break;
      }
      if(code_seen('X'))
      {
        extruder_offset[X_AXIS][tmp_extruder] = code_value();
      }
      if(code_seen('Y'))
      {
        extruder_offset[Y_AXIS][tmp_extruder] = code_value();
      }
      #ifdef DUAL_X_CARRIAGE
      if(code_seen('Z'))
      {
        extruder_offset[Z_AXIS][tmp_extruder] = code_value();
      }
      #endif
      SERIAL_ECHO_START;
      SERIAL_ECHOPGM(MSG_HOTEND_OFFSET);
      for(tmp_extruder = 0; tmp_extruder < EXTRUDERS; tmp_extruder++)
      {
         SERIAL_ECHO(" ");
         SERIAL_ECHO(extruder_offset[X_AXIS][tmp_extruder]);
         SERIAL_ECHO(",");
         SERIAL_ECHO(extruder_offset[Y_AXIS][tmp_extruder]);
      #ifdef DUAL_X_CARRIAGE
         SERIAL_ECHO(",");
         SERIAL_ECHO(extruder_offset[Z_AXIS][tmp_extruder]);
      #endif
      }
      SERIAL_ECHOLN("");
    }break;
    #endif
    case 220: // M220 S<factor in percent>- set speed factor override percentage
    {
      if(code_seen('S'))
      {
        feedmultiply = code_value() ;
      }
    }
    break;
    case 221: // M221 S<factor in percent>- set extrude factor override percentage
    {
      if(code_seen('S'))
      {
        int tmp_code = code_value();
        if (code_seen('T'))
        {
          if(setTargetedHotend(221)){
            break;
          }
          extruder_multiply[tmp_extruder] = tmp_code;
        }
        else
        {
          extrudemultiply = tmp_code ;
        }
      }
    }
    break;

	case 226: // M226 P<pin number> S<pin state>- Wait until the specified pin reaches the state required
	{
      if(code_seen('P')){
        int pin_number = code_value(); // pin number
        int pin_state = -1; // required pin state - default is inverted

        if(code_seen('S')) pin_state = code_value(); // required pin state

        if(pin_state >= -1 && pin_state <= 1){

          for(int8_t i = 0; i < (int8_t)sizeof(sensitive_pins); i++)
          {
            if (sensitive_pins[i] == pin_number)
            {
              pin_number = -1;
              break;
            }
          }

          if (pin_number > -1)
          {
            st_synchronize();

            pinMode(pin_number, INPUT);

            int target;
            switch(pin_state){
            case 1:
              target = HIGH;
              break;

            case 0:
              target = LOW;
              break;

            case -1:
              target = !digitalRead(pin_number);
              break;
            }

            while(digitalRead(pin_number) != target){
              manage_heater();
              manage_inactivity();
              lcd_update(encoderClicked, encoderLongPressed);
            }
          }
        }
      }
    }
    break;

    #if NUM_SERVOS > 0
    case 280: // M280 - set servo position absolute. P: servo index, S: angle or microseconds
      {
        int servo_index = -1;
        int servo_position = 0;
        if (code_seen('P'))
          servo_index = code_value();
        if (code_seen('S')) {
          servo_position = code_value();
          if ((servo_index >= 0) && (servo_index < NUM_SERVOS)) {
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
		      servos[servo_index].attach(0);
#endif
            servos[servo_index].write(servo_position);
#if defined (ENABLE_AUTO_BED_LEVELING) && (PROBE_SERVO_DEACTIVATION_DELAY > 0)
              delay(PROBE_SERVO_DEACTIVATION_DELAY);
              servos[servo_index].detach();
#endif
          }
          else {
            SERIAL_ECHO_START;
            SERIAL_ECHO("Servo ");
            SERIAL_ECHO(servo_index);
            SERIAL_ECHOLN(" out of range");
          }
        }
        else if (servo_index >= 0) {
          SERIAL_PROTOCOL(MSG_OK);
          SERIAL_PROTOCOL(" Servo ");
          SERIAL_PROTOCOL(servo_index);
          SERIAL_PROTOCOL(": ");
          SERIAL_PROTOCOL(servos[servo_index].read());
          SERIAL_PROTOCOLLN("");
        }
      }
      break;
    #endif // NUM_SERVOS > 0

    #if (LARGE_FLASH == true && ( BEEPER > 0 || defined(ULTRALCD) || defined(LCD_USE_I2C_BUZZER)))
    case 300: // M300
    {
      int beepS = code_seen('S') ? code_value() : 110;
      int beepP = code_seen('P') ? code_value() : 1000;
      if (beepS > 0)
      {
        #if BEEPER > 0
          tone(BEEPER, beepS);
          delay(beepP);
          noTone(BEEPER);
        #elif defined(ULTRALCD)
		  lcd_buzz(beepS, beepP);
		#elif defined(LCD_USE_I2C_BUZZER)
		  lcd_buzz(beepP, beepS);
        #endif
      }
      else
      {
        delay(beepP);
      }
    }
    break;
    #endif // M300

    #ifdef PIDTEMP
    case 301: // M301
      {
        if(code_seen('P')) Kp = code_value();
        if(code_seen('I')) Ki = scalePID_i(code_value());
        if(code_seen('D')) Kd = scalePID_d(code_value());

        #ifdef PID_ADD_EXTRUSION_RATE
        if(code_seen('C')) Kc = code_value();
        #endif

        updatePID();
        SERIAL_PROTOCOL(MSG_OK);
        SERIAL_PROTOCOL(" p:");
        SERIAL_PROTOCOL(Kp);
        SERIAL_PROTOCOL(" i:");
        SERIAL_PROTOCOL(unscalePID_i(Ki));
        SERIAL_PROTOCOL(" d:");
        SERIAL_PROTOCOL(unscalePID_d(Kd));
        #ifdef PID_ADD_EXTRUSION_RATE
        SERIAL_PROTOCOL(" c:");
        //Kc does not have scaling applied above, or in resetting defaults
        SERIAL_PROTOCOL(Kc);
        #endif
        SERIAL_PROTOCOLLN("");
      }
      break;
    #endif //PIDTEMP
    //#ifdef PIDTEMPBED
    case 304: // M304
      {
        if(code_seen('P')) fwidthKp = code_value();
        if(code_seen('I')) fwidthKi = scalePID_i(code_value());
        if(code_seen('D')) fwidthKd = scalePID_d(code_value());

        updatePID();
        SERIAL_PROTOCOL(MSG_OK);
        SERIAL_PROTOCOL(" p:");
        SERIAL_PROTOCOL(fwidthKp);
        SERIAL_PROTOCOL(" i:");
        SERIAL_PROTOCOL(unscalePID_i(fwidthKi));
        SERIAL_PROTOCOL(" d:");
        SERIAL_PROTOCOL(unscalePID_d(fwidthKd));
        SERIAL_PROTOCOLLN("");
      }
      break;
    //#endif //PIDTEMP
    case 240: // M240  Triggers a camera by emulating a Canon RC-1 : http://www.doc-diy.net/photo/rc-1_hacked/
     {
     	#ifdef CHDK
       
         SET_OUTPUT(CHDK);
         WRITE(CHDK, HIGH);
         chdkHigh = millis();
         chdkActive = true;
       
       #else
     	
      	#if defined(PHOTOGRAPH_PIN) && PHOTOGRAPH_PIN > -1
	const uint8_t NUM_PULSES=16;
	const float PULSE_LENGTH=0.01524;
	for(int i=0; i < NUM_PULSES; i++) {
        WRITE(PHOTOGRAPH_PIN, HIGH);
        _delay_ms(PULSE_LENGTH);
        WRITE(PHOTOGRAPH_PIN, LOW);
        _delay_ms(PULSE_LENGTH);
        }
        delay(7.33);
        for(int i=0; i < NUM_PULSES; i++) {
        WRITE(PHOTOGRAPH_PIN, HIGH);
        _delay_ms(PULSE_LENGTH);
        WRITE(PHOTOGRAPH_PIN, LOW);
        _delay_ms(PULSE_LENGTH);
        }
      	#endif
      #endif //chdk end if
     }
    break;
#ifdef DOGLCD
    case 250: // M250  Set LCD contrast value: C<value> (value 0..63)
     {
	  if (code_seen('C')) {
	   lcd_setcontrast( ((int)code_value())&63 );
          }
          SERIAL_PROTOCOLPGM("lcd contrast value: ");
          SERIAL_PROTOCOL(lcd_contrast);
          SERIAL_PROTOCOLLN("");
     }
    break;
#endif
    #ifdef PREVENT_DANGEROUS_EXTRUDE
    case 302: // allow cold extrudes, or set the minimum extrude temperature
    {
	  float temp = .0;
	  if (code_seen('S')) temp=code_value();
      set_extrude_min_temp(temp);
    }
    break;
	#endif
    case 303: // M303 PID autotune
    {
      float temp = 190.0;
      int e=0;
      int c=5;
      if (code_seen('E')) e=code_value();
        if (e<0)
          temp=70;
      if (code_seen('S')) temp=code_value();
      if (code_seen('C')) c=code_value();
      PID_autotune(temp, e, c);
    }
    break;
    case 400: // M400 finish all moves
    {
      st_synchronize();
    }
    break;
#if defined(ENABLE_AUTO_BED_LEVELING) && defined(SERVO_ENDSTOPS)
    case 401:
    {
        engage_z_probe();    // Engage Z Servo endstop if available
    }
    break;

    case 402:
    {
        retract_z_probe();    // Retract Z Servo endstop if enabled
    }
    break;
#endif
    case 500: // M500 Store settings in EEPROM
    {
        Config_StoreSettings();
    }
    break;
    case 501: // M501 Read settings from EEPROM
    {
        Config_RetrieveSettings();
    }
    break;
    case 502: // M502 Revert to default settings
    {
        Config_ResetDefault();
    }
    break;
    case 503: // M503 print settings currently in memory
    {
        Config_PrintSettings();
    }
    break;
    #ifdef ABORT_ON_ENDSTOP_HIT_FEATURE_ENABLED
    case 540:
    {
        if(code_seen('S')) abort_on_endstop_hit = code_value() > 0;
    }
    break;
    #endif
    #ifdef FILAMENTCHANGEENABLE
    case 600: //Pause for filament change X[pos] Y[pos] Z[relative lift] E[initial retract] L[later retract distance for removal]
    {
        float target[4];
        float lastpos[4];
        target[X_AXIS]=current_position[X_AXIS];
        target[Y_AXIS]=current_position[Y_AXIS];
        target[Z_AXIS]=current_position[Z_AXIS];
        target[E_AXIS]=current_position[E_AXIS];
        target[P_AXIS]=current_position[P_AXIS];  //FMM added P_AXIS
        lastpos[X_AXIS]=current_position[X_AXIS];
        lastpos[Y_AXIS]=current_position[Y_AXIS];
        lastpos[Z_AXIS]=current_position[Z_AXIS];
        lastpos[E_AXIS]=current_position[E_AXIS];
        lastpos[P_AXIS]=current_position[P_AXIS];  //FMM added P_AXIS
        //retract by E
        if(code_seen('E'))
        {
          target[E_AXIS]+= code_value();  //FMM consider adding P_AXIS?
        }
        else
        {
          #ifdef FILAMENTCHANGE_FIRSTRETRACT
            target[E_AXIS]+= FILAMENTCHANGE_FIRSTRETRACT ;   //FMM consider adding P_AXIS?
          #endif
        }
        plan_buffer_line(target[X_AXIS], target[Y_AXIS], target[Z_AXIS], target[E_AXIS],target[P_AXIS], feedrate/60, active_extruder);  //FMM added P_AXIS

        //lift Z
        if(code_seen('Z'))
        {
          target[Z_AXIS]+= code_value();
        }
        else
        {
          #ifdef FILAMENTCHANGE_ZADD
            target[Z_AXIS]+= FILAMENTCHANGE_ZADD ;
          #endif
        }
        plan_buffer_line(target[X_AXIS], target[Y_AXIS], target[Z_AXIS], target[E_AXIS], target[P_AXIS],feedrate/60, active_extruder);  //FMM added P_AXIS

        //move xy
        if(code_seen('X'))
        {
          target[X_AXIS]+= code_value();
        }
        else
        {
          #ifdef FILAMENTCHANGE_XPOS
            target[X_AXIS]= FILAMENTCHANGE_XPOS ;
          #endif
        }
        if(code_seen('Y'))
        {
          target[Y_AXIS]= code_value();
        }
        else
        {
          #ifdef FILAMENTCHANGE_YPOS
            target[Y_AXIS]= FILAMENTCHANGE_YPOS ;
          #endif
        }

        plan_buffer_line(target[X_AXIS], target[Y_AXIS], target[Z_AXIS], target[E_AXIS], target[P_AXIS], feedrate/60, active_extruder);  //FMM added P_AXIS

        if(code_seen('L'))
        {
          target[E_AXIS]+= code_value();  //FMM consider adding P_AXIS
        }
        else
        {
          #ifdef FILAMENTCHANGE_FINALRETRACT
            target[E_AXIS]+= FILAMENTCHANGE_FINALRETRACT ;  //FMM consider adding P_AXIS
          #endif
        }

        plan_buffer_line(target[X_AXIS], target[Y_AXIS], target[Z_AXIS], target[E_AXIS], target[P_AXIS],feedrate/60, active_extruder);  //FMM added P_AXIS

        //finish moves
        st_synchronize();
        //disable extruder steppers so filament can be removed
        disable_e0();
        disable_p();
        disable_e2();
        delay(100);
        LCD_ALERTMESSAGEPGM(MSG_FILAMENTCHANGE);
        uint8_t cnt=0;
        while(!lcd_clicked()){
          cnt++;
          manage_heater();
          manage_inactivity();
          lcd_update(encoderClicked, encoderLongPressed);
          if(cnt==0)
          {
          #if BEEPER > 0
            SET_OUTPUT(BEEPER);

            WRITE(BEEPER,HIGH);
            delay(3);
            WRITE(BEEPER,LOW);
            delay(3);
          #else
			#if !defined(LCD_FEEDBACK_FREQUENCY_HZ) || !defined(LCD_FEEDBACK_FREQUENCY_DURATION_MS)
              lcd_buzz(1000/6,100);
			#else
			  lcd_buzz(LCD_FEEDBACK_FREQUENCY_DURATION_MS,LCD_FEEDBACK_FREQUENCY_HZ);
			#endif
          #endif
          }
        }

        //return to normal
        if(code_seen('L'))
        {
          target[E_AXIS]+= -code_value();  //FMM consider adding P_AXIS
        }
        else
        {
          #ifdef FILAMENTCHANGE_FINALRETRACT
            target[E_AXIS]+=(-1)*FILAMENTCHANGE_FINALRETRACT ;  //FMM consider adding P_AXIS
          #endif
        }
        current_position[E_AXIS]=target[E_AXIS]; //the long retract of L is compensated by manual filament feeding
        current_position[P_AXIS]=target[P_AXIS];   //FMM added P_AXIS
        plan_set_e_position(current_position[E_AXIS]);
        plan_set_p_position(current_position[P_AXIS]);  //FMM added P_AXIS
        plan_buffer_line(target[X_AXIS], target[Y_AXIS], target[Z_AXIS], target[E_AXIS], target[P_AXIS],feedrate/60, active_extruder); //should do nothing
        plan_buffer_line(lastpos[X_AXIS], lastpos[Y_AXIS], target[Z_AXIS], target[E_AXIS], target[P_AXIS],feedrate/60, active_extruder); //move xy back
        plan_buffer_line(lastpos[X_AXIS], lastpos[Y_AXIS], lastpos[Z_AXIS], target[E_AXIS], target[P_AXIS],feedrate/60, active_extruder); //move z back
        plan_buffer_line(lastpos[X_AXIS], lastpos[Y_AXIS], lastpos[Z_AXIS], lastpos[E_AXIS], lastpos[P_AXIS],feedrate/60, active_extruder); //final untretract
    }
    break;
    #endif //FILAMENTCHANGEENABLE
    #ifdef DUAL_X_CARRIAGE
    case 605: // Set dual x-carriage movement mode:
              //    M605 S0: Full control mode. The slicer has full control over x-carriage movement
              //    M605 S1: Auto-park mode. The inactive head will auto park/unpark without slicer involvement
              //    M605 S2 [Xnnn] [Rmmm]: Duplication mode. The second extruder will duplicate the first with nnn
              //                         millimeters x-offset and an optional differential hotend temperature of
              //                         mmm degrees. E.g., with "M605 S2 X100 R2" the second extruder will duplicate
              //                         the first with a spacing of 100mm in the x direction and 2 degrees hotter.
              //
              //    Note: the X axis should be homed after changing dual x-carriage mode.
    {
        st_synchronize();

        if (code_seen('S'))
          dual_x_carriage_mode = code_value();

        if (dual_x_carriage_mode == DXC_DUPLICATION_MODE)
        {
          if (code_seen('X'))
            duplicate_extruder_x_offset = max(code_value(),X2_MIN_POS - x_home_pos(0));

          if (code_seen('R'))
            duplicate_extruder_temp_offset = code_value();

          SERIAL_ECHO_START;
          SERIAL_ECHOPGM(MSG_HOTEND_OFFSET);
          SERIAL_ECHO(" ");
          SERIAL_ECHO(extruder_offset[X_AXIS][0]);
          SERIAL_ECHO(",");
          SERIAL_ECHO(extruder_offset[Y_AXIS][0]);
          SERIAL_ECHO(" ");
          SERIAL_ECHO(duplicate_extruder_x_offset);
          SERIAL_ECHO(",");
          SERIAL_ECHOLN(extruder_offset[Y_AXIS][1]);
        }
        else if (dual_x_carriage_mode != DXC_FULL_CONTROL_MODE && dual_x_carriage_mode != DXC_AUTO_PARK_MODE)
        {
          dual_x_carriage_mode = DEFAULT_DUAL_X_CARRIAGE_MODE;
        }

        active_extruder_parked = false;
        extruder_duplication_enabled = false;
        delayed_move_time = 0;
    }
    break;
    #endif //DUAL_X_CARRIAGE
    case 907: // M907 Set digital trimpot motor current using axis codes.
    {
      #if defined(DIGIPOTSS_PIN) && DIGIPOTSS_PIN > -1
        for(int i=0;i<NUM_AXIS;i++) if(code_seen(axis_codes[i])) digipot_current(i,code_value());
        if(code_seen('B')) digipot_current(4,code_value());
        if(code_seen('S')) for(int i=0;i<=4;i++) digipot_current(i,code_value());
      #endif
      #ifdef MOTOR_CURRENT_PWM_XY_PIN
        if(code_seen('X')) digipot_current(0, code_value());
      #endif
      #ifdef MOTOR_CURRENT_PWM_Z_PIN
        if(code_seen('Z')) digipot_current(1, code_value());
      #endif
      #ifdef MOTOR_CURRENT_PWM_E_PIN
        if(code_seen('E')) digipot_current(2, code_value());
      #endif
      #ifdef DIGIPOT_I2C
        // this one uses actual amps in floating point
        for(int i=0;i<NUM_AXIS;i++) if(code_seen(axis_codes[i])) digipot_i2c_set_current(i, code_value());
        // for each additional extruder (named B,C,D,E..., channels 4,5,6,7...)
        for(int i=NUM_AXIS;i<DIGIPOT_I2C_NUM_CHANNELS;i++) if(code_seen('B'+i-NUM_AXIS)) digipot_i2c_set_current(i, code_value());
      #endif
    }
    break;
    case 908: // M908 Control digital trimpot directly.
    {
      #if defined(DIGIPOTSS_PIN) && DIGIPOTSS_PIN > -1
        uint8_t channel,current;
        if(code_seen('P')) channel=code_value();
        if(code_seen('S')) current=code_value();
        digitalPotWrite(channel, current);
      #endif
    }
    break;
    case 350: // M350 Set microstepping mode. Warning: Steps per unit remains unchanged. S code sets stepping mode for all drivers.
    {
      #if defined(X_MS1_PIN) && X_MS1_PIN > -1
        if(code_seen('S')) for(int i=0;i<=4;i++) microstep_mode(i,code_value());
        for(int i=0;i<NUM_AXIS;i++) if(code_seen(axis_codes[i])) microstep_mode(i,(uint8_t)code_value());
        if(code_seen('B')) microstep_mode(4,code_value());
        microstep_readings();
      #endif
    }
    break;
    case 351: // M351 Toggle MS1 MS2 pins directly, S# determines MS1 or MS2, X# sets the pin high/low.
    {
      #if defined(X_MS1_PIN) && X_MS1_PIN > -1
      if(code_seen('S')) switch((int)code_value())
      {
        case 1:
          for(int i=0;i<NUM_AXIS;i++) if(code_seen(axis_codes[i])) microstep_ms(i,code_value(),-1);
          if(code_seen('B')) microstep_ms(4,code_value(),-1);
          break;
        case 2:
          for(int i=0;i<NUM_AXIS;i++) if(code_seen(axis_codes[i])) microstep_ms(i,-1,code_value());
          if(code_seen('B')) microstep_ms(4,-1,code_value());
          break;
      }
      microstep_readings();
      #endif
    }
    break;
	case 700: // M700 - Extruder data dump 
	{
		// Duration and time remaining
		SERIAL_PROTOCOLPGM("ok D:");
		SERIAL_PROTOCOL(duration);
		SERIAL_PROTOCOLPGM(" /");
		SERIAL_PROTOCOL(timeremaining);
		// lenght    
		SERIAL_PROTOCOLPGM(" L:");
		SERIAL_PROTOCOL_F(extrude_length, 1);
		// filament width
		SERIAL_PROTOCOLPGM(" Fil:");
		SERIAL_PROTOCOL_F(current_filwidth, 2);
		// average filament width
		SERIAL_PROTOCOLPGM(" Avg:");
		SERIAL_PROTOCOL_F(avg_measured_filament_width, 2);
		// min filament width
		SERIAL_PROTOCOLPGM(" Mn:");
		SERIAL_PROTOCOL_F(min_measured_filament_width, 2);
		// max filament width
		SERIAL_PROTOCOLPGM(" Mx:");
		SERIAL_PROTOCOL_F(max_measured_filament_width, 2);
		// extruder rpm
		SERIAL_PROTOCOLPGM(" E:");
		SERIAL_PROTOCOL_F(extruder_rpm, 2);
		// puller feedrate in mm/s
		SERIAL_PROTOCOLPGM(" P:");
		SERIAL_PROTOCOL_F(puller_feedrate, 2);
		// Winder speed
		SERIAL_PROTOCOLPGM(" W:");
		SERIAL_PROTOCOL(winderSpeed);
		//
#if defined(TEMP_0_PIN) && TEMP_0_PIN > -1
//		SERIAL_PROTOCOLPGM(" T:");
//		SERIAL_PROTOCOL_F(degHotend(tmp_extruder), 1);
//		SERIAL_PROTOCOLPGM(" /");
//		SERIAL_PROTOCOL_F(degTargetHotend(tmp_extruder), 1);
		for (int8_t cur_extruder = 0; cur_extruder < EXTRUDERS; ++cur_extruder) {
			SERIAL_PROTOCOLPGM(" T");
			SERIAL_PROTOCOL(cur_extruder);
			SERIAL_PROTOCOLPGM(":");
			SERIAL_PROTOCOL_F(degHotend(cur_extruder), 1);
			SERIAL_PROTOCOLPGM(" /");
			SERIAL_PROTOCOL_F(degTargetHotend(cur_extruder), 1);
		}
#else
		SERIAL_ERROR_START;
		SERIAL_ERRORLNPGM(MSG_ERR_NO_THERMISTORS);
#endif
              SERIAL_PROTOCOLLN("");
              return;
	}
	break;
	case 999: // M999: Restart after being stopped
      Stopped = false;
      lcd_reset_alert_level();
      gcode_LastN = Stopped_gcode_LastN;
      FlushSerialRequestResend();
    break;
    }
  }

  else if(code_seen('T'))
  {
    tmp_extruder = code_value();
    if(tmp_extruder >= EXTRUDERS) {
      SERIAL_ECHO_START;
      SERIAL_ECHO("T");
      SERIAL_ECHO(tmp_extruder);
      SERIAL_ECHOLN(MSG_INVALID_EXTRUDER);
    }
    else {
      boolean make_move = false;
      if(code_seen('F')) {
        make_move = true;
        next_feedrate = code_value();
        if(next_feedrate > 0.0) {
          feedrate = next_feedrate;
        }
      }
      #if EXTRUDERS > 1
      if(tmp_extruder != active_extruder) {
        // Save current position to return to after applying extruder offset
        memcpy(destination, current_position, sizeof(destination));
      #ifdef DUAL_X_CARRIAGE
        if (dual_x_carriage_mode == DXC_AUTO_PARK_MODE && Stopped == false &&
            (delayed_move_time != 0 || current_position[X_AXIS] != x_home_pos(active_extruder)))
        {
          // Park old head: 1) raise 2) move to park position 3) lower
          plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS] + TOOLCHANGE_PARK_ZLIFT,
                current_position[E_AXIS], current_position[P_AXIS], max_feedrate[Z_AXIS], active_extruder);
          plan_buffer_line(x_home_pos(active_extruder), current_position[Y_AXIS], current_position[Z_AXIS] + TOOLCHANGE_PARK_ZLIFT,
                current_position[E_AXIS], current_position[P_AXIS], max_feedrate[X_AXIS], active_extruder);
          plan_buffer_line(x_home_pos(active_extruder), current_position[Y_AXIS], current_position[Z_AXIS],
                current_position[E_AXIS], current_position[P_AXIS], max_feedrate[Z_AXIS], active_extruder);
          st_synchronize();
        }

        // apply Y & Z extruder offset (x offset is already used in determining home pos)
        current_position[Y_AXIS] = current_position[Y_AXIS] -
                     extruder_offset[Y_AXIS][active_extruder] +
                     extruder_offset[Y_AXIS][tmp_extruder];
        current_position[Z_AXIS] = current_position[Z_AXIS] -
                     extruder_offset[Z_AXIS][active_extruder] +
                     extruder_offset[Z_AXIS][tmp_extruder];

        active_extruder = tmp_extruder;

        // This function resets the max/min values - the current position may be overwritten below.
        axis_is_at_home(X_AXIS);

        if (dual_x_carriage_mode == DXC_FULL_CONTROL_MODE)
        {
          current_position[X_AXIS] = inactive_extruder_x_pos;
          inactive_extruder_x_pos = destination[X_AXIS];
        }
        else if (dual_x_carriage_mode == DXC_DUPLICATION_MODE)
        {
          active_extruder_parked = (active_extruder == 0); // this triggers the second extruder to move into the duplication position
          if (active_extruder == 0 || active_extruder_parked)
            current_position[X_AXIS] = inactive_extruder_x_pos;
          else
            current_position[X_AXIS] = destination[X_AXIS] + duplicate_extruder_x_offset;
          inactive_extruder_x_pos = destination[X_AXIS];
          extruder_duplication_enabled = false;
        }
        else
        {
          // record raised toolhead position for use by unpark
          memcpy(raised_parked_position, current_position, sizeof(raised_parked_position));
          raised_parked_position[Z_AXIS] += TOOLCHANGE_UNPARK_ZLIFT;
          active_extruder_parked = true;
          delayed_move_time = 0;
        }
      #else
        // Offset extruder (only by XY)
        int i;
        for(i = 0; i < 2; i++) {
           current_position[i] = current_position[i] -
                                 extruder_offset[i][active_extruder] +
                                 extruder_offset[i][tmp_extruder];
        }
        // Set the new active extruder and position
        active_extruder = tmp_extruder;
      #endif //else DUAL_X_CARRIAGE
        plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS], current_position[P_AXIS]);  //FMM added P_AXIS
        // Move to the old position if 'F' was in the parameters
        if(make_move && Stopped == false) {
           prepare_move();
        }
      }
      #endif
      SERIAL_ECHO_START;
      SERIAL_ECHO(MSG_ACTIVE_EXTRUDER);
      SERIAL_PROTOCOLLN((int)active_extruder);
    }
  }

  else
  {
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM(MSG_UNKNOWN_COMMAND);
    SERIAL_ECHO(cmdbuffer[bufindr]);
    SERIAL_ECHOLNPGM("\"");
  }

  ClearToSend();
}

void FlushSerialRequestResend()
{
  //char cmdbuffer[bufindr][100]="Resend:";
  MYSERIAL.flush();
  SERIAL_PROTOCOLPGM(MSG_RESEND);
  SERIAL_PROTOCOLLN(gcode_LastN + 1);
  ClearToSend();
}

void ClearToSend()
{
  previous_millis_cmd = millis();
  #ifdef SDSUPPORT
  if(fromsd[bufindr])
    return;
  #endif //SDSUPPORT
  SERIAL_PROTOCOLLNPGM(MSG_OK);
}

void get_coordinates()
{
  bool seen[5]={false,false,false,false,false};  //FMM added P_AXIS
  for(int8_t i=0; i < NUM_AXIS; i++) {
    if(code_seen(axis_codes[i]))
    {
      destination[i] = (float)code_value() + (axis_relative_modes[i] || relative_mode)*current_position[i];
      seen[i]=true;
    }
    else destination[i] = current_position[i]; //Are these else lines really needed?
  }
  if(code_seen('F')) {
    next_feedrate = code_value();
    if(next_feedrate > 0.0) feedrate = next_feedrate;
  }
}

void get_arc_coordinates()
{
#ifdef SF_ARC_FIX
   bool relative_mode_backup = relative_mode;
   relative_mode = true;
#endif
   get_coordinates();
#ifdef SF_ARC_FIX
   relative_mode=relative_mode_backup;
#endif

   if(code_seen('I')) {
     offset[0] = code_value();
   }
   else {
     offset[0] = 0.0;
   }
   if(code_seen('J')) {
     offset[1] = code_value();
   }
   else {
     offset[1] = 0.0;
   }
}

void clamp_to_software_endstops(float target[3])
{
  if (min_software_endstops) {
    if (target[X_AXIS] < min_pos[X_AXIS]) target[X_AXIS] = min_pos[X_AXIS];
    if (target[Y_AXIS] < min_pos[Y_AXIS]) target[Y_AXIS] = min_pos[Y_AXIS];
    if (target[Z_AXIS] < min_pos[Z_AXIS]) target[Z_AXIS] = min_pos[Z_AXIS];
  }

  if (max_software_endstops) {
    if (target[X_AXIS] > max_pos[X_AXIS]) target[X_AXIS] = max_pos[X_AXIS];
    if (target[Y_AXIS] > max_pos[Y_AXIS]) target[Y_AXIS] = max_pos[Y_AXIS];
    if (target[Z_AXIS] > max_pos[Z_AXIS]) target[Z_AXIS] = max_pos[Z_AXIS];
  }
}

#ifdef DELTA
void recalc_delta_settings(float radius, float diagonal_rod)
{
	 delta_tower1_x= -SIN_60*radius; // front left tower
	 delta_tower1_y= -COS_60*radius;	   
	 delta_tower2_x=  SIN_60*radius; // front right tower
	 delta_tower2_y= -COS_60*radius;	   
	 delta_tower3_x= 0.0;                  // back middle tower
	 delta_tower3_y= radius;
	 delta_diagonal_rod_2= sq(diagonal_rod);
}

void calculate_delta(float cartesian[3])
{
  delta[X_AXIS] = sqrt(delta_diagonal_rod_2
                       - sq(delta_tower1_x-cartesian[X_AXIS])
                       - sq(delta_tower1_y-cartesian[Y_AXIS])
                       ) + cartesian[Z_AXIS];
  delta[Y_AXIS] = sqrt(delta_diagonal_rod_2
                       - sq(delta_tower2_x-cartesian[X_AXIS])
                       - sq(delta_tower2_y-cartesian[Y_AXIS])
                       ) + cartesian[Z_AXIS];
  delta[Z_AXIS] = sqrt(delta_diagonal_rod_2
                       - sq(delta_tower3_x-cartesian[X_AXIS])
                       - sq(delta_tower3_y-cartesian[Y_AXIS])
                       ) + cartesian[Z_AXIS];
  /*
  SERIAL_ECHOPGM("cartesian x="); SERIAL_ECHO(cartesian[X_AXIS]);
  SERIAL_ECHOPGM(" y="); SERIAL_ECHO(cartesian[Y_AXIS]);
  SERIAL_ECHOPGM(" z="); SERIAL_ECHOLN(cartesian[Z_AXIS]);

  SERIAL_ECHOPGM("delta x="); SERIAL_ECHO(delta[X_AXIS]);
  SERIAL_ECHOPGM(" y="); SERIAL_ECHO(delta[Y_AXIS]);
  SERIAL_ECHOPGM(" z="); SERIAL_ECHOLN(delta[Z_AXIS]);
  */
}
#endif

void prepare_move()
{
  clamp_to_software_endstops(destination);

  previous_millis_cmd = millis();
#ifdef DELTA
  float difference[NUM_AXIS];
  for (int8_t i=0; i < NUM_AXIS; i++) {
    difference[i] = destination[i] - current_position[i];
  }
  float cartesian_mm = sqrt(sq(difference[X_AXIS]) +
                            sq(difference[Y_AXIS]) +
                            sq(difference[Z_AXIS]));
  if (cartesian_mm < 0.000001) { cartesian_mm = abs(difference[E_AXIS]); }
  if (cartesian_mm < 0.000001) { return; }
  float seconds = 6000 * cartesian_mm / feedrate / feedmultiply;
  int steps = max(1, int(delta_segments_per_second * seconds));
  // SERIAL_ECHOPGM("mm="); SERIAL_ECHO(cartesian_mm);
  // SERIAL_ECHOPGM(" seconds="); SERIAL_ECHO(seconds);
  // SERIAL_ECHOPGM(" steps="); SERIAL_ECHOLN(steps);
  for (int s = 1; s <= steps; s++) {
    float fraction = float(s) / float(steps);
    for(int8_t i=0; i < NUM_AXIS; i++) {
      destination[i] = current_position[i] + difference[i] * fraction;
    }
    calculate_delta(destination);
    plan_buffer_line(delta[X_AXIS], delta[Y_AXIS], delta[Z_AXIS],
                     destination[E_AXIS], destination[P_AXIS], feedrate*feedmultiply/60/100.0,
                     active_extruder);
  }
#else

#ifdef DUAL_X_CARRIAGE
  if (active_extruder_parked)
  {
    if (dual_x_carriage_mode == DXC_DUPLICATION_MODE && active_extruder == 0)
    {
      // move duplicate extruder into correct duplication position.
      plan_set_position(inactive_extruder_x_pos, current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
      plan_buffer_line(current_position[X_AXIS] + duplicate_extruder_x_offset, current_position[Y_AXIS], current_position[Z_AXIS],
          current_position[E_AXIS], current_position[P_AXIS], max_feedrate[X_AXIS], 1);
      plan_set_position(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS], current_position[E_AXIS]);
      st_synchronize();
      extruder_duplication_enabled = true;
      active_extruder_parked = false;
    }
    else if (dual_x_carriage_mode == DXC_AUTO_PARK_MODE) // handle unparking of head
    {
      if (current_position[E_AXIS] == destination[E_AXIS])
      {
        // this is a travel move - skit it but keep track of current position (so that it can later
        // be used as start of first non-travel move)
        if (delayed_move_time != 0xFFFFFFFFUL)
        {
          memcpy(current_position, destination, sizeof(current_position));
          if (destination[Z_AXIS] > raised_parked_position[Z_AXIS])
            raised_parked_position[Z_AXIS] = destination[Z_AXIS];
          delayed_move_time = millis();
          return;
        }
      }
      delayed_move_time = 0;
      // unpark extruder: 1) raise, 2) move into starting XY position, 3) lower
      plan_buffer_line(raised_parked_position[X_AXIS], raised_parked_position[Y_AXIS], raised_parked_position[Z_AXIS],    current_position[E_AXIS], current_position[P_AXIS],max_feedrate[Z_AXIS], active_extruder);
      plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], raised_parked_position[Z_AXIS],
          current_position[E_AXIS], current_position[P_AXIS],min(max_feedrate[X_AXIS],max_feedrate[Y_AXIS]), active_extruder);
      plan_buffer_line(current_position[X_AXIS], current_position[Y_AXIS], current_position[Z_AXIS],
          current_position[E_AXIS], current_position[P_AXIS],max_feedrate[Z_AXIS], active_extruder);
      active_extruder_parked = false;
    }
  }
#endif //DUAL_X_CARRIAGE

  // Do not use feedmultiply for E or Z only moves
  if( (current_position[X_AXIS] == destination [X_AXIS]) && (current_position[Y_AXIS] == destination [Y_AXIS])) {
      plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate/60, active_extruder);  //FMM added P_AXIS
  }
  else {
    plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS], destination[E_AXIS], destination[P_AXIS], feedrate*feedmultiply/60/100.0, active_extruder);  //FMM added P_AXIS
  }
#endif //else DELTA
  for(int8_t i=0; i < NUM_AXIS; i++) {
    current_position[i] = destination[i];
  }
}

void prepare_arc_move(char isclockwise) {
  float r = hypot(offset[X_AXIS], offset[Y_AXIS]); // Compute arc radius for mc_arc

  // Trace the arc
  mc_arc(current_position, destination, offset, X_AXIS, Y_AXIS, Z_AXIS, feedrate*feedmultiply/60/100.0, r, isclockwise, active_extruder);

  // As far as the parser is concerned, the position is now == target. In reality the
  // motion control system might still be processing the action and the real tool position
  // in any intermediate location.
  for(int8_t i=0; i < NUM_AXIS; i++) {
    current_position[i] = destination[i];
  }
  previous_millis_cmd = millis();
}

#if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1

#if defined(WINDER_PIN)
  #if CONTROLLERFAN_PIN == FAN_PIN
    #error "You cannot set CONTROLLERFAN_PIN equal to FAN_PIN"
  #endif
#endif

unsigned long lastMotor = 0; //Save the time for when a motor was turned on last
unsigned long lastMotorCheck = 0;

void controllerFan()
{
  if ((millis() - lastMotorCheck) >= 2500) //Not a time critical function, so we only check every 2500ms
  {
    lastMotorCheck = millis();

    if(!READ(X_ENABLE_PIN) || !READ(Y_ENABLE_PIN) || !READ(Z_ENABLE_PIN) || (soft_pwm_bed > 0)
    #if EXTRUDERS > 2
       || !READ(E2_ENABLE_PIN)
    #endif
    #if EXTRUDER > 1
      #if defined(X2_ENABLE_PIN) && X2_ENABLE_PIN > -1
       || !READ(X2_ENABLE_PIN)
      #endif
       || !READ(E1_ENABLE_PIN)
    #endif
       || !READ(E0_ENABLE_PIN)) //If any of the drivers are enabled...
    {
      lastMotor = millis(); //... set time to NOW so the fan will turn on
    }

    if ((millis() - lastMotor) >= (CONTROLLERFAN_SECS*1000UL) || lastMotor == 0) //If the last time any driver was enabled, is longer since than CONTROLLERSEC...
    {
        digitalWrite(CONTROLLERFAN_PIN, 0);
        analogWrite(CONTROLLERFAN_PIN, 0);
    }
    else
    {
        // allows digital or PWM fan output to be used (see M42 handling)
        digitalWrite(CONTROLLERFAN_PIN, CONTROLLERFAN_SPEED);
        analogWrite(CONTROLLERFAN_PIN, CONTROLLERFAN_SPEED);
    }
  }
}
#endif

#ifdef TEMP_STAT_LEDS
static bool blue_led = false;
static bool red_led = false;
static uint32_t stat_update = 0;

void handle_status_leds(void) {
  float max_temp = 0.0;
  if(millis() > stat_update) {
    stat_update += 500; // Update every 0.5s
    for (int8_t cur_extruder = 0; cur_extruder < EXTRUDERS; ++cur_extruder) {
       max_temp = max(max_temp, degHotend(cur_extruder));
       max_temp = max(max_temp, degTargetHotend(cur_extruder));
    }
    #if defined(TEMP_BED_PIN) && TEMP_BED_PIN > -1
      max_temp = max(max_temp, degTargetBed());
      max_temp = max(max_temp, degBed());
    #endif
    if((max_temp > 55.0) && (red_led == false)) {
      digitalWrite(STAT_LED_RED, 1);
      digitalWrite(STAT_LED_BLUE, 0);
      red_led = true;
      blue_led = false;
    }
    if((max_temp < 54.0) && (blue_led == false)) {
      digitalWrite(STAT_LED_RED, 0);
      digitalWrite(STAT_LED_BLUE, 1);
      red_led = false;
      blue_led = true;
    }
  }
}
#endif

void manage_inactivity()
{
  if( (millis() - previous_millis_cmd) >  max_inactive_time )
    if(max_inactive_time)
      kill();
  if(stepper_inactive_time)  {
    if( (millis() - previous_millis_cmd) >  stepper_inactive_time )
    {
      if(blocks_queued() == false) {
        disable_x();
        disable_y();
        disable_z();
        disable_e0();
        disable_p();
        disable_e2();
      }
    }
  }
  
  #ifdef CHDK //Check if pin should be set to LOW after M240 set it to HIGH
    if (chdkActive)
    {
      chdkActive = false;
      if (millis()-chdkHigh < CHDK_DELAY) return;
      WRITE(CHDK, LOW);
    }
  #endif
  
  #if defined(KILL_PIN) && KILL_PIN > -1
    if( 0 == READ(KILL_PIN) )
      kill();
  #endif
  #if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1
    //controllerFan(); //Check if fan should be turned on to cool stepper drivers down
  #endif
  #ifdef EXTRUDER_RUNOUT_PREVENT
    if( (millis() - previous_millis_cmd) >  EXTRUDER_RUNOUT_SECONDS*1000 )
    if(degHotend(active_extruder)>EXTRUDER_RUNOUT_MINTEMP)
    {
     bool oldstatus=READ(E0_ENABLE_PIN);
     enable_e0();
     float oldepos=current_position[E_AXIS];
     float oldedes=destination[E_AXIS];
     plan_buffer_line(destination[X_AXIS], destination[Y_AXIS], destination[Z_AXIS],
                      destination[E_AXIS]+EXTRUDER_RUNOUT_EXTRUDE*EXTRUDER_RUNOUT_ESTEPS/axis_steps_per_unit[E_AXIS], destination[P_AXIS],
                      EXTRUDER_RUNOUT_SPEED/60.*EXTRUDER_RUNOUT_ESTEPS/axis_steps_per_unit[E_AXIS], active_extruder);
     current_position[E_AXIS]=oldepos;
     destination[E_AXIS]=oldedes;
     plan_set_e_position(oldepos);
     previous_millis_cmd=millis();
     st_synchronize();
     WRITE(E0_ENABLE_PIN,oldstatus);
    }
  #endif
  #if defined(DUAL_X_CARRIAGE)
    // handle delayed move timeout
    if (delayed_move_time != 0 && (millis() - delayed_move_time) > 1000 && Stopped == false)
    {
      // travel moves have been received so enact them
      delayed_move_time = 0xFFFFFFFFUL; // force moves to be done
      memcpy(destination,current_position,sizeof(destination));
      prepare_move();
    }
  #endif
  #ifdef TEMP_STAT_LEDS
      handle_status_leds();
  #endif
  check_axes_activity();
}

void kill()
{
  cli(); // Stop interrupts
  disable_heater();

  disable_x();
  disable_y();
  disable_z();
  disable_e0();
  disable_p();
  disable_e2();

#if defined(PS_ON_PIN) && PS_ON_PIN > -1
  pinMode(PS_ON_PIN,INPUT);
#endif
  SERIAL_ERROR_START;
  SERIAL_ERRORLNPGM(MSG_ERR_KILLED);
  LCD_ALERTMESSAGEPGM(MSG_KILLED);
  suicide();
  while(1) { /* Intentionally left empty */ } // Wait for reset
}

void Stop()
{
	
	

  disable_heater();
  if(Stopped == false) {
    Stopped = true;
    Stopped_gcode_LastN = gcode_LastN; // Save last g_code for restart
    SERIAL_ERROR_START;
    SERIAL_ERRORLNPGM(MSG_ERR_STOPPED);
    LCD_MESSAGEPGM(MSG_STOPPED);
  }
  
}

bool IsStopped() { return Stopped; };

#ifdef FAST_PWM_FAN
void setPwmFrequency(uint8_t pin, int val)
{
  val &= 0x07;
  switch(digitalPinToTimer(pin))
  {

    #if defined(TCCR0A)
    case TIMER0A:
    case TIMER0B:
//         TCCR0B &= ~(_BV(CS00) | _BV(CS01) | _BV(CS02));
//         TCCR0B |= val;
         break;
    #endif

    #if defined(TCCR1A)
    case TIMER1A:
    case TIMER1B:
//         TCCR1B &= ~(_BV(CS10) | _BV(CS11) | _BV(CS12));
//         TCCR1B |= val;
         break;
    #endif

    #if defined(TCCR2)
    case TIMER2:
    case TIMER2:
         TCCR2 &= ~(_BV(CS10) | _BV(CS11) | _BV(CS12));
         TCCR2 |= val;
         break;
    #endif

    #if defined(TCCR2A)
    case TIMER2A:
    case TIMER2B:
         TCCR2B &= ~(_BV(CS20) | _BV(CS21) | _BV(CS22));
         TCCR2B |= val;
         break;
    #endif

    #if defined(TCCR3A)
    case TIMER3A:
    case TIMER3B:
    case TIMER3C:
         TCCR3B &= ~(_BV(CS30) | _BV(CS31) | _BV(CS32));
         TCCR3B |= val;
         break;
    #endif

    #if defined(TCCR4A)
    case TIMER4A:
    case TIMER4B:
    case TIMER4C:
         TCCR4B &= ~(_BV(CS40) | _BV(CS41) | _BV(CS42));
         TCCR4B |= val;
         break;
   #endif

    #if defined(TCCR5A)
    case TIMER5A:
    case TIMER5B:
    case TIMER5C:
         TCCR5B &= ~(_BV(CS50) | _BV(CS51) | _BV(CS52));
         TCCR5B |= val;
         break;
   #endif

  }
}
#endif //FAST_PWM_FAN

bool setTargetedHotend(int code){
  tmp_extruder = active_extruder;
  if(code_seen('T')) {
    tmp_extruder = code_value();
    if(tmp_extruder >= EXTRUDERS) {
      SERIAL_ECHO_START;
      switch(code){
        case 104:
          SERIAL_ECHO(MSG_M104_INVALID_EXTRUDER);
          break;
        case 105:
          SERIAL_ECHO(MSG_M105_INVALID_EXTRUDER);
          break;
        case 109:
          SERIAL_ECHO(MSG_M109_INVALID_EXTRUDER);
          break;
        case 218:
          SERIAL_ECHO(MSG_M218_INVALID_EXTRUDER);
          break;
        case 221:
          SERIAL_ECHO(MSG_M221_INVALID_EXTRUDER);
          break;
      }
      SERIAL_ECHOLN(tmp_extruder);
      return true;
    }
  }
  return false;
}
