#include "fr3d_lcd_remote.h"

#ifdef ULTRA_LCD

#include "ultralcd.h"

static char fr3d_lcd_mirror[FR3D_LCD_MIRROR_ROWS][FR3D_LCD_MIRROR_COLS];
static uint8_t fr3d_lcd_mir_col = 0;
static uint8_t fr3d_lcd_mir_row = 0;
static volatile uint8_t fr3d_remote_click_pending = 0;

/* Default: encoder fisico activo. Banco sin Smart Controller: LCDHWENC0 */
uint8_t fr3d_lcd_hw_encoder = 1;

extern uint8_t lcdDrawUpdate;
extern uint32_t encoderPosition;

void fr3d_lcd_mirror_clear(void)
{
  for (uint8_t r = 0; r < FR3D_LCD_MIRROR_ROWS; r++) {
    for (uint8_t c = 0; c < FR3D_LCD_MIRROR_COLS; c++) {
      fr3d_lcd_mirror[r][c] = ' ';
    }
  }
  fr3d_lcd_mir_col = 0;
  fr3d_lcd_mir_row = 0;
}

void fr3d_lcd_mirror_set_cursor(uint8_t col, uint8_t row)
{
  if (row >= FR3D_LCD_MIRROR_ROWS) row = FR3D_LCD_MIRROR_ROWS - 1;
  if (col >= FR3D_LCD_MIRROR_COLS) col = FR3D_LCD_MIRROR_COLS - 1;
  fr3d_lcd_mir_col = col;
  fr3d_lcd_mir_row = row;
}

static char fr3d_lcd_sanitize(uint8_t c)
{
  if (c < 0x20 || c > 0x7E) return '?';
  if (c == ',') return '?';
  return (char)c;
}

void fr3d_lcd_mirror_write(uint8_t c)
{
  if (fr3d_lcd_mir_row >= FR3D_LCD_MIRROR_ROWS) return;
  if (fr3d_lcd_mir_col >= FR3D_LCD_MIRROR_COLS) {
    /* HD44780 wrap tipico: no avanzamos de linea automaticamente aqui */
    return;
  }
  fr3d_lcd_mirror[fr3d_lcd_mir_row][fr3d_lcd_mir_col] = fr3d_lcd_sanitize(c);
  fr3d_lcd_mir_col++;
}

void fr3d_lcd_mirror_get_line(uint8_t row, char *out, uint8_t cols)
{
  if (!out || cols == 0) return;
  if (row >= FR3D_LCD_MIRROR_ROWS) {
    for (uint8_t i = 0; i < cols; i++) out[i] = ' ';
    out[cols] = '\0';
    return;
  }
  uint8_t n = cols;
  if (n > FR3D_LCD_MIRROR_COLS) n = FR3D_LCD_MIRROR_COLS;
  for (uint8_t i = 0; i < n; i++) out[i] = fr3d_lcd_mirror[row][i];
  for (uint8_t i = n; i < cols; i++) out[i] = ' ';
  out[cols] = '\0';
}

void fr3d_lcd_remote_enc_step(int8_t dir)
{
#ifdef ULTIPANEL
  if (dir > 0) {
    encoderPosition += (uint32_t)ENCODER_STEPS_PER_MENU_ITEM;
  } else if (dir < 0) {
    if (encoderPosition >= (uint32_t)ENCODER_STEPS_PER_MENU_ITEM)
      encoderPosition -= (uint32_t)ENCODER_STEPS_PER_MENU_ITEM;
    else
      encoderPosition = 0;
  } else {
    return;
  }
  lcdDrawUpdate = 1;
#else
  (void)dir;
#endif
}

void fr3d_lcd_remote_enc_click(void)
{
  fr3d_remote_click_pending = 1;
}

void fr3d_lcd_remote_poll_click(bool *clicked)
{
  if (!clicked) return;
  if (fr3d_remote_click_pending) {
    fr3d_remote_click_pending = 0;
    *clicked = true;
  }
}

void fr3d_lcd_remote_dump_lcdq(void)
{
  char line[FR3D_LCD_MIRROR_COLS + 1];
  for (uint8_t r = 0; r < FR3D_LCD_MIRROR_ROWS; r++) {
    fr3d_lcd_mirror_get_line(r, line, FR3D_LCD_MIRROR_COLS);
    SERIAL_ECHO_START;
    SERIAL_ECHOPGM("LCD,");
    SERIAL_ECHO((int)r);
    SERIAL_ECHOPGM(",");
    SERIAL_ECHO(line);
    SERIAL_ECHOLNPGM(",");
  }
}

#endif /* ULTRA_LCD */