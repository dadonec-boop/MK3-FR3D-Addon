/*
  temperature.h - temperature controller
  
*/

#ifndef temperature_h
#define temperature_h 

#include "MK3.h"
#include "planner.h"
#ifdef PID_ADD_EXTRUSION_RATE
  #include "stepper.h"
#endif

// public functions
void tp_init();  //initialize the heating
void manage_heater(); //it is critical that this is called periodically.

// For converting raw Filament Width to milimeters
float analog2widthFil();
	
// For converting raw Filament Width to an extrusion ratio based on area (from width to area)
int widthFil_to_extrusion_ratio(float nominal_width);


// low level conversion routines
// do not use these routines and variables outside of temperature.cpp
extern int target_temperature[EXTRUDERS];  
extern float current_temperature[EXTRUDERS];
#ifdef SHOW_TEMP_ADC_VALUES
  extern int current_temperature_raw[EXTRUDERS];
  extern int current_temperature_bed_raw;
#endif
extern int target_temperature_bed;
extern float current_temperature_bed;
extern float current_filwidth;

#ifdef TEMP_SENSOR_1_AS_REDUNDANT
  extern float redundant_temperature;
#endif

#if defined(CONTROLLERFAN_PIN) && CONTROLLERFAN_PIN > -1
  extern unsigned char soft_pwm_bed;
#endif

#ifdef PIDTEMP
  extern float Kp,Ki,Kd,Kc;
  float scalePID_i(float i);
  float scalePID_d(float d);
  float unscalePID_i(float i);
  float unscalePID_d(float d);

#endif
//#ifdef PIDTEMPBED
  extern float fwidthKp,fwidthKi,fwidthKd;
  extern float fFactor1, fFactor2, pcirc, sensorRunoutMin, sensorRunoutMax;
  extern uint8_t fr3d_hall_diameter_enabled;
  extern float fr3d_hall_cal_adc_170, fr3d_hall_cal_adc_175, fr3d_hall_cal_adc_180;
  extern float fr3d_hall_diam_offset_mm;
  extern uint8_t fr3d_hall_pattern;     /* 0=A (1.5/1.7/2.0), 1=B (1.7/1.75/2.0) */
  extern uint8_t fr3d_hall_cal_valid;   /* 1 = three pattern points calibrated */
  extern uint8_t fr3d_hall_cal_mask;    /* bits 0/1/2 = Lo/Mid/Hi points saved */
  float fr3d_hall_pattern_mm(uint8_t idx);
  void fr3d_hall_set_pattern(uint8_t pat);
  void fr3d_hall_note_point_saved(uint8_t bit);
  void fr3d_hall_migrate_from_legacy_adc(void);
  /** true si los 3 ADC guardados no son los defaults de fábrica. */
  uint8_t fr3d_hall_points_look_saved(void);
  /**
   * Si CALV=0 pero hay 3 puntos guardados, pone CALV=1 y mask=7.
   * Devuelve 1 si quedó calibrado (ya lo estaba o se reparó).
   */
  uint8_t fr3d_hall_activate_saved_cal(void);
  extern uint8_t fr3d_pred_enabled, fr3d_pred_mode;
  extern uint8_t fr3d_pred_optimize; /* RAM sesión: 0=off 1=on; no EEPROM */
  extern float fr3d_pred_p_star; /* Objetivo eficiencia P* observado (RPM pull en PAUT); RAM */
  extern uint8_t fr3d_pred_p_star_valid; /* 0=sin objetivo 1=usar fr3d_pred_p_star */
  extern uint8_t fr3d_pred_window_size, fr3d_pred_delta_t_max, fr3d_pred_t_switch_margin, fr3d_pred_t_settle_fusions;
  extern float fr3d_pred_hold_m;
  extern uint16_t fr3d_pred_hold_timeout_s;
  extern float fr3d_pred_target_diam_mm, fr3d_pred_deadband_half_mm, fr3d_pred_temp_match_max_c;
  extern float fr3d_diam_jump_debounce_mm, fr3d_diam_pending_match_mm;
  extern uint8_t fr3d_diam_debug_csv_enabled;
  extern uint8_t fr3d_csv_cycle_s;
  extern float fr3d_pred_r_min, fr3d_pred_r_max, fr3d_pred_delta_r_min, fr3d_pred_delta_r_max;
  extern float fr3d_pred_k_span_r, fr3d_pred_k_err_r, fr3d_pred_delta_t_min, fr3d_pred_k_span_t, fr3d_pred_k_err_t;
  extern int16_t fr3d_pred_t_min, fr3d_pred_t_max;
  extern float fr3d_pred_r_switch_margin;
#if defined(FR3D_HALL_DIAMETER_PIN) && (FR3D_HALL_DIAMETER_PIN > -1)
  /* Promedio ~0..1023 actualizado en el ISR de temperatura (no bloquear TIMER0 desde main). */
  extern volatile uint16_t fr3d_hall_adc_oversample;
#endif
//#endif

#ifdef BABYSTEPPING
  extern volatile int babystepsTodo[3];
#endif
  
//high level conversion routines, for use outside of temperature.cpp
//inline so that there is no performance decrease.
//deg=degreeCelsius

FORCE_INLINE float degHotend(uint8_t extruder) {  
  return current_temperature[extruder];
};

#ifdef SHOW_TEMP_ADC_VALUES
  FORCE_INLINE float rawHotendTemp(uint8_t extruder) {  
    return current_temperature_raw[extruder];
  };

  FORCE_INLINE float rawBedTemp() {  
    return current_temperature_bed_raw;
  };
#endif

FORCE_INLINE float degBed() {
  return current_temperature_bed;
};

FORCE_INLINE float degTargetHotend(uint8_t extruder) {  
  return target_temperature[extruder];
};

FORCE_INLINE float degTargetBed() {   
  return target_temperature_bed;
};

FORCE_INLINE void setTargetHotend(const float &celsius, uint8_t extruder) {  
  target_temperature[extruder] = celsius;
};

FORCE_INLINE void setTargetBed(const float &celsius) {  
  target_temperature_bed = celsius;
};

FORCE_INLINE bool isHeatingHotend(uint8_t extruder){  
  return target_temperature[extruder] > current_temperature[extruder];
};

FORCE_INLINE bool isHeatingBed() {
  return target_temperature_bed > current_temperature_bed;
};

FORCE_INLINE bool isCoolingHotend(uint8_t extruder) {  
  return target_temperature[extruder] < current_temperature[extruder];
};

FORCE_INLINE bool isCoolingBed() {
  return target_temperature_bed < current_temperature_bed;
};

#define degHotend0() degHotend(0)
#define degTargetHotend0() degTargetHotend(0)
#define setTargetHotend0(_celsius) setTargetHotend((_celsius), 0)
#define isHeatingHotend0() isHeatingHotend(0)
#define isCoolingHotend0() isCoolingHotend(0)
#if EXTRUDERS > 1
#define degHotend1() degHotend(1)
#define degTargetHotend1() degTargetHotend(1)
#define setTargetHotend1(_celsius) setTargetHotend((_celsius), 1)
#define isHeatingHotend1() isHeatingHotend(1)
#define isCoolingHotend1() isCoolingHotend(1)
#else
#define setTargetHotend1(_celsius) do{}while(0)
#endif
#if EXTRUDERS > 2
#define degHotend2() degHotend(2)
#define degTargetHotend2() degTargetHotend(2)
#define setTargetHotend2(_celsius) setTargetHotend((_celsius), 2)
#define isHeatingHotend2() isHeatingHotend(2)
#define isCoolingHotend2() isCoolingHotend(2)
#else
#define setTargetHotend2(_celsius) do{}while(0)
#endif
#if EXTRUDERS > 3
#error Invalid number of extruders
#endif



int getHeaterPower(int heater);
void disable_heater();
void setWatch();
void updatePID();

#if (defined (THERMAL_RUNAWAY_PROTECTION_PERIOD) && THERMAL_RUNAWAY_PROTECTION_PERIOD > 0) || (defined (THERMAL_RUNAWAY_PROTECTION_BED_PERIOD) && THERMAL_RUNAWAY_PROTECTION_BED_PERIOD > 0)
void thermal_runaway_protection(int *state, unsigned long *timer, float temperature, float target_temperature, int heater_id, int period_seconds, int hysteresis_degc);
static int thermal_runaway_state_machine[3]; // = {0,0,0};
static unsigned long thermal_runaway_timer[3]; // = {0,0,0};
static bool thermal_runaway = false;
  #if TEMP_SENSOR_BED != 0
    static int thermal_runaway_bed_state_machine;
    static unsigned long thermal_runaway_bed_timer;
  #endif
#endif

FORCE_INLINE void autotempShutdown(){
 #ifdef AUTOTEMP
 if(autotemp_enabled)
 {
  autotemp_enabled=false;
  if(degTargetHotend(active_extruder)>autotemp_min)
    setTargetHotend(0,active_extruder);
 }
 #endif
}

void PID_autotune(float temp, int extruder, int ncycles);

#endif
